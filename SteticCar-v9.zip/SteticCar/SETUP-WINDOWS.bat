@echo off
setlocal
cd /d "%~dp0"
node -e "const [a,b]=process.versions.node.split('.').map(Number); if(a<22 || (a===22 && b<13)){console.error('Node.js 22.13+ e necessario para o Expo SDK 57.'); process.exit(1)}"
if errorlevel 1 goto :end
if exist node_modules rmdir /s /q node_modules
if exist package-lock.json del /q package-lock.json
call npm install
if errorlevel 1 goto :end
call npx expo install --check
if errorlevel 1 goto :end
call npx expo start --lan -c
:end
pause
