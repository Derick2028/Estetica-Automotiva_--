import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, Animated, Dimensions, Image, SafeAreaView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import * as LocalAuthentication from 'expo-local-authentication';

const { width } = Dimensions.get('window');

interface Props {
  onEnter: () => void;
}

function FaceIdIcon({ scanning }: { scanning: boolean }) {
  const scan = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!scanning) return;
    const animation = Animated.loop(
      Animated.sequence([
        Animated.timing(scan, { toValue: 1, duration: 1400, useNativeDriver: true }),
        Animated.timing(scan, { toValue: 0, duration: 1400, useNativeDriver: true }),
      ]),
    );
    animation.start();
    return () => animation.stop();
  }, [scan, scanning]);

  const translateY = scan.interpolate({ inputRange: [0, 1], outputRange: [-42, 42] });

  return (
    <View style={styles.faceIdIcon}>
      <View style={[styles.corner, styles.cornerTL]} /><View style={[styles.corner, styles.cornerTR]} />
      <View style={[styles.corner, styles.cornerBL]} /><View style={[styles.corner, styles.cornerBR]} />
      <View style={styles.faceOval}>
        <View style={styles.eyeRow}><View style={styles.eye} /><View style={styles.eye} /></View>
        <View style={styles.nose} /><View style={styles.mouth} />
      </View>
      {scanning && <Animated.View style={[styles.scanLine, { transform: [{ translateY }] }]} />}
    </View>
  );
}

export default function LoginScreen({ onEnter }: Props) {
  const [authenticating, setAuthenticating] = useState(false);
  const [biometricLabel, setBiometricLabel] = useState('Biometria');

  const handleBiometrics = useCallback(async () => {
    if (authenticating) return;
    setAuthenticating(true);
    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const isEnrolled = await LocalAuthentication.isEnrolledAsync();
      const supported = await LocalAuthentication.supportedAuthenticationTypesAsync();
      const hasFace = supported.includes(LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION);
      setBiometricLabel(hasFace ? 'Face ID' : 'Biometria');

      if (!hasHardware || !isEnrolled) {
        Alert.alert('Biometria indisponível', 'Este aparelho não possui uma biometria cadastrada. Você pode entrar normalmente.', [
          { text: 'Entrar', onPress: onEnter },
          { text: 'Cancelar', style: 'cancel' },
        ]);
        return;
      }

      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: hasFace ? 'Entrar no SteticCar com Face ID' : 'Entrar no SteticCar com biometria',
        cancelLabel: 'Cancelar',
        fallbackLabel: 'Usar código do aparelho',
        disableDeviceFallback: false,
      });
      if (result.success) onEnter();
    } catch {
      Alert.alert('Biometria indisponível', 'Não foi possível usar a biometria. Você pode entrar normalmente.', [
        { text: 'Entrar', onPress: onEnter },
        { text: 'Cancelar', style: 'cancel' },
      ]);
    } finally {
      setAuthenticating(false);
    }
  }, [authenticating, onEnter]);

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#000000" translucent={false} />
      <View style={styles.container}>
      <Image source={require('../assets/logo.png')} style={styles.coverLogo} resizeMode="contain" />
      <Text style={styles.title}>SteticCar</Text>
      <Text style={styles.subtitle}>ESTÉTICA AUTOMOTIVA</Text>

      <View style={styles.card}>
        <Text style={styles.welcome}>Bem-vindo</Text>
        <Text style={styles.description}>Entre no aplicativo sem precisar de conta.</Text>
        <TouchableOpacity style={styles.enterButton} onPress={onEnter} accessibilityRole="button">
          <Text style={styles.enterText}>Entrar no aplicativo</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.biometricCard}>
        <FaceIdIcon scanning={authenticating} />
        <Text style={styles.biometricTitle}>{authenticating ? `Aguardando ${biometricLabel}...` : `Acesso opcional por ${biometricLabel}`}</Text>
        <Text style={styles.biometricSubtitle}>A biometria é opcional e nunca impede a entrada no aplicativo.</Text>
        <TouchableOpacity style={styles.biometricButton} onPress={handleBiometrics} disabled={authenticating} accessibilityRole="button">
          <Text style={styles.biometricButtonText}>{authenticating ? 'Autenticando...' : `Usar ${biometricLabel}`}</Text>
        </TouchableOpacity>
      </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#000000' },
  container: { flex: 1, backgroundColor: '#000000', alignItems: 'center', justifyContent: 'center', padding: 20 },
  coverLogo: { width: width * 0.58, height: width * 0.34, marginBottom: 2 },
  title: { fontSize: 32, fontWeight: 'bold', color: '#ffffff', marginTop: 4 },
  subtitle: { fontSize: 14, color: '#00aeff', letterSpacing: 2, marginBottom: 16, fontWeight: '600' },
  card: { width: '100%', maxWidth: 380, backgroundColor: '#101010', borderWidth: 1, borderColor: '#242424', borderRadius: 18, padding: 20, marginBottom: 12 },
  welcome: { color: '#ffffff', fontSize: 21, fontWeight: '700', textAlign: 'center', marginBottom: 6 },
  description: { color: '#999999', fontSize: 13, textAlign: 'center', marginBottom: 16 },
  enterButton: { backgroundColor: '#0066cc', borderWidth: 1, borderColor: '#00aeff', borderRadius: 10, paddingVertical: 14, alignItems: 'center' },
  enterText: { color: '#ffffff', fontSize: 16, fontWeight: '700' },
  biometricCard: { width: '100%', maxWidth: 380, alignItems: 'center', backgroundColor: '#0c0c0c', borderWidth: 1, borderColor: '#1e1e1e', borderRadius: 18, paddingVertical: 14, paddingHorizontal: 16 },
  faceIdIcon: { width: 88, height: 88, alignItems: 'center', justifyContent: 'center', marginBottom: 8, overflow: 'hidden' },
  corner: { position: 'absolute', width: 20, height: 20, borderColor: '#00aeff' },
  cornerTL: { top: 2, left: 2, borderTopWidth: 2, borderLeftWidth: 2, borderTopLeftRadius: 7 }, cornerTR: { top: 2, right: 2, borderTopWidth: 2, borderRightWidth: 2, borderTopRightRadius: 7 },
  cornerBL: { bottom: 2, left: 2, borderBottomWidth: 2, borderLeftWidth: 2, borderBottomLeftRadius: 7 }, cornerBR: { bottom: 2, right: 2, borderBottomWidth: 2, borderRightWidth: 2, borderBottomRightRadius: 7 },
  faceOval: { width: 45, height: 58, borderWidth: 2, borderColor: '#00aeff', borderRadius: 24, alignItems: 'center', paddingTop: 18 },
  eyeRow: { flexDirection: 'row', gap: 12 }, eye: { width: 4, height: 4, borderRadius: 2, backgroundColor: '#00aeff' }, nose: { width: 2, height: 10, backgroundColor: '#00aeff', marginTop: 3 }, mouth: { width: 14, height: 5, borderBottomWidth: 2, borderColor: '#00aeff', borderRadius: 8 },
  scanLine: { position: 'absolute', left: 12, right: 12, height: 2, backgroundColor: '#00aeff' },
  biometricTitle: { color: '#ffffff', fontSize: 15, fontWeight: '700', textAlign: 'center', marginBottom: 4 }, biometricSubtitle: { color: '#777777', fontSize: 12, textAlign: 'center', lineHeight: 17, marginBottom: 8 },
  biometricButton: { paddingVertical: 9, paddingHorizontal: 18, borderRadius: 8, backgroundColor: '#222222', borderWidth: 1, borderColor: '#333333' }, biometricButtonText: { color: '#ffffff', fontSize: 13, fontWeight: '700' },
});
