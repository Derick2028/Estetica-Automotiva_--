# SteticCar

Aplicativo de estética automotiva

## Versão

- Expo SDK 57


# Explicação sobre o app SteticCar 

## Acesso do aplicativo
A tela de entrada possui um botão normal de acesso. Face ID/biometria continua disponível somente como opção.

## Tudo sobre o App

- O aplicativo inicia exigindo autenticação biométrica do aparelho. No iPhone com Face ID, o sistema abre o Face ID nativo; em aparelhos Android compatíveis, usa a biometria disponível.
- Novo agendamento salva o registro no estado do aplicativo e abre imediatamente a lista de agendamentos.
- Ver agendamentos mostra os registros cadastrados, ordenados por data e horário.
- Há botão Voltar nas telas internas e botão Sair no início, no formulário e na lista.
- Ao sair, o aplicativo volta para a tela de autenticação biométrica.
-  fiz a modificação acresentando a camera para tira foto da placa do carro. 


## Estrutura

- `pages/` — telas do aplicativo.
- `login/` — tela de entrada e biometria opcional.
- `camera/` — captura e recorte automático da placa.
- `utils/` — tipos compartilhados.
- `assets/` — imagens.
