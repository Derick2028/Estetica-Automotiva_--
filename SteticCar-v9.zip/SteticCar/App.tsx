import React, { useState } from 'react';
import { Alert } from 'react-native';
import LoginScreen from './login/LoginScreen';
import Home from './pages/Home';
import AgendamentoForm from './pages/AgendamentoForm';
import ListaAgendamentos from './pages/ListaAgendamentos';
import { Agendamento } from './utils/types';

type Screen = 'login' | 'home' | 'novo' | 'lista';

export default function App() {
  const [screen, setScreen] = useState<Screen>('login');
  const [agendamentos, setAgendamentos] = useState<Agendamento[]>([]);

  const logout = () => setScreen('login');

  const salvarAgendamento = (novo: Agendamento) => {
    setAgendamentos((atual) => [...atual, novo]);
    setScreen('lista');
    Alert.alert('Agendamento realizado', 'O agendamento foi salvo e já está disponível em Ver agendamentos.');
  };

  if (screen === 'login') return <LoginScreen onEnter={() => setScreen('home')} />;
  if (screen === 'novo') return <AgendamentoForm agendamentos={agendamentos} onAgendamento={salvarAgendamento} onVoltar={() => setScreen('home')} onLogout={logout} />;
  if (screen === 'lista') return <ListaAgendamentos agendamentos={agendamentos} onVoltar={() => setScreen('home')} onNovoAgendamento={() => setScreen('novo')} onLogout={logout} />;
  return <Home onAgendar={() => setScreen('novo')} onVerAgendamentos={() => setScreen('lista')} onLogout={logout} />;
}
