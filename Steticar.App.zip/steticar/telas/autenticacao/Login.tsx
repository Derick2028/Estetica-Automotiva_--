import { createThemedStyles, themeColor, themeStatusBar } from '../../ui/theme';
import { NeonBackdrop, BrandLogo } from '../../ui/neon';
import { useEffect, useState } from 'react';
import { Alert, ActivityIndicator, KeyboardAvoidingView, Platform, ScrollView, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { entrarFirebase, entrarGoogleFirebase, recuperarSenhaFirebase } from '../../services/firebase/autenticacao';
import { buscarClientePorEmail, buscarClientePorId, criarCliente } from '../../services/database';
import { sessaoOffline } from '../../services/firebase/sessaoOffline';
import { autenticarNoAparelho, limparBloqueioBiometrico, nomeBiometria, obterAcessoBiometrico, salvarClienteBiometria } from '../../servicos/segurancaUsuario';
import { lerCredenciaisCliente, salvarCredenciaisCliente } from '../../servicos/credenciaisSalvas';

interface Props { onEnter: (id: number) => void; onCadastro: () => void; onVoltar: () => void }

export default function Login({ onEnter, onCadastro, onVoltar }: Props) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [ocupado, setOcupado] = useState(false);
  const [recuperando, setRecuperando] = useState(false);
  const [nomeBio, setNomeBio] = useState('biometria / Face ID');

  useEffect(() => {
    let ativo = true;
    nomeBiometria().then(nome => { if (ativo) setNomeBio(nome); }).catch(console.warn);
    lerCredenciaisCliente().then(dados => { if (ativo && dados) { setEmail(dados.email); setSenha(dados.senha); } }).catch(console.warn);
    return () => { ativo = false; };
  }, []);

  const obterClienteDaConta = async (endereco: string, perfil: { nome: string; telefone?: string; endereco?: string }) => {
    const existente = await buscarClientePorEmail(endereco);
    if (existente) return existente.id;
    return criarCliente({
      nome: perfil.nome,
      celular: perfil.telefone ?? '',
      endereco: perfil.endereco ?? '',
      email: endereco,
      placa: `CLIENTE-${Date.now()}`,
    });
  };

  // A primeira ativação só é permitida depois de validar e-mail e senha no Firebase.
  // Uma digital/Face ID não é substituto da confirmação de identidade na primeira entrada.
  const entrarComSenha = async (ativarDiretamente = false) => {
    if (ocupado) return;
    if (!email.trim() || !senha) {
      Alert.alert('Dados necessários', 'Informe seu e-mail e senha para vincular a biometria a esta conta.');
      return;
    }
    setOcupado(true);
    try {
      const endereco = email.trim().toLowerCase();
      const resultado = await entrarFirebase(endereco, senha);
      if (resultado.perfil?.tipo !== 'cliente' || resultado.perfil.ativo === false) {
        throw new Error('Esta conta não está autorizada como cliente.');
      }
      const id = await obterClienteDaConta(endereco, resultado.perfil);
      const registro = await obterAcessoBiometrico('cliente');
      const continuar = () => { setSenha(''); onEnter(id); };
      const ativar = async () => {
        try {
          if (await autenticarNoAparelho('Ativar entrada por biometria')) {
            await salvarCredenciaisCliente(endereco, senha);
            await salvarClienteBiometria(id);
            await limparBloqueioBiometrico();
          }
        } catch (erro: any) {
          Alert.alert('Biometria não ativada', erro?.message ?? 'Você pode continuar entrando com sua senha.');
        } finally { continuar(); }
      };
      if (registro?.clienteId === id) { await salvarCredenciaisCliente(endereco, senha); continuar(); return; }
      if (ativarDiretamente) { await ativar(); return; }
      // Ativação opcional e solicitada na tela de entrada, nunca no perfil.
      Alert.alert('Acesso rápido', `Deseja ativar ${nomeBio} para entrar nas próximas vezes?`, [
        { text: 'Agora não', style: 'cancel', onPress: continuar },
        { text: 'Ativar', onPress: () => { void ativar(); } },
      ], { cancelable: false });
    } catch (erro: any) {
      Alert.alert('Não foi possível entrar', erro?.message ?? 'Confira o e-mail, a senha e sua conexão.');
    } finally { setOcupado(false); }
  };

  const entrarComGoogle = async () => {
    if (ocupado) return;
    setOcupado(true);
    try {
      const resultado = await entrarGoogleFirebase('cliente');
      if (!resultado) return;
      const endereco = resultado.usuario.email?.toLowerCase();
      if (!endereco) throw new Error('A Conta Google não forneceu um e-mail.');
      const id = await obterClienteDaConta(endereco, resultado.perfil);
      setEmail(endereco);
      setSenha('');
      onEnter(id);
    } catch (erro: any) {
      Alert.alert('Login Google indisponível', erro?.message ?? 'Verifique sua internet e a configuração da Conta Google.');
    } finally { setOcupado(false); }
  };

  const entrarComBiometria = async () => {
    if (ocupado) return;
    setOcupado(true);
    try {
      const registro = await obterAcessoBiometrico('cliente');
      if (!registro?.clienteId) {
        // O usuário pode iniciar a ativação na própria tela de login.
        if (email.trim() && senha) {
          setOcupado(false);
          await entrarComSenha(true);
        } else {
          Alert.alert('Primeiro acesso com senha',
            `Para ativar ${nomeBio}, informe seu e-mail e senha nesta tela e toque novamente em "Entrar com ${nomeBio}". Depois, bastará usar a biometria.`);
        }
        return;
      }
      if (email.trim() && email.trim().toLowerCase() !== registro.email) {
        throw new Error('A biometria deste aparelho está vinculada a outra conta. Entre com a senha para trocar.');
      }
      if (!await autenticarNoAparelho('Entrar no StetiCar')) return;
      const { user } = await sessaoOffline('cliente');
      const cliente = await buscarClientePorId(registro.clienteId);
      if (user.uid !== registro.uid || !cliente || cliente.email?.trim().toLowerCase() !== registro.email) {
        throw new Error('Não foi possível confirmar a conta local. Entre novamente com e-mail e senha.');
      }
      await limparBloqueioBiometrico();
      onEnter(cliente.id);
    } catch (erro: any) {
      Alert.alert('Acesso biométrico indisponível', erro?.message ?? 'Use sua senha para entrar.');
    } finally { setOcupado(false); }
  };

  const recuperar = async () => {
    if (recuperando) return;
    if (!email.trim()) return Alert.alert('Informe seu e-mail', 'Digite o e-mail para recuperar a senha.');
    setRecuperando(true);
    try {
      await recuperarSenhaFirebase(email);
      Alert.alert('Confira seu e-mail', 'Se a conta estiver cadastrada, você receberá instruções para redefinir a senha.');
    } catch (erro: any) {
      Alert.alert('Não foi possível enviar', erro?.message ?? 'Verifique sua conexão e tente novamente.');
    } finally { setRecuperando(false); }
  };

  return <SafeAreaView style={s.safe}><NeonBackdrop />
    <StatusBar barStyle={themeStatusBar()} />
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={s.box} keyboardShouldPersistTaps="handled">
        <View style={s.imagem}>
          <View style={s.logoGlow} pointerEvents="none"/>
          <BrandLogo width={255} height={182}/>
          <Text style={s.slogan}>ESTÉTICA AUTOMOTIVA PREMIUM</Text>
        </View>
        <Text style={s.sub}>Área do Cliente</Text>
        <Text style={s.subDesc}>Entre para agendar serviços, acompanhar atendimentos e acessar sua conta com praticidade.</Text>
        <View style={s.card}>
          <Text style={s.label}>E-mail</Text>
          <TextInput style={s.input} keyboardType="email-address" autoCapitalize="none" autoComplete="email" value={email} onChangeText={setEmail} placeholder="seuemail@exemplo.com" placeholderTextColor={themeColor("#688CA7")} />
          <Text style={s.label}>Senha</Text>
          <TextInput style={s.input} secureTextEntry value={senha} onChangeText={setSenha} placeholder="Sua senha" placeholderTextColor={themeColor("#688CA7")} />
          <TouchableOpacity style={s.prim} disabled={ocupado} onPress={() => { void entrarComSenha(); }} accessibilityRole="button">
            {ocupado ? <ActivityIndicator color="#03060D" /> : <Text style={s.bt}>Entrar com senha</Text>}
          </TouchableOpacity>
          <TouchableOpacity style={[s.google, { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#DADCE0' }]} disabled={ocupado} onPress={() => { void entrarComGoogle(); }} accessibilityRole="button">
            <Text style={[s.googleTexto, { color: '#202124' }]}><Text style={{color:themeColor('#4285F4'),fontWeight:'900'}}>G</Text>   Entrar com Google</Text>
          </TouchableOpacity>
          <TouchableOpacity style={s.sec} disabled={ocupado} onPress={() => { void entrarComBiometria(); }} accessibilityRole="button">
            <Text style={s.bioText}>◉  Entrar com {nomeBio}</Text>
          </TouchableOpacity>
          <Text style={s.ajuda}>O primeiro acesso pelo Google exige internet. Depois, sua sessão validada pode ser reaberta offline. A biometria pode ser ativada após um acesso com senha.</Text>
          <TouchableOpacity style={s.link} disabled={recuperando} onPress={() => { void recuperar(); }}><Text style={s.linkT}>{recuperando ? 'Enviando...' : 'Esqueci minha senha'}</Text></TouchableOpacity>
          <TouchableOpacity style={s.link} onPress={onCadastro}><Text style={s.linkT}>Criar meu cadastro</Text></TouchableOpacity>
        </View>
        <TouchableOpacity onPress={onVoltar} accessibilityRole="button" style={s.voltar}>
          <Text style={s.linkT}>← Voltar para escolher acesso</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  </SafeAreaView>;
}

const s = createThemedStyles({
  safe: { flex: 1, backgroundColor: themeColor('#03060D') },
  box: { flexGrow: 1, justifyContent: 'center', padding: 22, alignItems: 'center' },
  imagem: { width: '100%', height: 228, alignItems: 'center', justifyContent: 'center', borderRadius: 24, overflow: 'hidden', marginBottom: 14, borderWidth: 1, borderColor: themeColor('#164463'), backgroundColor: themeColor('rgba(4,11,24,0.88)') },
  logoGlow: { position: 'absolute', width: 190, height: 120, borderRadius: 60, backgroundColor: themeColor('rgba(0,177,255,0.15)') },
  marca: { backgroundColor: themeColor('rgba(2,14,23,0.72)'), padding: 14, alignItems: 'center' },
  titulo: { fontSize: 31, fontWeight: '900', color: themeColor('#FFFFFF') },
  slogan: { color: themeColor('#43DEFF'), letterSpacing: 2.2, fontSize: 9, fontWeight: '900', marginTop: -12 },
  sub: { color: themeColor('#00B9FF'), marginBottom: 6, fontSize: 22, fontWeight: '900' },
  subDesc: { color: themeColor('#9EBDD3'), marginBottom: 22, textAlign: 'center', lineHeight: 19 },
  card: {width: '100%', maxWidth: 420, backgroundColor: themeColor('#0A111E'), padding: 20, borderRadius: 20, borderWidth: 1, borderColor: themeColor('#164463'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},
  label: { color: themeColor('#fff'), fontWeight: '700', marginBottom: 7 },
  input: {height: 52, borderRadius: 14, borderWidth: 1, borderColor: themeColor('#164463'), backgroundColor: themeColor('#081828'), color: themeColor('#fff'), paddingHorizontal: 14, marginBottom: 16},
  prim: {backgroundColor: themeColor('#067EEB'), padding: 15, borderRadius: 16, alignItems: 'center', borderWidth: 1, borderColor: themeColor('#43DEFF'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.35, shadowRadius: 12, shadowOffset: {width:0,height:3}, elevation: 6},
  google: { backgroundColor:themeColor('#FFFFFF'), padding:15, borderRadius:10, alignItems:'center', marginTop:12 },
  googleTexto: { color:themeColor('#202124'),fontWeight:'900' },
  sec: {backgroundColor: themeColor('#081828'), padding: 15, borderRadius: 15, alignItems: 'center', marginTop: 12, borderWidth: 1, borderColor: themeColor('#148DD2')},
  bt: { color: themeColor('#FFFFFF'), fontWeight: '800' },
  bioText: { color: themeColor('#FFFFFF'), fontWeight: '800' },
  ajuda: { color: themeColor('#9EBDD3'), fontSize: 12, lineHeight: 18, marginTop: 12 },
  link: { padding: 14, alignItems: 'center' },
  linkT: { color: themeColor('#00B9FF'), fontWeight: '700' },
  voltar: { marginTop: 22, marginBottom: 12, alignSelf: 'stretch', alignItems: 'center', padding: 15, borderRadius: 12, borderWidth: 1, borderColor: themeColor('#00B9FF') },
});
