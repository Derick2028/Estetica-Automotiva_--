import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type ThemeMode = 'dark' | 'light';
const THEME_STORAGE_KEY = '@steticar/appearance';

// Estado visual único. A alteração ocorre antes da atualização do contexto para
// que os StyleSheets existentes e os estilos em linha usem a mesma paleta.
let activeMode: ThemeMode = 'dark';
export const currentTheme = () => activeMode;

const LIGHT_COLORS: Record<string, string> = {
  '#03060d': '#F3F7FC',
  '#000000': '#F3F7FC',
  '#0a111e': '#FFFFFF',
  '#0e1929': '#FFFFFF',
  '#102439': '#E5F0FA',
  '#081828': '#EEF5FB',
  '#03111a': '#FFFFFF',
  '#060d18': '#FFFFFF',
  '#040b18': '#FFFFFF',
  '#222': '#DFE9F3',
  '#34455d': '#D9E7F3',
  '#164463': '#CADBEA',
  '#148dd2': '#287FB8',
  '#376a7a': '#97B7CC',
  '#00b9ff': '#006DAF',
  '#43deff': '#167BB7',
  '#4ddbff': '#056EAD',
  '#067eeb': '#075EBC',
  '#00baff': '#006DAF',
  '#f7fbff': '#16283C',
  '#f5fafc': '#16283C',
  '#f2f8fc': '#16283C',
  '#e5edf7': '#21364B',
  '#ffffff': '#16283C',
  '#fff': '#16283C',
  'white': '#16283C',
  'black': '#F3F7FC',
  '#9ebdd3': '#526A7D',
  '#688ca7': '#6B8195',
  '#78a6c3': '#5A7388',
  '#506b7d': '#8599A8',
  '#ffd37d': '#99640E',
  '#51e0a5': '#147B58',
  '#ff8294': '#B92C4C',
  '#ff9d9d': '#B92C4C',
};

const TRANSLUCENT_COLORS: Record<string, string> = {
  'rgba(9,19,33,0.98)': 'rgba(255,255,255,0.97)',
  'rgba(10,20,34,0.97)': 'rgba(255,255,255,0.97)',
  'rgba(4,11,24,0.78)': 'rgba(255,255,255,0.88)',
  'rgba(2,12,21,0.75)': 'rgba(5,19,38,0.75)', // Sobre fotografias: manter contraste.
  'rgba(0,150,255,0.13)': 'rgba(0,125,215,0.07)',
  'rgba(0,180,255,0.10)': 'rgba(0,125,215,0.08)',
  'rgba(0,187,255,0.45)': 'rgba(0,112,180,0.22)',
};

/** Converte somente cores visuais; sem modificar dados de negócio. */
export function themeColor(color: string, property = 'color', styleName = '', mode: ThemeMode = activeMode): string {
  if (mode === 'dark') return color;
  const key = color.trim().toLowerCase().replace(/\s+/g, '');
  // Textos sobre botões azuis e imagens precisam permanecer brancos.
  if (property === 'color' && /^photo(Title|Desc)$/i.test(styleName)) {
    return color; // Texto sobre fotografia escurecida: contraste independente do tema.
  }
  if (property === 'color' && /^(#fff|#ffffff|white)$/.test(key) &&
      /^(actionText|buttonText|botaoTexto|botaoText|mainText|primText|textoBotao|textButton|activeLabel)$/i.test(styleName)) {
    return '#FFFFFF';
  }
  if (/^rgba\(/.test(key)) {
    const explicit = TRANSLUCENT_COLORS[key];
    if (explicit) return explicit;
    const match = /^rgba\((\d+),(\d+),(\d+),([.\d]+)\)$/.exec(key);
    if (match) {
      const [r, g, b, alpha] = match.slice(1).map(Number);
      if (r < 35 && g < 45 && b < 65 && property === 'backgroundColor')
        return `rgba(255,255,255,${Math.min(1,alpha).toFixed(2)})`;
    }
    return color;
  }
  return LIGHT_COLORS[key] ?? color;
}

function convertStyle(style: any, name: string): any {
  if (!style || typeof style !== 'object') return style;
  if (Array.isArray(style)) return style.map(item => convertStyle(item, name));
  const result: Record<string, unknown> = {};
  Object.keys(style).forEach(property => {
    const value = style[property];
    result[property] = typeof value === 'string' && /^(color|backgroundColor|borderColor|borderTopColor|borderBottomColor|borderLeftColor|borderRightColor|shadowColor|textDecorationColor|tintColor|overlayColor)$/.test(property)
      ? themeColor(value, property, name, 'light') : value;
  });
  // Superfícies claras não precisam de sombras azuis tão intensas.
  if ('shadowOpacity' in result && typeof result.shadowOpacity === 'number')
    result.shadowOpacity = Math.min(result.shadowOpacity, 0.13);
  return result;
}

/** Estilos com duas versões prontas, sem precisar recriar telas nem alterar sua lógica. */
export const createThemedStyles: typeof StyleSheet.create = ((definitions: any) => {
  const dark = StyleSheet.create(definitions);
  // Calcula a paleta clara sem mudar o modo ativo durante o carregamento.
  const light = StyleSheet.create(Object.fromEntries(
    Object.entries(definitions).map(([key, value]) => [key, convertStyle(value, key)])
  ));
  return new Proxy(dark, {
    get(target, prop) {
      if (typeof prop !== 'string') return Reflect.get(target, prop);
      return Reflect.get(activeMode === 'light' ? light : target, prop);
    },
  });
}) as typeof StyleSheet.create;

/** Para pequenas paletas declaradas por telas antigas. */
export function themedPalette<T extends Record<string, string>>(colors: T): T {
  return new Proxy(colors, {
    get(target, prop) {
      const value = Reflect.get(target, prop);
      return typeof value === 'string' ? themeColor(value) : value;
    },
  });
}

export const themeStatusBar = (): 'dark-content' | 'light-content' => activeMode === 'light' ? 'dark-content' : 'light-content';

type ThemeContextValue = { mode: ThemeMode; setMode: (mode: ThemeMode) => void; toggle: () => void };
const ThemeContext = createContext<ThemeContextValue>({
  mode: 'dark', setMode: () => {}, toggle: () => {},
});

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [mode, setModeState] = useState<ThemeMode>('dark');
  const setMode = useCallback((value: ThemeMode) => {
    activeMode = value;
    setModeState(value);
    AsyncStorage.setItem(THEME_STORAGE_KEY, value).catch(error => console.warn('Preferência visual não salva:', error));
  }, []);
  useEffect(() => {
    let mounted = true;
    AsyncStorage.getItem(THEME_STORAGE_KEY)
      .then(saved => {
        if (mounted && (saved === 'dark' || saved === 'light')) {
          activeMode = saved;
          setModeState(saved);
        }
      })
      .catch(error => console.warn('Preferência visual não carregada:', error));
    return () => { mounted = false; };
  }, []);
  const toggle = useCallback(() => setMode(activeMode === 'dark' ? 'light' : 'dark'), [setMode]);
  const value = useMemo(() => ({ mode, setMode, toggle }), [mode, setMode, toggle]);
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export const useAppTheme = () => useContext(ThemeContext);
