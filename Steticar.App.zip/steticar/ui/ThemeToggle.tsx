import { useRef, useState, type ComponentRef } from 'react';
import { Dimensions, Modal, Pressable, Text, TouchableOpacity, View } from 'react-native';
import { useAppTheme, type ThemeMode } from './theme';

/** Acesso discreto à aparência: o menu só aparece quando o ícone é pressionado. */
export default function ThemeToggle({ compact = false }: { compact?: boolean }) {
  const { mode, setMode } = useAppTheme();
  const [aberto, setAberto] = useState(false);
  const [posicao, setPosicao] = useState({ top: 65, right: 16 });
  const ancora = useRef<ComponentRef<typeof View>>(null);
  const escuro = mode === 'dark';
  const corTexto = escuro ? '#F7FBFF' : '#16283C';
  const corSecundaria = escuro ? '#9EBDD3' : '#5A7388';
  const corDestaque = escuro ? '#43DEFF' : '#075EBC';

  function abrirOuFechar() {
    if (aberto) {
      setAberto(false);
      return;
    }
    // Mantém o menu próximo do ícone, mesmo em telas com diferentes cabeçalhos.
    if (!ancora.current) {
      setAberto(true);
      return;
    }
    ancora.current.measureInWindow((x, y, largura, altura) => {
      const larguraTela = Dimensions.get('window').width;
      const alturaTela = Dimensions.get('window').height;
      setPosicao({
        top: Math.max(12, Math.min(y + altura + 8, alturaTela - 210)),
        right: Math.max(12, Math.min(larguraTela - x - largura, larguraTela - 225)),
      });
      setAberto(true);
    });
  }

  function selecionar(valor: ThemeMode) {
    setMode(valor);
    setAberto(false);
  }

  return (
    <View style={{ alignSelf: 'flex-end', marginVertical: compact ? 4 : 6 }}>
      <View ref={ancora} collapsable={false}>
        <TouchableOpacity
          onPress={abrirOuFechar}
          accessibilityRole="button"
          accessibilityLabel="Alterar aparência do aplicativo"
          accessibilityHint="Abrir opções de modo claro e escuro"
          accessibilityState={{ expanded: aberto }}
          style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center',
            borderRadius: 15, borderWidth: 1,
            borderColor: escuro ? '#164463' : '#CADBEA',
            backgroundColor: escuro ? '#081828' : '#FFFFFF' }}>
          <Text style={{ color: corDestaque, fontSize: 27, fontWeight: '700', lineHeight: 32 }}>
            {escuro ? '☾' : '☀'}
          </Text>
        </TouchableOpacity>
      </View>
      <Modal
        visible={aberto}
        transparent
        animationType="fade"
        onRequestClose={() => setAberto(false)}>
        <View style={{ flex: 1 }}>
          <Pressable
            accessibilityLabel="Fechar opções de aparência"
            onPress={() => setAberto(false)}
            style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
          />
          <View style={{ position: 'absolute', top: posicao.top, right: posicao.right,
            width: 208, padding: 12, borderRadius: 17, borderWidth: 1,
            borderColor: escuro ? '#245979' : '#BDD6E8',
            backgroundColor: escuro ? '#0D2034' : '#FFFFFF',
            shadowColor: '#001C35', shadowOpacity: 0.25, shadowRadius: 16,
            shadowOffset: { width: 0, height: 5 }, elevation: 18 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between',
              alignItems: 'center', marginBottom: 8 }}>
              <Text style={{ color: corTexto, fontWeight: '800', fontSize: 14 }}>Aparência</Text>
              <TouchableOpacity onPress={() => setAberto(false)}
                accessibilityRole="button" accessibilityLabel="Fechar menu de aparência"
                style={{ paddingVertical: 5, paddingHorizontal: 9 }}>
                <Text style={{ fontSize: 19, color: corSecundaria }}>×</Text>
              </TouchableOpacity>
            </View>
            {([
              { value: 'light', label: '☀  Modo claro' },
              { value: 'dark', label: '☾  Modo escuro' },
            ] as const).map(opcao => {
              const selecionado = mode === opcao.value;
              return (
                <TouchableOpacity key={opcao.value}
                  onPress={() => selecionar(opcao.value)}
                  accessibilityRole="button"
                  accessibilityState={{ selected: selecionado }}
                  style={{ minHeight: 44, borderRadius: 11, flexDirection: 'row',
                    alignItems: 'center', justifyContent: 'space-between',
                    paddingHorizontal: 12, marginTop: 5,
                    backgroundColor: selecionado
                      ? (escuro ? '#0878D3' : '#E4F2FC')
                      : (escuro ? '#142B42' : '#F2F6FB') }}>
                  <Text style={{ fontSize: 13, fontWeight: selecionado ? '800' : '600',
                    color: selecionado && escuro ? '#FFFFFF' : corTexto }}>
                    {opcao.label}
                  </Text>
                  {selecionado && <Text style={{ color: selecionado && escuro ? '#FFFFFF' : corDestaque,
                    fontWeight: '900', fontSize: 16 }}>✓</Text>}
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
      </Modal>
    </View>
  );
}
