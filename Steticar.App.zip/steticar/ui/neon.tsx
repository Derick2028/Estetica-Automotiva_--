import { Image, ImageStyle, StyleSheet, Text, View } from 'react-native';
import { createThemedStyles, currentTheme, themeColor } from './theme';

const DARK_NEON = {
  bg: '#03060D',
  surface: '#0A111E',
  panel: '#0E1929',
  raised: '#102439',
  input: '#081828',
  line: '#164463',
  lineBright: '#148DD2',
  primary: '#00B9FF',
  bright: '#43DEFF',
  blue: '#067EEB',
  text: '#F7FBFF',
  muted: '#9EBDD3',
  subtle: '#688CA7',
  success: '#51E0A5',
  warning: '#FFD37D',
  danger: '#FF8294',
} as const;

export const NEON: typeof DARK_NEON = new Proxy(DARK_NEON, {
  get(target, key) {
    const value = Reflect.get(target, key);
    return typeof value === 'string' ? themeColor(value) : value;
  },
});

export const neo = createThemedStyles({
  card: {
    backgroundColor: NEON.surface,
    borderColor: NEON.line,
    borderWidth: 1,
    borderRadius: 22,
    shadowColor: NEON.primary,
    shadowOpacity: 0.18,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 5 },
    elevation: 5,
  },
  cardActive: {
    borderColor: NEON.primary,
    shadowColor: NEON.primary,
    shadowOpacity: 0.35,
    shadowRadius: 17,
    elevation: 8,
  },
  action: {
    backgroundColor: NEON.blue,
    borderWidth: 1,
    borderColor: NEON.bright,
    borderRadius: 16,
    minHeight: 48,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: NEON.primary,
    shadowOpacity: 0.40,
    shadowRadius: 13,
    shadowOffset: { width: 0, height: 3 },
    elevation: 6,
  },
  secondary: {
    backgroundColor: NEON.input,
    borderColor: NEON.lineBright,
    borderWidth: 1,
    borderRadius: 16,
    minHeight: 48,
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    backgroundColor: NEON.input,
    borderWidth: 1,
    borderColor: NEON.line,
    borderRadius: 14,
    minHeight: 50,
    paddingHorizontal: 14,
    color: NEON.text,
  },
  heading: { color: NEON.text, fontSize: 24, fontWeight: '900' },
  actionText: { color: '#FFFFFF', fontWeight: '900', fontSize: 15 },
  caption: { color: NEON.muted, fontSize: 13, lineHeight: 19 },
  glow: {
    borderWidth: 1,
    borderColor: 'rgba(0, 187, 255, 0.45)',
    borderRadius: 25,
    shadowColor: NEON.primary,
    shadowOpacity: 0.4,
    shadowRadius: 21,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
});

export function NeonBackdrop() {
  const source = currentTheme() === 'light'
    ? require('../assets/visual/light_background.png')
    : require('../assets/visual/neon_background.png');
  return <Image pointerEvents="none" accessibilityIgnoresInvertColors
    source={source} resizeMode="cover" style={StyleSheet.absoluteFill} />;
}

export function BrandLogo({ width = 220, height = 180, style }: { width?: number; height?: number; style?: ImageStyle }) {
  return <Image source={require('../assets/logo.png')} resizeMode="contain"
    accessibilityLabel="Logo tridimensional StetiCar"
    style={[{ width, height }, style]} />;
}

export function SectionLabel({ title, subtitle }: { title: string; subtitle?: string }) {
  return <View style={{ marginBottom: 14 }}><Text style={neo.heading}>{title}</Text>
    {!!subtitle && <Text style={[neo.caption, { marginTop: 5 }]}>{subtitle}</Text>}</View>;
}
