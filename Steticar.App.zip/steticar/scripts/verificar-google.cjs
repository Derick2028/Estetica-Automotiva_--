const fs = require('node:fs');
const path = require('node:path');

const raiz = path.resolve(__dirname, '..');
const erros = [];
const avisos = [];
const plataforma = process.argv.includes('--ios') ? 'ios' : 'android';

function registrar(erro) { erros.push(erro); }
function carregarEnv() {
  const values = {};
  const filename = path.join(raiz, '.env');
  if (!fs.existsSync(filename)) return values;
  const content = fs.readFileSync(filename, 'utf8');
  for (const line of content.split(/\r?\n/)) {
    const found = line.match(/^\s*(EXPO_PUBLIC_[A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (found) values[found[1]] = found[2].replace(/^['"]|['"]$/g, '');
  }
  return values;
}
const env = { ...carregarEnv(), ...process.env };
const expo = require(path.join(raiz, 'app.json')).expo;
const required = ['EXPO_PUBLIC_FIREBASE_API_KEY','EXPO_PUBLIC_FIREBASE_PROJECT_ID','EXPO_PUBLIC_FIREBASE_APP_ID'];
for (const key of required) {
  if (!env[key] || /SUBSTITUA|PLACEHOLDER/i.test(env[key])) registrar(`Defina ${key} no .env`);
}
const webClientId = env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID;
if (!webClientId || !/^\d+-[\w-]+\.apps\.googleusercontent\.com$/.test(webClientId)) {
  registrar('Informe EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID (cliente OAuth do tipo Web) no .env');
}

if (plataforma === 'android') {
  const arquivo = path.join(raiz, 'google-services.json');
  if (!fs.existsSync(arquivo)) registrar('Baixe google-services.json do Firebase e coloque na raiz do projeto');
  else {
    try {
      const config = JSON.parse(fs.readFileSync(arquivo, 'utf8'));
      const clients = config.client || [];
      const matched = clients.find(c => c.client_info?.android_client_info?.package_name === expo.android.package);
      if (!matched) registrar(`google-services.json não corresponde ao pacote ${expo.android.package}`);
      else {
        const webIds = (matched.oauth_client || []).filter(c => c.client_type === 3).map(c => c.client_id);
        if (webClientId && webIds.length && !webIds.includes(webClientId)) registrar('O Client ID Web não corresponde ao google-services.json');
        if (!webIds.length) avisos.push('O arquivo ainda não lista um cliente OAuth Web; verifique o provedor Google e baixe uma nova versão do arquivo.');
        const androidOauth = (matched.oauth_client || []).filter(c=>c.client_type===1);
        if (!androidOauth.length) avisos.push('Nenhum cliente OAuth Android encontrado: registre o SHA-1 do certificado do APK no Firebase e atualize google-services.json.');
      }
    } catch(error) { registrar(`google-services.json inválido: ${error.message}`); }
  }
} else {
  const filename = path.join(raiz,'GoogleService-Info.plist');
  if (!fs.existsSync(filename)) registrar('Baixe GoogleService-Info.plist do Firebase e coloque na raiz do projeto');
  if (!env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID) avisos.push('Informe EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID no .env caso o SDK do Google não detecte automaticamente o cliente iOS.');
}

console.log(`Verificação Google Sign-In (${plataforma.toUpperCase()})`);
for (const line of erros) console.error(`ERRO: ${line}`);
for (const line of avisos) console.warn(`ATENÇÃO: ${line}`);
if (erros.length === 0) {
  console.log('Configuração local básica aprovada. Confirme que Google está habilitado no Firebase Authentication.');
  if (plataforma === 'android') console.log('A impressão SHA-1 da chave que assina o APK deve estar registrada no Firebase.');
} else console.error('A configuração Google está incompleta; verifique as mensagens acima.');
process.exitCode = erros.length ? 1 : 0;
