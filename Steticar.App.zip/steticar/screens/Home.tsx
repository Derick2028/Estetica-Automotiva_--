import { createThemedStyles, themeColor, themeStatusBar } from '../ui/theme';
import { useEffect, useRef, useState, type ComponentRef } from 'react';
import { Alert, Image, Linking, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Location from 'expo-location';
import MapView, { Marker } from 'react-native-maps';
import { buscarClientePorId, Cliente } from '../services/database';
import { BrandLogo, NEON, NeonBackdrop, neo } from '../ui/neon';



interface HomeProps {
  clienteId: number;
  onAgendar: () => void;
  onServicos: () => void;
  onExtras: () => void;
  onPolimentos: () => void;
  onFidelidade: () => void;
  onVerAgendamentos: () => void;
  onLogout: () => void;
  onPerfil: () => void;
  onSincronizar: () => void;
}

export default function Home({ clienteId, onAgendar, onServicos, onExtras, onPolimentos, onFidelidade, onVerAgendamentos, onLogout, onPerfil, onSincronizar }: HomeProps) {
  const [perfil, setPerfil] = useState<Cliente | null>(null);
  const scrollRef = useRef<ComponentRef<typeof ScrollView>>(null);
  useEffect(() => { let ativo=true; buscarClientePorId(clienteId).then(c=>{if(ativo)setPerfil(c)}).catch(()=>{});return ()=>{ativo=false}; }, [clienteId]);
  const [location, setLocation] = useState<Location.LocationObject | null>(null);
  const [locationDenied, setLocationDenied] = useState(false);
  const [mostrarMapa, setMostrarMapa] = useState(false);
  const [secaoInfo, setSecaoInfo] = useState<'contato'|'duvidas'|null>(null);
  const abrirContato = async (tipo:'whatsapp'|'email') => {
    const url=tipo==='whatsapp' ? `https://wa.me/5524994195881?text=${encodeURIComponent('Olá, StetiCar! Gostaria de informações sobre os serviços.')}` : `mailto:derickwogel@gmail.com?subject=${encodeURIComponent('Contato - StetiCar')}&body=${encodeURIComponent('Olá, gostaria de saber mais sobre os serviços da StetiCar.')}`;
    try { await Linking.openURL(url); } catch { Alert.alert('Não foi possível abrir', tipo==='whatsapp'?'Verifique se o WhatsApp está disponível.':'Configure um aplicativo de e-mail.'); }
  };

  useEffect(() => {
    if (!mostrarMapa) return;
    let mounted = true;
    let subscription: Location.LocationSubscription | null = null;
    const loadLocation = async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') {
          if (mounted) setLocationDenied(true);
          return;
        }
        const currentLocation = await Location.getCurrentPositionAsync({});
        if (mounted) setLocation(currentLocation);
        subscription = await Location.watchPositionAsync({accuracy: Location.Accuracy.Balanced, timeInterval: 5000, distanceInterval: 10}, pos => { if (mounted) setLocation(pos); });
      } catch {
        if (mounted) setLocationDenied(true);
      }
    };
    loadLocation();
    return () => { mounted = false; subscription?.remove(); };
  }, [mostrarMapa]);

  const atalhos = [
    { imagem: require('../assets/icons/agendar.png'), titulo: 'Agendar Serviço', acao: onAgendar },
    { imagem: require('../assets/icons/agendamentos.png'), titulo: 'Meus Agendamentos', acao: onVerAgendamentos },
    { imagem: require('../assets/icons/perfil.png'), titulo: 'Meu Perfil', acao: onPerfil },
    { imagem: require('../assets/icons/unidade.png'), titulo: 'Minha Unidade', acao: () => setMostrarMapa(v => !v) },
    { imagem: require('../assets/icons/sincronizar.png'), titulo: 'Sincronizar Dados', acao: onSincronizar },
  ];
  const categorias = [
    { imagem: require('../assets/icons/servicos.png'), titulo: 'Nossos serviços', descricao: 'Lavagem simples e completa', acao: onServicos },
    { imagem: require('../assets/icons/extras.png'), titulo: 'Serviços extras', descricao: 'Tratamentos adicionais', acao: onExtras },
    { imagem: require('../assets/icons/polimentos.png'), titulo: 'Polimentos', descricao: 'Cuidado profissional', acao: onPolimentos },
    { imagem: require('../assets/icons/fidelidade.png'), titulo: 'Cartão fidelidade', descricao: 'Acompanhe seus benefícios', acao: onFidelidade },
  ];

  return <SafeAreaView style={styles.safeArea}>
    <StatusBar barStyle={themeStatusBar()} />
    <NeonBackdrop />
    <ScrollView ref={scrollRef} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.top}>
        <Text style={styles.wordmark}>STETI<Text style={{ color: NEON.bright }}>CAR</Text></Text>
        <TouchableOpacity onPress={onPerfil} style={styles.account} accessibilityRole="button" accessibilityLabel="Abrir meu perfil">
          {perfil?.foto_perfil
            ? <Image source={{ uri: perfil.foto_perfil }} style={styles.accountImage} />
            : <Text style={styles.accountIcon}>♙</Text>}
        </TouchableOpacity>
      </View>
      <View style={styles.hero}>
        <View style={styles.heroGlow} pointerEvents="none" />
        <BrandLogo width={245} height={175} />
        <Text style={styles.welcome}>Olá, {perfil?.nome?.trim()?.split(/\s+/)[0] || 'Cliente'}!</Text>
        <Text style={styles.heroSub}>Seu carro merece o melhor cuidado.</Text>
        <Text style={styles.heroCaption}>Escolha uma opção para começar</Text>
      </View>

      <View style={styles.heading}><Text style={styles.headingText}>Menu principal</Text><Text style={styles.headingHint}>ACESSO RÁPIDO</Text></View>
      <View style={styles.grid}>
        {atalhos.map((item, i) => <TouchableOpacity key={item.titulo} onPress={item.acao} style={[neo.card, styles.tile, i === 0 && styles.tileFeatured, i === atalhos.length - 1 && styles.tileWide]} accessibilityRole="button">
          <View style={styles.iconBox}><Image source={item.imagem} style={styles.tileIconImage} resizeMode="contain" /></View>
          <Text style={styles.tileTitle}>{item.titulo}</Text>
          <Text style={styles.tileArrow}>↗</Text>
        </TouchableOpacity>)}
      </View>
      <View style={styles.heading}><Text style={styles.headingText}>Cuidados com seu carro</Text><Text style={styles.headingHint}>SERVIÇOS</Text></View>
      <View style={styles.catalog}>
        {categorias.map(item => <TouchableOpacity key={item.titulo} onPress={item.acao} style={[neo.card, styles.service]} accessibilityRole="button">
          <View style={styles.serviceIcon}><Image source={item.imagem} style={styles.serviceIconImage} resizeMode="contain" /></View>
          <View style={{ flex: 1 }}><Text style={styles.serviceTitle}>{item.titulo}</Text><Text style={styles.serviceText}>{item.descricao}</Text></View>
          <Text style={styles.chevron}>›</Text>
        </TouchableOpacity>)}
      </View>

      <View style={styles.quickActions}>
        <TouchableOpacity onPress={() => setSecaoInfo(v => v === 'contato' ? null : 'contato')} style={styles.quickButton}><Text style={styles.quickButtonText}>✉  Contato</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => setSecaoInfo(v => v === 'duvidas' ? null : 'duvidas')} style={styles.quickButton}><Text style={styles.quickButtonText}>?  Dúvidas</Text></TouchableOpacity>
      </View>
      {secaoInfo === 'contato' && <View style={[neo.card, styles.infoCard]}>
        <Text style={styles.infoTitle}>Fale com a StetiCar</Text>
        <Text style={styles.infoText}>Estamos à disposição para explicar nossos serviços e ajudar você a cuidar do seu veículo.</Text>
        <TouchableOpacity accessibilityRole="button" onPress={() => abrirContato('whatsapp')} style={[neo.action, { marginTop: 12 }]}><Text style={neo.actionText}>WhatsApp · (24) 99419-5881</Text></TouchableOpacity>
        <TouchableOpacity accessibilityRole="button" onPress={() => abrirContato('email')} style={[neo.secondary, { marginTop: 10 }]}><Text style={styles.quickButtonText}>Enviar e-mail</Text></TouchableOpacity>
      </View>}
      {secaoInfo === 'duvidas' && <View style={[neo.card, styles.infoCard]}>
        <Text style={styles.infoTitle}>Dúvidas sobre estética automotiva</Text>
        <Text style={styles.infoText}>A estética automotiva reúne técnicas e produtos específicos para limpar, conservar, proteger e valorizar seu veículo, por dentro e por fora.</Text>
        <Text style={styles.question}>Qual a diferença entre lavagem simples e completa?</Text>
        <Text style={styles.infoText}>A simples inclui pré-lavagem, shampoo siliconado, rodas e pneus, aspiração e limpeza básica do painel. A completa oferece limpeza detalhada, duas pré-lavagens, proteção da pintura, cuidados com plásticos e tratamento interno mais profundo.</Text>
        <Text style={styles.question}>Posso adicionar tratamentos extras?</Text>
        <Text style={styles.infoText}>Sim. Você pode escolher tratamentos adicionais, como cristalização, proteção da pintura, cera hidrorrepelente e restauração de faróis. Também oferecemos Polimento Técnico, Polimento Comercial e Enceramento Comercial como serviços principais.</Text>
        <Text style={styles.question}>Quanto tempo dura a proteção?</Text>
        <Text style={styles.infoText}>Depende do produto, da exposição ao tempo e dos cuidados de manutenção. A duração informada é estimada e não uma garantia.</Text>
        <Text style={styles.question}>Como faço meu agendamento?</Text>
        <Text style={styles.infoText}>Abra Novo Agendamento, escolha um serviço principal, data e horário, selecione os extras e confirme. A disponibilidade compartilhada é atualizada após sincronização com a nuvem.</Text>
      </View>}
      {mostrarMapa && <View style={[neo.card, styles.mapSection]}>
        <Text style={styles.infoTitle}>⌖  Sua localização atual</Text>
        <Text style={styles.mapHint}>O GPS atualiza enquanto esta seção está aberta. Sua localização não é compartilhada automaticamente com a estética.</Text>
        <View style={styles.mapContainer}>
          {location ? <MapView style={styles.map} region={{ latitude: location.coords.latitude, longitude: location.coords.longitude, latitudeDelta: 0.01, longitudeDelta: 0.01 }} showsUserLocation><Marker coordinate={{ latitude: location.coords.latitude, longitude: location.coords.longitude }} title="Minha localização" /></MapView>
            : <View style={styles.placeholder}><Text style={{ color: NEON.muted }}>{locationDenied ? 'Autorize a localização nas configurações.' : 'Buscando localização...'}</Text></View>}
        </View>
      </View>}
      <TouchableOpacity onPress={onLogout} style={styles.logout}><Text style={styles.logoutText}>↪  Sair / bloquear acesso</Text></TouchableOpacity>
      <Text style={styles.footer}>STETICAR  •  ESTÉTICA AUTOMOTIVA PREMIUM</Text>
    </ScrollView>
    <View style={styles.tabbar}>
      <TouchableOpacity onPress={() => scrollRef.current?.scrollTo({ y: 0, animated: true })} accessibilityRole="button" accessibilityState={{ selected: true }} style={styles.tab}>
        <Text style={[styles.tabIcon, { color: NEON.bright }]}>⌂</Text><Text style={[styles.tabText, { color: NEON.bright }]}>Início</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={onVerAgendamentos} accessibilityRole="button" style={styles.tab}>
        <Text style={styles.tabIcon}>▦</Text><Text style={styles.tabText}>Agenda</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={onPerfil} accessibilityRole="button" style={styles.tab}>
        <Text style={styles.tabIcon}>♙</Text><Text style={styles.tabText}>Perfil</Text>
      </TouchableOpacity>
    </View>
  </SafeAreaView>;
}

const styles = createThemedStyles({
  safeArea: { flex: 1, backgroundColor: NEON.bg },
  content: { paddingHorizontal: 17, paddingBottom: 28, maxWidth: 620, width: '100%', alignSelf: 'center' },
  top: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 11, paddingBottom: 6 },
  wordmark: { color: NEON.text, fontWeight: '900', fontSize: 19, letterSpacing: 1.6 },
  account: { width: 42, height: 42, borderRadius: 16, borderWidth: 1, borderColor: NEON.lineBright, backgroundColor: NEON.input, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  accountImage: { width: '100%', height: '100%' },
  accountIcon: { color: NEON.bright, fontSize: 27 },
  hero: { backgroundColor: themeColor('rgba(4,11,24,0.78)'), borderWidth: 1, borderColor: NEON.line, borderRadius: 25, alignItems: 'center', paddingBottom: 18, marginTop: 10, overflow: 'hidden' },
  heroGlow: { position: 'absolute', width: 240, height: 140, top: 12, borderRadius: 95, backgroundColor: themeColor('rgba(0,180,255,0.10)') },
  welcome: { fontSize: 23, color: NEON.text, fontWeight: '900', marginTop: -8 },
  heroSub: { color: NEON.muted, fontSize: 13, marginTop: 5 },
  heroCaption: { fontSize: 12, color: NEON.bright, marginTop: 11, fontWeight: '700', letterSpacing: 0.3 },
  heading: { marginTop: 24, marginBottom: 13, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 6 },
  headingText: { fontSize: 19, color: NEON.text, fontWeight: '900', flexShrink: 1 },
  headingHint: { color: NEON.subtle, fontWeight: '800', letterSpacing: 0.7, fontSize: 9 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 11 },
  tile: { width: '48.25%', minHeight: 130, padding: 14, justifyContent: 'center', alignItems: 'center', position: 'relative', backgroundColor: themeColor('rgba(10,20,34,0.97)') },
  tileWide: { width: '100%', minHeight: 104, flexDirection: 'row', justifyContent: 'flex-start', gap: 14, paddingHorizontal: 18 },
  tileFeatured: { borderColor: NEON.lineBright },
  iconBox: { width: 49, height: 49, borderRadius: 15, backgroundColor: NEON.input, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: NEON.lineBright, marginBottom: 9 },
  tileIconImage: { width: 34, height: 34 },
  tileTitle: { color: NEON.text, fontWeight: '800', fontSize: 12, textAlign: 'center' },
  tileArrow: { color: NEON.primary, position: 'absolute', right: 12, top: 8, fontSize: 16 },
  catalog: { gap: 10 },
  service: { padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12 },
  serviceIcon: { width: 56, height: 56, alignItems: 'center', justifyContent: 'center', borderRadius: 14, backgroundColor: NEON.input, borderWidth: 1, borderColor: NEON.line, overflow: 'hidden' },
  serviceIconImage: { width: 38, height: 38 },
  serviceTitle: { color: NEON.text, fontWeight: '900', fontSize: 15 },
  serviceText: { color: NEON.muted, fontSize: 12, marginTop: 4 },
  chevron: { color: NEON.bright, fontSize: 25, marginRight: 4 },
  quickActions: { flexDirection: 'row', gap: 11, marginTop: 21 },
  quickButton: { flex: 1, padding: 14, borderColor: NEON.lineBright, borderWidth: 1, backgroundColor: NEON.input, borderRadius: 14, alignItems: 'center' },
  quickButtonText: { color: NEON.text, fontWeight: '800', fontSize: 13 },
  infoCard: { padding: 17, marginTop: 16 },
  infoTitle: { color: NEON.text, fontWeight: '900', fontSize: 19, marginBottom: 10 },
  infoText: { color: NEON.muted, lineHeight: 21, fontSize: 13, marginBottom: 9 },
  question: { color: NEON.bright, fontWeight: '800', fontSize: 14, marginTop: 9, marginBottom: 6 },
  mapSection: { padding: 15, marginTop: 15 },
  mapHint: { color: NEON.muted, fontSize: 12, lineHeight: 19, marginBottom: 13 },
  mapContainer: { height: 260, borderRadius: 17, overflow: 'hidden', borderWidth: 1, borderColor: NEON.line },
  map: { flex: 1 },
  placeholder: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: NEON.panel },
  logout: { marginTop: 23, borderColor: NEON.line, borderWidth: 1, borderRadius: 15, padding: 14, alignItems: 'center', backgroundColor: NEON.input },
  logoutText: { color: NEON.muted, fontWeight: '800', fontSize: 13 },
  footer: { color: NEON.subtle, fontSize: 9, textAlign: 'center', marginTop: 17, letterSpacing: 1 },
  tabbar: { flexDirection: 'row', backgroundColor: themeColor('#060D18'), borderTopWidth: 1, borderTopColor: NEON.lineBright, paddingTop: 10, paddingBottom: 8, shadowColor: NEON.primary, shadowOpacity: 0.23, shadowRadius: 13, elevation: 12 },
  tab: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 2, minHeight: 45 },
  tabIcon: { color: NEON.muted, fontSize: 23 },
  tabText: { color: NEON.muted, fontSize: 10, fontWeight: '800' },
});
