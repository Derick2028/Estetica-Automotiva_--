import { createThemedStyles, themeColor } from '../ui/theme';
import { NeonBackdrop, BrandLogo } from '../ui/neon';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { entrarFirebase, entrarGoogleFirebase, sairFirebase } from '../services/firebase/autenticacao';
import { sessaoOffline } from '../services/firebase/sessaoOffline';
import { registrarEmpresaAutorizada } from '../services/offlineAgenda';
import { EMPRESA_ID } from '../services/firebase/agendamentos';
import { autenticarNoAparelho, limparBloqueioBiometrico, nomeBiometria, obterAcessoBiometrico, salvarEmpresaBiometria } from '../servicos/segurancaUsuario';

export default function LoginProprietarioFirebase({ onAutorizado, onVoltar }: { onAutorizado: () => void; onVoltar: () => void }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [ocupado, setOcupado] = useState(false);
  const [nomeBio, setNomeBio] = useState('biometria / Face ID');

  useEffect(() => {
    let ativo = true;
    nomeBiometria().then(nome => { if (ativo) setNomeBio(nome); }).catch(console.warn);
    return () => { ativo = false; };
  }, []);

  const entrarComSenha = async (ativarDiretamente = false) => {
    if (ocupado) return;
    if (!email.trim() || !senha) {
      Alert.alert('Preencha e-mail e senha', 'Informe sua conta administrativa para ativar o reconhecimento biométrico.');
      return;
    }
    setOcupado(true);
    try {
      const resultado = await entrarFirebase(email, senha);
      if (resultado.perfil?.tipo !== 'estetica' || resultado.perfil.ativo !== true) {
        await sairFirebase();
        Alert.alert('Acesso não autorizado', 'Esta conta não tem permissão de estética.');
        return;
      }
      const { user } = await sessaoOffline('estetica');
      await registrarEmpresaAutorizada(user.uid, resultado.perfil.empresaId ?? EMPRESA_ID);
      const registro = await obterAcessoBiometrico('estetica');
      const continuar = () => { setSenha(''); onAutorizado(); };
      const ativar = async () => {
        try {
          if (await autenticarNoAparelho('Ativar entrada biométrica da estética')) {
            await salvarEmpresaBiometria();
            await limparBloqueioBiometrico();
          }
        } catch (erro: any) {
          Alert.alert('Biometria não ativada', erro?.message ?? 'Você pode continuar entrando com a senha.');
        } finally { continuar(); }
      };
      if (registro) { continuar(); return; }
      if (ativarDiretamente) { await ativar(); return; }
      Alert.alert('Acesso rápido', `Deseja ativar ${nomeBio} para entrar na estética nas próximas vezes?`, [
        { text: 'Agora não', style: 'cancel', onPress: continuar },
        { text: 'Ativar', onPress: () => { void ativar(); } },
      ], { cancelable: false });
    } catch (erro: any) {
      Alert.alert('Não foi possível entrar', erro?.message ?? 'Verifique sua internet e os dados da conta.');
    } finally { setOcupado(false); }
  };

  const entrarComGoogle = async () => {
    if (ocupado) return;
    setOcupado(true);
    try {
      const resultado = await entrarGoogleFirebase('estetica');
      if (!resultado) return;
      await registrarEmpresaAutorizada(resultado.usuario.uid, resultado.perfil.empresaId ?? EMPRESA_ID);
      setEmail(resultado.usuario.email ?? '');
      setSenha('');
      onAutorizado();
    } catch (erro: any) {
      Alert.alert('Conta não autorizada', erro?.message ?? 'Verifique o acesso Google e a autorização administrativa.');
    } finally { setOcupado(false); }
  };

  const entrarComBiometria = async () => {
    if (ocupado) return;
    setOcupado(true);
    try {
      const registro = await obterAcessoBiometrico('estetica');
      if (!registro) {
        if (email.trim() && senha) {
          setOcupado(false);
          await entrarComSenha(true);
        } else {
          Alert.alert('Primeiro acesso com senha',
            `Para ativar ${nomeBio}, informe o e-mail e a senha da estética nesta tela e toque novamente em "Entrar com ${nomeBio}".`);
        }
        return;
      }
      if (email.trim() && email.trim().toLowerCase() !== registro.email) {
        throw new Error('A biometria está vinculada a outra conta. Entre com a senha da estética.');
      }
      if (!await autenticarNoAparelho('Entrar na Estética')) return;
      const { user, perfil } = await sessaoOffline('estetica');
      if (user.uid !== registro.uid || perfil.ativo !== true) {
        throw new Error('A sessão da estética não corresponde à conta cadastrada. Entre com a senha.');
      }
      await registrarEmpresaAutorizada(user.uid, perfil.empresaId ?? EMPRESA_ID);
      await limparBloqueioBiometrico();
      onAutorizado();
    } catch (erro: any) {
      Alert.alert('Acesso biométrico indisponível', erro?.message ?? 'Use sua senha para entrar.');
    } finally { setOcupado(false); }
  };

  return <SafeAreaView style={s.root}><NeonBackdrop />
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={s.body} keyboardShouldPersistTaps="handled">
        <View style={{ alignItems: 'center', marginBottom: 9 }}><BrandLogo width={224} height={172}/><Text style={{ color: themeColor('#43DEFF'), fontSize: 9, fontWeight: '900', letterSpacing: 2, marginTop: -13 }}>ESTÉTICA AUTOMOTIVA PREMIUM</Text></View>
        <Text style={s.title}>Acesso da Estética</Text>
        <Text style={s.desc}>Entre na área administrativa para gerenciar sua agenda, seus clientes e a operação da estética.</Text>
        <Text style={s.label}>E-mail</Text>
        <TextInput style={s.input} value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" autoComplete="email" placeholder="seu@email.com" placeholderTextColor={themeColor("#9EBDD3")} />
        <Text style={s.label}>Senha</Text>
        <TextInput style={s.input} value={senha} onChangeText={setSenha} secureTextEntry placeholder="Sua senha" placeholderTextColor={themeColor("#9EBDD3")} />
        <TouchableOpacity disabled={ocupado} style={s.button} onPress={() => { void entrarComSenha(); }} accessibilityRole="button">
          {ocupado ? <ActivityIndicator color="#03060D" /> : <Text style={s.buttonText}>Entrar com senha</Text>}
        </TouchableOpacity>
        <TouchableOpacity disabled={ocupado} style={[s.googleButton, { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#DADCE0' }]} onPress={() => { void entrarComGoogle(); }} accessibilityRole="button">
          <Text style={[s.googleText, { color: '#202124' }]}><Text style={{color:themeColor('#4285F4'),fontWeight:'900'}}>G</Text>   Entrar com Google</Text>
        </TouchableOpacity>
        <TouchableOpacity disabled={ocupado} style={s.bioButton} onPress={() => { void entrarComBiometria(); }} accessibilityRole="button">
          <Text style={s.bioText}>◉  Entrar com {nomeBio}</Text>
        </TouchableOpacity>
        <Text style={s.note}>A Conta Google precisa estar autorizada como estética no Firebase. O primeiro login exige internet; sessões já validadas podem ser reabertas offline.</Text>
        <TouchableOpacity onPress={onVoltar} style={s.back}><Text style={s.backText}>← Voltar para escolher acesso</Text></TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  </SafeAreaView>;
}

const s = createThemedStyles({
  root: { flex: 1, backgroundColor: themeColor('#03060D') },
  body: { flexGrow: 1, justifyContent: 'center', padding: 24, maxWidth: 530, alignSelf: 'center', width: '100%' },
  title: { fontSize: 25, fontWeight: '900', color: themeColor('#FFFFFF'), textAlign: 'center', marginBottom: 12 },
  desc: { color: themeColor('#9EBDD3'), textAlign: 'center', marginBottom: 30 },
  label: { color: themeColor('#FFFFFF'), fontWeight: '700', marginBottom: 8 },
  input: {backgroundColor: themeColor('#081828'), color: themeColor('#FFFFFF'), borderWidth: 1, borderColor: themeColor('#164463'), borderRadius: 14, paddingHorizontal: 15, minHeight: 52, marginBottom: 18},
  button: {backgroundColor: themeColor('#067EEB'), padding: 16, borderRadius: 16, alignItems: 'center', borderWidth: 1, borderColor: themeColor('#43DEFF'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.35, shadowRadius: 12, shadowOffset: {width:0,height:3}, elevation: 6},
  buttonText: { fontWeight: '900', color: themeColor('#FFFFFF') },
  googleButton: { backgroundColor:themeColor('#FFFFFF'),padding:16,borderRadius:12,alignItems:'center',marginTop:12 },
  googleText: { color:themeColor('#202124'),fontWeight:'900' },
  bioButton: {backgroundColor: themeColor('#081828'), borderWidth: 1, borderColor: themeColor('#148DD2'), padding: 16, borderRadius: 15, alignItems: 'center', marginTop: 12},
  bioText: { color: themeColor('#FFFFFF'), fontWeight: '800' },
  note: { color: themeColor('#9EBDD3'), textAlign: 'center', fontSize: 12, marginTop: 18, lineHeight: 18 },
  back: { marginTop: 28, borderWidth: 1, borderColor: themeColor('#00B9FF'), borderRadius: 12, padding: 15, alignItems: 'center' },
  backText: { color: themeColor('#00B9FF'), fontWeight: '700' },
});
