import { createThemedStyles, themeColor, themeStatusBar } from '../ui/theme';
import { NeonBackdrop } from '../ui/neon';
import { useMicrophonePermissions } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import { SERVICOS_EXTRAS, SERVICOS_PRINCIPAIS, formatarPreco, calcularTotal, precoServicoPrincipal, servicoPrincipalValido } from '../services/servicosExtras';
import { useRef, useState } from 'react';
import { Alert, Image, KeyboardAvoidingView, Platform, ScrollView, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import type { TextInputInstance } from 'react-native';
import { parse, isValid, isBefore, startOfDay } from 'date-fns';
import { Agendamento } from '../services/types';
import { verificarDisponibilidade } from '../services/disponibilidade';
import PlacaCamera from '../components/camera/PlacaCamera';
import CalendarioAgendamento from '../components/CalendarioAgendamento';

interface AgendamentoFormProps {
  onAgendamento: (novoAgendamento: Agendamento) => void;
  agendamentos: Agendamento[];
  onVoltar: () => void;
  onLogout: () => void;
  tipoInicial?: string;
}

const PLACA_REGEX = /^[A-Z]{3}(?:[0-9]{4}|[0-9][A-Z][0-9]{2})$/;
const HORA_REGEX = /^(?:[01]\d|2[0-3]):[0-5]\d$/;

function formatarData(texto: string) {
  const digits = texto.replace(/\D/g, '').slice(0, 8);
  if (digits.length <= 2) return digits;
  if (digits.length <= 4) return `${digits.slice(0, 2)}/${digits.slice(2)}`;
  return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}`;
}

function formatarHora(texto: string) {
  const digits = texto.replace(/\D/g, '').slice(0, 4);
  if (digits.length <= 2) return digits;
  return `${digits.slice(0, 2)}:${digits.slice(2)}`;
}

export default function AgendamentoForm({ agendamentos, onAgendamento, onVoltar, onLogout, tipoInicial = '' }: AgendamentoFormProps) {
  const [placa, setPlaca] = useState('');
  const [data, setData] = useState('');
  const [horario, setHorario] = useState('');
  const [tipoLavagem, setTipoLavagem] = useState(tipoInicial);
  const [listaTiposAberta, setListaTiposAberta] = useState(false);
  const [cameraAberta, setCameraAberta] = useState(false);
  const [fotoPlaca, setFotoPlaca] = useState<string | null>(null);
  const placaInputRef = useRef<TextInputInstance>(null);
  const [, solicitarPermissaoMicrofone] = useMicrophonePermissions();
  const [servicosExtras, setServicosExtras] = useState<string[]>([]);
  const [midiaVeiculo, setMidiaVeiculo] = useState<string | undefined>(undefined);
  const [tipoMidiaVeiculo, setTipoMidiaVeiculo] = useState<'foto' | 'video' | undefined>(undefined);
  const selecionarMidia = async (tipo: 'foto' | 'video') => {
    try {
      const permissao = await ImagePicker.requestCameraPermissionsAsync();
      if (!permissao.granted) { Alert.alert('Permissão necessária', 'Autorize a câmera nas configurações do celular.'); return; }
      if (tipo === 'video') {
        const microfone = await solicitarPermissaoMicrofone();
        if (!microfone.granted) { Alert.alert('Permissão necessária', 'Autorize o microfone para gravar vídeo.'); return; }
      }
      const resultado = await ImagePicker.launchCameraAsync({
        mediaTypes: tipo === 'video' ? ['videos'] : ['images'],
        quality: 0.7, videoMaxDuration: 30,
      });
      if (!resultado.canceled && resultado.assets[0]?.uri) {
        setMidiaVeiculo(resultado.assets[0].uri);
        setTipoMidiaVeiculo(tipo);
      }
    } catch { Alert.alert('Câmera indisponível', 'Não foi possível abrir a câmera neste dispositivo.'); }
  };
  const alternarExtra = (id: string) => setServicosExtras(atual => atual.includes(id) ? atual.filter(item => item !== id) : [...atual, id]);


  const disponibilidade = verificarDisponibilidade(data, horario, agendamentos);

  const handleLogout = () => {
    Alert.alert('Sair do aplicativo', 'Deseja realmente sair?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Sair', style: 'destructive', onPress: onLogout },
    ]);
  };

  const handleAgendar = () => {
    const placaNormalizada = placa.trim().toUpperCase();
    const dataNormalizada = data.trim();
    const horarioNormalizado = horario.trim();
    const tipoNormalizado = tipoLavagem.trim();

    if (!PLACA_REGEX.test(placaNormalizada)) {
      Alert.alert('Placa inválida', 'Use o formato ABC1D23 ou ABC1234.'); return;
    }
    const dataConvertida = parse(dataNormalizada, 'dd/MM/yyyy', new Date());
    if (!isValid(dataConvertida) || dataNormalizada.length !== 10) {
      Alert.alert('Data inválida', 'Informe a data no formato DD/MM/AAAA.'); return;
    }
    if (isBefore(startOfDay(dataConvertida), startOfDay(new Date()))) {
      Alert.alert('Data inválida', 'Escolha hoje ou uma data futura.'); return;
    }
    if (!HORA_REGEX.test(horarioNormalizado)) {
      Alert.alert('Horário inválido', 'Informe o horário no formato HH:MM.'); return;
    }
    const [hora, minuto] = horarioNormalizado.split(':').map(Number);
    const totalMinutos = hora * 60 + minuto;
    if (totalMinutos < 600 || totalMinutos >= 1080 || (totalMinutos >= 720 && totalMinutos < 780)) {
      Alert.alert('Horário indisponível', 'O atendimento funciona das 10:00 às 18:00, com pausa das 12:00 às 13:00.'); return;
    }
    if (!servicoPrincipalValido(tipoNormalizado)) {
      Alert.alert('Serviço inválido', 'Escolha um dos serviços principais disponíveis.'); return;
    }
    const disponibilidadeAtual = verificarDisponibilidade(dataNormalizada, horarioNormalizado, agendamentos);
    if (!disponibilidadeAtual.disponivel) {
      Alert.alert('Horário indisponível', disponibilidadeAtual.mensagem); return;
    }
    onAgendamento({ id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, placa: placaNormalizada, data: dataNormalizada, horario: horarioNormalizado, tipoLavagem: tipoNormalizado, fotoPlaca: fotoPlaca ?? undefined, servicosExtras, midiaVeiculo, tipoMidiaVeiculo });
  };

  return (
    <SafeAreaView style={styles.safeArea}><NeonBackdrop />
      <StatusBar barStyle={themeStatusBar()} />
      <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.header}>
          <Text style={styles.title}>Novo agendamento</Text>
        </View>

        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
        <Text style={styles.label}>Placa</Text>
        <View style={styles.plateOptions}>
          <TouchableOpacity style={[styles.plateOption, styles.plateOptionActive]} onPress={() => placaInputRef.current?.focus()} accessibilityRole="button">
            <Text style={styles.plateOptionText}>✍️ Digitar placa</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.plateOption} onPress={() => setCameraAberta(true)} accessibilityRole="button">
            <Text style={styles.plateOptionText}>📷 Fotografar placa</Text>
          </TouchableOpacity>
        </View>
        <TextInput ref={placaInputRef} style={styles.input} value={placa} onChangeText={setPlaca} placeholder="ABC1D23" placeholderTextColor={themeColor("#688CA7")} autoCapitalize="characters" maxLength={7} />
        {fotoPlaca && (
          <View style={styles.photoCard}>
            <Image source={{ uri: fotoPlaca }} style={styles.photoThumb} resizeMode="cover" />
            <View style={styles.photoInfo}>
              <Text style={styles.photoTitle}>Foto da placa adicionada</Text>
              <Text style={styles.photoText}>A foto será vinculada a este agendamento.</Text>
              <TouchableOpacity onPress={() => setCameraAberta(true)} accessibilityRole="button">
                <Text style={styles.photoAction}>Tirar outra foto</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
        <Text style={styles.label}>Data</Text>
        <CalendarioAgendamento valor={data} onChange={setData} />
        <Text style={styles.label}>Horário</Text>
        <TextInput style={styles.input} value={horario} onChangeText={(text) => setHorario(formatarHora(text))} placeholder="HH:MM" placeholderTextColor={themeColor("#688CA7")} keyboardType="number-pad" maxLength={5} />

        {data.length === 10 && horario.length === 5 && (
          <View style={[styles.availabilityCard, disponibilidade.disponivel ? styles.availabilityAvailable : styles.availabilityUnavailable]}>
            <Text style={styles.availabilityIcon}>{disponibilidade.disponivel ? '✓' : '!'}</Text>
            <View style={styles.availabilityInfo}>
              <Text style={[styles.availabilityTitle, disponibilidade.disponivel ? styles.availableText : styles.unavailableText]}>
                {disponibilidade.disponivel ? 'Horário disponível' : 'Horário indisponível'}
              </Text>
              <Text style={styles.availabilityMessage}>{disponibilidade.mensagem}</Text>
            </View>
          </View>
        )}
        <Text style={styles.label}>Serviço principal</Text>
        <TouchableOpacity
          style={styles.select}
          onPress={() => setListaTiposAberta((aberta) => !aberta)}
          accessibilityRole="button"
          accessibilityLabel="Selecionar serviço principal"
          accessibilityState={{ expanded: listaTiposAberta }}
        >
          <Text style={[styles.selectText, !tipoLavagem && styles.placeholderText]}>
            {tipoLavagem ? `${tipoLavagem} — ${formatarPreco(precoServicoPrincipal(tipoLavagem))}` : 'Selecione o serviço principal'}
          </Text>
          <Text style={styles.selectArrow}>{listaTiposAberta ? '▲' : '▼'}</Text>
        </TouchableOpacity>

        {listaTiposAberta && (
          <View style={styles.optionsList}>
            {SERVICOS_PRINCIPAIS.map((servico) => (
              <TouchableOpacity
                key={servico.id}
                style={styles.option}
                onPress={() => {
                  setTipoLavagem(servico.titulo);
                  setListaTiposAberta(false);
                }}
                accessibilityRole="button"
              >
                <Text style={styles.optionText}>{servico.titulo} — {formatarPreco(servico.preco)}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        <View style={extraStyles.section}>
          <Text style={extraStyles.heading}>✨ Serviços adicionais</Text>
          <Text style={extraStyles.hint}>Escolha os complementos desejados para o serviço principal. O valor total é calculado automaticamente.</Text>
          {SERVICOS_EXTRAS.map(servico => {
            const selecionado = servicosExtras.includes(servico.id);
            return <TouchableOpacity key={servico.id} accessibilityRole="checkbox" accessibilityState={{ checked: selecionado }} onPress={() => alternarExtra(servico.id)} style={[extraStyles.extraCard, selecionado && extraStyles.extraSelected]}>
              <Text style={extraStyles.emoji}>{servico.icone}</Text>
              <View style={{ flex: 1 }}><Text style={extraStyles.extraTitle}>{servico.titulo}</Text><Text style={extraStyles.hint}>{servico.descricao}</Text><Text style={{color:themeColor("#4DDBFF"),fontWeight:"800"}}>💰 {formatarPreco(servico.preco)}</Text></View>
              <Text style={extraStyles.check}>{selecionado ? '☑' : '□'}</Text>
            </TouchableOpacity>;
          })}
        </View>
        <View style={extraStyles.section}><Text style={[extraStyles.heading,{color:themeColor("#4DDBFF")}]}>💰 Total estimado: {formatarPreco(calcularTotal(tipoLavagem,servicosExtras))}</Text><Text style={extraStyles.hint}>Valor calculado com base no serviço principal e nos complementos selecionados.</Text></View>
        <View style={extraStyles.section}>
          <Text style={extraStyles.heading}>📷 Estado de sujeira do veículo</Text>
          <Text style={extraStyles.hint}>Envie uma foto ou um vídeo de até 30 segundos para mostrar como está o carro.</Text>
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 12 }}>
            <TouchableOpacity style={extraStyles.mediaButton} onPress={() => selecionarMidia('foto')}><Text style={extraStyles.mediaText}>📸 Tirar foto</Text></TouchableOpacity>
            <TouchableOpacity style={extraStyles.mediaButton} onPress={() => selecionarMidia('video')}><Text style={extraStyles.mediaText}>🎥 Gravar vídeo</Text></TouchableOpacity>
          </View>
          {midiaVeiculo && <View style={{ marginTop: 12 }}>
            {tipoMidiaVeiculo === 'foto' ? <Image source={{ uri: midiaVeiculo }} style={{ width: '100%', height: 170, borderRadius: 12 }} /> : <Text style={extraStyles.hint}>🎬 Vídeo gravado e anexado ao agendamento.</Text>}
            <TouchableOpacity onPress={() => { setMidiaVeiculo(undefined); setTipoMidiaVeiculo(undefined); }}><Text style={{ color: themeColor('#FCA5A5'), marginTop: 10, fontWeight: '700' }}>Remover mídia</Text></TouchableOpacity>
          </View>}
        </View>
        <TouchableOpacity style={styles.primaryButton} onPress={handleAgendar} accessibilityRole="button">
          <Text style={styles.primaryText}>Confirmar agendamento</Text>
        </TouchableOpacity>
      </ScrollView>

      <PlacaCamera visible={cameraAberta} onClose={() => setCameraAberta(false)} onPhotoTaken={setFotoPlaca} />

        <View style={styles.bottomBar}>
          <TouchableOpacity style={styles.backButton} onPress={onVoltar} accessibilityRole="button">
            <Text style={styles.backText}>Voltar</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.logoutButton} onPress={handleLogout} accessibilityRole="button">
            <Text style={styles.logoutText}>Sair</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = createThemedStyles({
  safeArea: { flex: 1, backgroundColor: themeColor('#03060D') },
  container: { flex: 1, backgroundColor: 'transparent' },
  scroll: { flex: 1 },
  header: {
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 72,
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 14,
    backgroundColor: themeColor('#03060D'),
    borderBottomWidth: 1,
    borderBottomColor: themeColor('#164463'),
  },
  content: { width: '100%', maxWidth: 620, alignSelf: 'center', paddingHorizontal: 18, paddingTop: 18, paddingBottom: 32 },
  title: { color: themeColor('#ffffff'), fontSize: 23, fontWeight: '800', textAlign: 'center', width: '100%' },
  label: { color: themeColor('#ffffff'), fontSize: 16, marginBottom: 6 },
  plateOptions: { flexDirection: 'row', gap: 10, marginBottom: 10 },
  plateOption: { flex: 1, backgroundColor: themeColor('#102439'), paddingVertical: 12, borderRadius: 13, alignItems: 'center', borderWidth: 1, borderColor: themeColor('#444444') },
  plateOptionActive: { borderColor: themeColor('#00B9FF') },
  plateOptionText: { color: themeColor('#ffffff'), fontSize: 14, fontWeight: '700' },
  input: {height: 50, borderWidth: 1, borderColor: themeColor('#164463'), borderRadius: 14, paddingHorizontal: 14, color: themeColor('#ffffff'), backgroundColor: themeColor('#081828'), marginBottom: 16, fontSize: 16},
  select: {minHeight: 50, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderWidth: 1, borderColor: themeColor('#164463'), borderRadius: 14, paddingHorizontal: 14, backgroundColor: themeColor('#081828')},
  selectText: { color: themeColor('#ffffff'), fontSize: 16 },
  placeholderText: { color: themeColor('#688CA7') },
  selectArrow: { color: themeColor('#00B9FF'), fontSize: 14, fontWeight: '800', marginLeft: 12 },
  optionsList: { marginTop: 5, marginBottom: 16, borderWidth: 1, borderColor: themeColor('#164463'), borderRadius: 13, overflow: 'hidden', backgroundColor: themeColor('#0A111E') },
  option: { minHeight: 50, justifyContent: 'center', paddingHorizontal: 14, borderBottomWidth: 1, borderBottomColor: themeColor('#2a2a2a') },
  optionText: { color: themeColor('#ffffff'), fontSize: 16, fontWeight: '600' },
  photoCard: {flexDirection: 'row', backgroundColor: themeColor('#0A111E'), borderWidth: 1, borderColor: themeColor('#164463'), borderRadius: 20, padding: 10, marginBottom: 15, shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},
  photoThumb: { width: 92, height: 64, borderRadius: 7, backgroundColor: themeColor('#03060D') },
  photoInfo: { flex: 1, marginLeft: 10, justifyContent: 'center' },
  photoTitle: { color: themeColor('#ffffff'), fontWeight: '700', marginBottom: 4 },
  photoText: { color: themeColor('#888888'), fontSize: 12, lineHeight: 17, marginBottom: 5 },
  photoAction: { color: themeColor('#00B9FF'), fontWeight: '700', fontSize: 13 },
  availabilityCard: { flexDirection: 'row', alignItems: 'center', borderRadius: 13, padding: 12, marginTop: -6, marginBottom: 16, borderWidth: 1 },
  availabilityAvailable: { backgroundColor: themeColor('#102C27'), borderColor: themeColor('#267956') },
  availabilityUnavailable: { backgroundColor: themeColor('#2a1111'), borderColor: themeColor('#8a3030') },
  availabilityIcon: { width: 28, height: 28, borderRadius: 14, backgroundColor: themeColor('#111111'), color: themeColor('#ffffff'), textAlign: 'center', textAlignVertical: 'center', fontSize: 18, fontWeight: '800', marginRight: 10 },
  availabilityInfo: { flex: 1 },
  availabilityTitle: { fontSize: 15, fontWeight: '800', marginBottom: 2 },
  availableText: { color: themeColor('#51E0A5') },
  unavailableText: { color: themeColor('#ff7777') },
  availabilityMessage: { color: themeColor('#dddddd'), fontSize: 13, lineHeight: 18 },
  primaryButton: {backgroundColor: themeColor('#067EEB'), paddingVertical: 15, borderRadius: 16, alignItems: 'center', marginTop: 8, borderWidth: 1, borderColor: themeColor('#43DEFF'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.35, shadowRadius: 12, shadowOffset: {width:0,height:3}, elevation: 6},
  primaryText: { color: themeColor('#ffffff'), fontSize: 16, fontWeight: '700' },
  bottomBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 10, paddingBottom: 16, backgroundColor: themeColor('#03060D'), borderTopWidth: 1, borderTopColor: themeColor('#164463') },
  backButton: {flex: 1, marginRight: 8, backgroundColor: themeColor('#081828'), paddingVertical: 13, borderRadius: 15, alignItems: 'center', borderWidth: 1, borderColor: themeColor('#148DD2')},
  backText: { color: themeColor('#ffffff'), fontWeight: '700' },
  logoutButton: { flex: 1, marginLeft: 8, backgroundColor: themeColor('#a00000'), paddingVertical: 13, borderRadius: 13, alignItems: 'center' },
  logoutText: { color: themeColor('#ffffff'), fontWeight: '700' },
});

const extraStyles = createThemedStyles({
  section: {backgroundColor: themeColor('#0E1929'), borderRadius: 20, padding: 16, marginTop: 22, marginBottom: 8, borderWidth: 1, borderColor: themeColor('#164463'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},
  heading: { color: themeColor('#FFFFFF'), fontSize: 19, fontWeight: '800', marginBottom: 7 },
  hint: { color: themeColor('#9EBDD3'), fontSize: 12, lineHeight: 18 },
  extraCard: {flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: themeColor('#102439'), padding: 12, borderRadius: 20, marginTop: 9, borderWidth: 1, borderColor: themeColor('#164463'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},
  extraSelected: { borderColor: themeColor('#00B9FF'), backgroundColor: themeColor('#153D49') },
  emoji: { fontSize: 23 }, extraTitle: { color: themeColor('#FFFFFF'), fontWeight: '700', fontSize: 14 }, check: { color: themeColor('#43DEFF'), fontSize: 25 },
  mediaButton: {flex: 1, backgroundColor: themeColor('#067EEB'), paddingVertical: 14, borderRadius: 16, alignItems: 'center', borderWidth: 1, borderColor: themeColor('#43DEFF'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.35, shadowRadius: 12, shadowOffset: {width:0,height:3}, elevation: 6},
  mediaText: { color: themeColor('#FFFFFF'), fontWeight: '800', fontSize: 13 },
});
