import { createThemedStyles, themeColor, themeStatusBar, themedPalette } from '../ui/theme';
import { NeonBackdrop } from '../ui/neon';
import { ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { SERVICOS_POLIMENTO, formatarPreco } from '../services/servicosExtras';

const cor = themedPalette({ fundo: '#03060D', painel: '#0A111E', linha: '#164463', ciano: '#00B9FF', ouro: '#4DDBFF', texto: '#FFFFFF', suave: '#9EBDD3' });

export default function ServicosPolimentos({ onVoltar, onAgendar }: { onVoltar: () => void; onAgendar: (servico: string) => void }) {
  return <SafeAreaView style={s.safe}><NeonBackdrop />
    <StatusBar barStyle={themeStatusBar()} />
    <ScrollView contentContainerStyle={s.conteudo}>
      <View style={s.cabecalho}>
        <TouchableOpacity accessibilityRole="button" accessibilityLabel="Voltar" onPress={onVoltar}><Text style={s.voltar}>‹</Text></TouchableOpacity>
        <Text style={s.titulo}>Serviços de Polimentos</Text><View style={{ width: 30 }} />
      </View>
      <Text style={s.intro}>Tratamentos para revitalizar, valorizar e proteger a pintura do seu veículo. Conheça as opções e escolha o serviço mais adequado.</Text>
      {SERVICOS_POLIMENTO.map(item => <View key={item.id} style={s.cartao}>
        <View style={s.linhaTitulo}><View style={s.icone}><Text style={{ fontSize: 29 }}>{item.icone}</Text></View>
          <View style={{ flex: 1 }}><Text style={s.nome}>{item.titulo}</Text><Text style={s.preco}>{formatarPreco(item.preco)}</Text></View>
        </View>
        <Text style={s.descricao}>{item.descricao}</Text>
        {item.detalhes.map(detalhe => <View key={detalhe} style={s.detalhe}><Text style={s.marcador}>✓</Text><Text style={s.detalheTexto}>{detalhe}</Text></View>)}
        <Text style={s.observacao}>{item.observacao}</Text>
        <TouchableOpacity accessibilityRole="button" onPress={() => onAgendar(item.titulo)} style={s.botao}>
          <Text style={s.botaoTexto}>Agendar {item.titulo}  →</Text>
        </TouchableOpacity>
      </View>)}
      <Text style={s.rodape}>Os resultados variam conforme o estado da pintura. Antes do serviço, a equipe poderá avaliar o veículo para orientar a escolha do tratamento.</Text>
    </ScrollView>
  </SafeAreaView>;
}
const s = createThemedStyles({
  safe:{flex:1,backgroundColor:cor.fundo},conteudo:{padding:18,paddingBottom:50},
  cabecalho:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:15},voltar:{fontSize:36,color:cor.texto,width:30},titulo:{color:cor.texto,fontWeight:'900',fontSize:19},
  intro:{color:cor.suave,fontSize:14,lineHeight:22,marginBottom:18},cartao:{borderWidth: 1, borderColor: themeColor('#164463'), backgroundColor: cor.painel, borderRadius: 20, padding: 17, marginBottom: 16, shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},
  linhaTitulo:{flexDirection:'row',alignItems:'center',gap:13,marginBottom:14},icone:{backgroundColor:themeColor('#102439'),height:58,width:58,borderRadius:14,alignItems:'center',justifyContent:'center'},
  nome:{color:cor.texto,fontSize:19,fontWeight:'900'},preco:{fontSize:23,color:cor.ouro,fontWeight:'900',marginTop:4},
  descricao:{color:cor.texto,fontSize:13,lineHeight:21,marginBottom:12},detalhe:{flexDirection:'row',alignItems:'flex-start',marginBottom:9},marcador:{color:cor.ciano,fontSize:16,fontWeight:'900',marginRight:10},
  detalheTexto:{flex:1,color:cor.suave,fontSize:12,lineHeight:19},observacao:{color:themeColor('#9EBDD3'),fontSize:11,lineHeight:17,marginTop:8,fontStyle:'italic'},
  botao:{padding: 15, backgroundColor: themeColor('#067EEB'), borderRadius: 16, marginTop: 16, borderWidth: 1, borderColor: themeColor('#43DEFF'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.35, shadowRadius: 12, shadowOffset: {width:0,height:3}, elevation: 6},botaoTexto:{textAlign:'center',color:cor.fundo,fontWeight:'900',fontSize:13},
  rodape:{color:cor.suave,fontSize:12,textAlign:'center',lineHeight:19,marginTop:8},
});
