import { createThemedStyles, themeColor, themeStatusBar } from '../ui/theme';
import { NeonBackdrop } from '../ui/neon';
import {ScrollView,StatusBar,StyleSheet,Text,TouchableOpacity,View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {Agendamento} from '../services/types';
export default function CartaoFidelidade({onVoltar,agendamentos}:{onVoltar:()=>void;agendamentos:Agendamento[]}) {
 const concluidas=agendamentos.filter(a=>['pronto','concluido','concluida'].includes(String(a.status??'').toLowerCase())).length;
 const progresso=concluidas%5;
 const recompensas=Math.floor(concluidas/5);
 return <SafeAreaView style={st.safe}><NeonBackdrop /><StatusBar barStyle={themeStatusBar()}/><ScrollView contentContainerStyle={st.content}>
 <View style={st.header}><TouchableOpacity onPress={onVoltar}><Text style={st.back}>‹</Text></TouchableOpacity><Text style={st.title}>Cartão Fidelidade</Text><View style={{width:26}}/></View>
 <View style={st.card}><Text style={st.gold}>★ ESTETICAR FIDELIDADE</Text><Text style={st.big}>5 lavagens = 1 grátis</Text><Text style={st.desc}>Acompanhe suas lavagens concluídas e seu progresso.</Text>
 <View style={st.stamps}>{[1,2,3,4,5].map(n=><View key={n} style={[st.stamp,n<=progresso&&st.done]}><Text style={{fontSize:24,color:n<=progresso?'#03060D':'#9EBDD3'}}>{n<=progresso?'✓':'★'}</Text></View>)}</View>
 <Text style={st.counter}>{progresso} de 5 para a próxima recompensa</Text>
 <Text style={st.desc}>Lavagens concluídas: {concluidas}</Text>
 <Text style={st.gold}>Recompensas conquistadas: {recompensas}</Text></View>
 <Text style={st.info}>A lavagem gratuita é uma Lavagem Simples, sem serviços extras. A utilização da recompensa precisa ser confirmada pela estética. Este cartão mostra o progresso, mas ainda não realiza resgate ou desconto automático.</Text>
 </ScrollView></SafeAreaView>;
}
const st=createThemedStyles({safe:{flex:1,backgroundColor:themeColor('#03060D')},content:{padding:17},header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginBottom:22},back:{color:themeColor('#fff'),fontSize:35,width:26},title:{color:themeColor('#fff'),fontWeight:'900',fontSize:19},card:{backgroundColor: themeColor('#0A111E'), borderRadius: 20, borderWidth: 1, borderColor: themeColor('#164463'), padding: 20, shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},gold:{color:themeColor('#4DDBFF'),fontWeight:'900',fontSize:15,marginBottom:12},big:{color:themeColor('#fff'),fontSize:24,fontWeight:'900',marginBottom:10},desc:{color:themeColor('#9EBDD3'),fontSize:13,marginBottom:15},stamps:{flexDirection:'row',justifyContent:'space-between',marginVertical:18},stamp:{width:48,height:48,borderRadius:12,borderWidth:1,borderColor:themeColor('#376A7A'),alignItems:'center',justifyContent:'center'},done:{backgroundColor:themeColor('#00B9FF')},counter:{color:themeColor('#fff'),fontWeight:'800',marginBottom:12},info:{color: themeColor('#9EBDD3'), fontSize: 13, lineHeight: 21, marginTop: 20, borderRadius: 20, borderWidth: 1, borderColor: themeColor('#164463'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5}});
