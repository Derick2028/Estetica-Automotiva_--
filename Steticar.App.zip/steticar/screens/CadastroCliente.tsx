import { createThemedStyles, themeColor, themeStatusBar } from '../ui/theme';
import { NeonBackdrop, BrandLogo } from '../ui/neon';
import { cadastrarClienteFirebase } from '../services/firebase/autenticacao';
import { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import { criarCliente, buscarClientePorCelular, buscarClientePorEmail } from '../services/database';
import { autenticarNoAparelho, salvarClienteBiometria, limparBloqueioBiometrico, nomeBiometria } from '../servicos/segurancaUsuario';
import { salvarCredenciaisCliente } from '../servicos/credenciaisSalvas';
import ConsultaCep from '../components/ConsultaCep';

interface Props {
  onCadastroConcluido: (id: number) => void;
  onVoltar: () => void;
}

function formatarCelular(texto: string) {
  const digits = texto.replace(/\D/g, '').slice(0, 11);
  if (digits.length <= 2) return digits.length ? `(${digits}` : '';
  if (digits.length <= 7) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
  return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
}

export default function CadastroCliente({ onCadastroConcluido, onVoltar }: Props) {
  const [nome, setNome] = useState('');
  const [email,setEmail]=useState('');
  const [fotoPerfil,setFotoPerfil]=useState<string|null>(null);
  const escolherFoto=async()=>{const p=await ImagePicker.requestMediaLibraryPermissionsAsync();if(!p.granted)return Alert.alert('Permissão necessária','Autorize o acesso às fotos.');const r=await ImagePicker.launchImageLibraryAsync({mediaTypes:['images'],allowsEditing:true,aspect:[1,1],quality:.7});if(!r.canceled)setFotoPerfil(r.assets[0].uri);};
  const [celular, setCelular] = useState('');
  const [endereco, setEndereco] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');
  const [salvando, setSalvando] = useState(false);

  const cadastrar = async () => {
    if (salvando) return;
    const nomeFinal = nome.trim();
    const celularFinal = celular.replace(/\D/g, '');
    const enderecoFinal = endereco.trim();

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return Alert.alert('E-mail inválido','Informe um e-mail válido.');
    if (nomeFinal.length < 3) return Alert.alert('Nome inválido', 'Informe seu nome completo.');
    if (celularFinal.length < 10 || celularFinal.length > 11) return Alert.alert('Celular inválido', 'Informe um número de celular válido.');
    if (enderecoFinal.length < 5) return Alert.alert('Endereço inválido', 'Informe seu endereço.');
    if (senha.length < 6) return Alert.alert('Senha inválida', 'Crie uma senha com pelo menos 6 caracteres.');
    if (senha !== confirmarSenha) return Alert.alert('Senhas diferentes', 'A confirmação da senha não confere.');

    setSalvando(true);
    try {
      if (await buscarClientePorEmail(email.trim().toLowerCase())) {
        Alert.alert('E-mail já cadastrado', 'Utilize outro e-mail ou entre na sua conta.');
        return;
      }
      if (await buscarClientePorCelular(celularFinal)) {
        Alert.alert('Cadastro já existe', 'Já existe um cadastro com este número de celular.');
        return;
      }

      await cadastrarClienteFirebase(email.trim(),senha,{nome:nomeFinal,telefone:celularFinal,endereco:enderecoFinal});
      const id = await criarCliente({ nome: nomeFinal, celular: celularFinal, endereco: enderecoFinal, placa: `CLIENTE-${Date.now()}-${Math.random().toString(36).slice(2,8)}`, foto_perfil: fotoPerfil, email:email.trim().toLowerCase() });
      const seguir = () => onCadastroConcluido(id);
      let tipoBio = 'biometria';
      try { tipoBio = await nomeBiometria(); } catch { /* mantém nome genérico */ }
      Alert.alert('Cadastro concluído', 'Deseja salvar seu acesso neste aparelho e ativar a ' + tipoBio + '? Na próxima vez, você poderá entrar sem digitar e-mail e senha.', [
        { text: 'Agora não', style: 'cancel', onPress: seguir },
        { text: 'Ativar e salvar acesso', onPress: () => { void (async () => {
          try {
            if (await autenticarNoAparelho('Ativar acesso rápido ao StetiCar')) {
              await salvarCredenciaisCliente(email, senha);
              await salvarClienteBiometria(id);
              await limparBloqueioBiometrico();
              Alert.alert('Acesso rápido ativado', 'Seu acesso foi salvo com segurança neste aparelho. Use a biometria na próxima entrada.');
            }
          } catch (erro: any) {
            Alert.alert('Não foi possível ativar', erro?.message ?? 'Você poderá ativar a biometria na tela de entrada.');
          } finally { seguir(); }
        })(); } },
      ], { cancelable: false });
    } catch (error: any) {
      Alert.alert('Erro no cadastro', error?.message || 'Não foi possível salvar seus dados.');
    } finally {
      setSalvando(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}><NeonBackdrop />
      <StatusBar barStyle={themeStatusBar()} />
      <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <View style={{ alignItems: 'center' }}><BrandLogo width={176} height={133}/></View>
          <Text style={styles.title}>Criar conta de cliente</Text>
          <Text style={styles.subtitle}>Seus dados, seus agendamentos e seu veículo bem cuidado.</Text>

          <Text style={styles.label}>👤  Nome completo</Text>
          <TextInput style={styles.input} value={nome} onChangeText={setNome} placeholder="Digite seu nome" placeholderTextColor={themeColor("#688CA7")} autoCapitalize="words" />

          <TouchableOpacity onPress={escolherFoto} style={{alignSelf:'center',alignItems:'center',marginBottom:20}}>{fotoPerfil?<Image source={{uri:fotoPerfil}} style={{width:90,height:90,borderRadius:45}}/>:<View style={{width:90,height:90,borderRadius:45,backgroundColor:themeColor('#222'),alignItems:'center',justifyContent:'center'}}><Text style={{color:themeColor('#fff')}}>Adicionar foto</Text></View>}<Text style={{color:themeColor('#00B9FF'),marginTop:8}}>Foto de perfil</Text></TouchableOpacity>
          <Text style={styles.label}>✉️  E-mail</Text>
          <TextInput style={styles.input} value={email} onChangeText={setEmail} placeholder="seuemail@exemplo.com" placeholderTextColor={themeColor("#688CA7")} keyboardType="email-address" autoCapitalize="none" />
          <Text style={styles.label}>📱  Número do celular</Text>
          <TextInput style={styles.input} value={celular} onChangeText={(v) => setCelular(formatarCelular(v))} placeholder="(00) 00000-0000" placeholderTextColor={themeColor("#688CA7")} keyboardType="phone-pad" maxLength={15} />

          <ConsultaCep enderecoAtual={endereco} aoPreencherEndereco={setEndereco} />
          <Text style={styles.label}>📍  Endereço (informe o número)</Text>
          <TextInput style={[styles.input, styles.multiline]} value={endereco} onChangeText={setEndereco} placeholder="Rua, número, bairro, cidade" placeholderTextColor={themeColor("#688CA7")} multiline />

          <Text style={styles.label}>🔒  Senha</Text>
          <TextInput style={styles.input} value={senha} onChangeText={setSenha} placeholder="Mínimo de 6 caracteres" placeholderTextColor={themeColor("#688CA7")} secureTextEntry />

          <Text style={styles.label}>🔐  Confirmar senha</Text>
          <TextInput style={styles.input} value={confirmarSenha} onChangeText={setConfirmarSenha} placeholder="Digite a senha novamente" placeholderTextColor={themeColor("#688CA7")} secureTextEntry />


          <View style={styles.info}>
            <Text style={styles.infoTitle}>🔐 Acesso biométrico</Text>
            <Text style={styles.infoText}>A impressão digital ou Face ID pode ser ativada na tela de entrada, depois de confirmar sua conta com a senha.</Text>
          </View>

          <TouchableOpacity style={styles.primary} onPress={cadastrar} disabled={salvando}>
            <Text style={styles.primaryText}>{salvando ? 'Salvando...' : 'Cadastrar meus dados'}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.secondary} onPress={onVoltar} disabled={salvando}>
            <Text style={styles.secondaryText}>Voltar</Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = createThemedStyles({
  safeArea: { flex: 1, backgroundColor: themeColor('#03060D') },
  container: { flex: 1, backgroundColor: 'transparent' },
  content: { padding: 22, paddingBottom: 40 },
  title: { color: themeColor('#fff'), fontSize: 28, fontWeight: '800', textAlign: 'center', marginTop: 18 },
  subtitle: { color: themeColor('#999'), textAlign: 'center', marginTop: 8, marginBottom: 28 },
  label: { color: themeColor('#fff'), fontSize: 15, fontWeight: '700', marginBottom: 7 },
  input: {backgroundColor: themeColor('#081828'), borderColor: themeColor('#164463'), borderWidth: 1, borderRadius: 14, minHeight: 50, paddingHorizontal: 14, color: themeColor('#fff'), fontSize: 16, marginBottom: 18},
  multiline: { minHeight: 86, paddingTop: 14, textAlignVertical: 'top' },
  info: {backgroundColor: themeColor('#0A111E'), borderColor: themeColor('#164463'), borderWidth: 1, borderRadius: 20, padding: 14, marginBottom: 18, shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},
  infoTitle: { color: themeColor('#fff'), fontWeight: '800', marginBottom: 5 },
  infoText: { color: themeColor('#bbb'), fontSize: 13, lineHeight: 19 },
  primary: {backgroundColor: themeColor('#067EEB'), borderColor: themeColor('#43DEFF'), borderWidth: 1, borderRadius: 16, paddingVertical: 15, alignItems: 'center', shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.35, shadowRadius: 12, shadowOffset: {width:0,height:3}, elevation: 6},
  primaryText: { color: themeColor('#fff'), fontSize: 16, fontWeight: '800' },
  secondary: {backgroundColor: themeColor('#081828'), borderRadius: 15, paddingVertical: 14, alignItems: 'center', marginTop: 10, borderWidth: 1, borderColor: themeColor('#148DD2')},
  secondaryText: { color: themeColor('#fff'), fontWeight: '700' },
});
