import ThemeToggle from '../ui/ThemeToggle';
import { createThemedStyles, themeColor } from '../ui/theme';
import { NeonBackdrop, BrandLogo } from '../ui/neon';
import { salvarCache, lerCacheEmpresa, registrarEmpresaAutorizada, empresaAutorizadaLocal, guardarStatusPendente, lerStatusPendentes, sincronizarStatusPendentes } from '../services/offlineAgenda';
import { observarAgendaDaEmpresa, EMPRESA_ID } from '../services/firebase/agendamentos';
import { firebaseServices } from '../services/firebase/config';
import { getDocFromServer, doc } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';
import {sessaoOffline} from '../services/firebase/sessaoOffline';
import {temInternet, observarConexao} from '../services/conexao';
import { SERVICOS_EXTRAS, calcularTotal, formatarPreco, precoServicoPrincipal } from '../services/servicosExtras';
import { useEffect, useState } from 'react';
import {AppState,Alert,ScrollView,StyleSheet,Text,TouchableOpacity,View,Linking} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {StatusLavagem} from '../services/database';

type Item={id:string;nome:string;celular:string;placa:string;data:string;horario:string;tipo_lavagem:string;status:StatusLavagem;foto_placa:string|null;servicos_extras:string|null;midia_veiculo:string|null;tipo_midia_veiculo:string|null;formaPagamento?:'pix'|'dinheiro'|'cartao_credito'|null};
export default function PainelProprietario({onVoltar,onSairCompleto}:{onVoltar:()=>void;onSairCompleto:()=>void}){
 const [lista,setLista]=useState<Item[]>([]);
 const [empresaAtual,setEmpresaAtual]=useState<string|null>(null);
 const [pendencias,setPendencias]=useState<Record<string,string>>({});
 const [mostrarHistorico,setMostrarHistorico]=useState(false);
 const [carregando,setCarregando]=useState(true);
 const [erroAgenda,setErroAgenda]=useState('');
 const [tentativa,setTentativa]=useState(0);
 useEffect(()=>{
  let ativo=true;
  let cancelar:(()=>void)|null=null;
  let conectando=false;
  let uid:string|null=null;
  let empresa:string|null=null;
  const converter=(a:any):Item=>({...a,
    data:a.data?.includes('-')?a.data.split('-').reverse().join('/'):a.data,
    tipo_lavagem:a.tipoLavagem??a.tipo_lavagem,
    servicos_extras:Array.isArray(a.servicosExtras)?JSON.stringify(a.servicosExtras):(a.servicos_extras??'[]'),
    foto_placa:a.foto_placa??null,midia_veiculo:a.midia_veiculo??null,tipo_midia_veiculo:a.tipo_midia_veiculo??null});
  const atualizarLocal=async()=>{
    if(!uid||!empresa)return;
    const [cache,pendentes]=await Promise.all([lerCacheEmpresa(empresa,uid),lerStatusPendentes(uid,empresa)]);
    if(!ativo)return;
    const atualizados=new Map(pendentes.filter(a=>!a.erro).map(a=>[a.id,a.status_novo]));
    setLista(cache.map(a=>({...converter(a),status:(atualizados.get(a.id)??a.status)})));
    setPendencias(Object.fromEntries(pendentes.map(a=>[a.id,a.erro??'Aguardando sincronização'])));
    setCarregando(false);
  };
  const sincronizar=()=>{
    if(!uid||!empresa||firebaseServices().auth.currentUser?.uid!==uid)return;
    sincronizarStatusPendentes(uid,empresa).then(atualizarLocal).catch(console.warn);
  };
  const conectar=async()=>{
    if(!uid||!empresa||cancelar||conectando)return;
    if(!await temInternet()){if(ativo)setErroAgenda('Sem internet no momento. Exibindo agendamentos salvos neste aparelho.');return;}
    const auth=firebaseServices().auth;
    await auth.authStateReady();
    const atual=auth.currentUser;
    if(!atual||atual.uid!==uid){
      if(ativo)setErroAgenda('A sessão do Firebase não está autenticada. Volte à entrada da Estética e faça login novamente com internet.');
      return;
    }
    conectando=true;
    try{
      const perfil=await getDocFromServer(doc(firebaseServices().db,'usuarios',uid));
      if(!perfil.exists()||perfil.data().tipo!=='estetica'||perfil.data().ativo!==true) {
        if(ativo)setErroAgenda('A conta precisa ter usuarios/{UID} com tipo "estetica" e ativo = true no Firestore.');
        return;
      }
      const empresaValidada=perfil.data().empresaId??EMPRESA_ID;
      await registrarEmpresaAutorizada(uid,empresaValidada);
      if(!ativo)return;
      if(empresa!==empresaValidada){empresa=empresaValidada;setEmpresaAtual(empresaValidada);await atualizarLocal();}
      cancelar=observarAgendaDaEmpresa(empresaValidada,async items=>{
        if(!ativo)return;
        try {await salvarCache(uid!,empresaValidada,items,'empresa');await atualizarLocal();if(ativo)setErroAgenda('');}
        catch(error){console.warn('Erro ao gravar a agenda local:',error);}
      },e=>{
        cancelar?.();cancelar=null; // Permite tentar novamente após falha do listener.
        if(!ativo)return;
        setErroAgenda((e as any).code==='permission-denied'
          ? 'Permissão negada pelo Firestore. Confira as regras publicadas, o campo empresaId do administrador e o filtro da agenda.'
          : (e as any).code==='unauthenticated'
          ? 'Sessão expirada. Faça login novamente na área da Estética.'
          : 'Não foi possível carregar a agenda online: '+e.message);
      });
      sincronizar();
    }catch(e:any){if(ativo)setErroAgenda(e?.code==='permission-denied'
      ? 'O Firebase negou a leitura do perfil administrativo. Verifique usuarios/{UID} e as regras publicadas.'
      : e?.code==='unavailable'
      ? 'Servidor indisponível. Exibindo a última agenda salva neste aparelho.'
      : 'Falha ao consultar a agenda online: '+(e?.message??'verifique a conexão e a sessão.'));}
    finally{conectando=false;}
  };
  const iniciar=async()=>{
    try{
      const sessao=await sessaoOffline('estetica');
      uid=sessao.user.uid;
      const empresaLocal=await empresaAutorizadaLocal(uid);
      const empresaValidada=empresaLocal ?? (sessao.perfil as {empresaId?:string|null}).empresaId ?? EMPRESA_ID;
      empresa=empresaValidada;
      if(!ativo)return;
      setEmpresaAtual(empresaValidada);
      // Upgrade de sessões antigas: autorização local já verificada no perfil.
      if(!empresaLocal) await registrarEmpresaAutorizada(uid,empresaValidada);
      await atualizarLocal();
      if(!await temInternet()) {if(ativo)setErroAgenda('Modo offline: últimas reservas sincronizadas.');return;}
      await conectar();
    }catch(e:any){if(ativo){setCarregando(false);setErroAgenda(e?.message??'Entre uma vez online com a conta administrativa.');}}
  };
  iniciar().catch(console.warn);
  const pararConexao=observarConexao(()=>{conectar().catch(console.warn);sincronizar();});
  const pararAuth=onAuthStateChanged(firebaseServices().auth,usuario=>{if(usuario?.uid===uid)conectar().catch(console.warn);});
  const appListener=AppState.addEventListener('change',estado=>{if(estado==='active'){conectar().catch(console.warn);sincronizar();}});
  const intervalo=setInterval(()=>{conectar().catch(console.warn);sincronizar();},30000);
  return ()=>{ativo=false;cancelar?.();pararConexao();pararAuth();appListener.remove();clearInterval(intervalo);};
 },[tentativa]);
 const abrirWhatsApp=async(a:Item,status:StatusLavagem)=>{const msg=status==='iniciado'?'Iniciamos a lavagem do seu veículo.':status==='finalizado'?'Estamos terminando a lavagem do seu veículo.':status==='pronto'?'Lavagem terminada com sucesso! Seu veículo está pronto.':'Seu agendamento está confirmado.';const telefone=a.celular.replace(/\D/g,'');const url=`https://wa.me/${telefone.startsWith('55')?telefone:`55${telefone}`}?text=${encodeURIComponent(`Olá, ${a.nome}! StetiCar: ${msg}`)}`;try{await Linking.openURL(url)}catch{Alert.alert('WhatsApp indisponível','Não foi possível abrir o WhatsApp.')}};
 const arquivar=async(a:Item)=>{Alert.alert('Remover da agenda ativa','O agendamento será cancelado e ficará fora dos atendimentos ativos. Deseja continuar?', [{text:'Voltar',style:'cancel'},{text:'Confirmar',style:'destructive',onPress:async()=>{try{await mudar(a.id,'cancelado')}catch{Alert.alert('Erro','Não foi possível arquivar o agendamento. Confira as regras do Firebase.')}}}]);};
 const mudar=async(id:string,status:StatusLavagem)=>{
   const sessao=await sessaoOffline('estetica').catch(()=>null);const uid=sessao?.user.uid;const item=lista.find(a=>a.id===id);
   if(!uid || !empresaAtual || !item)return Alert.alert('Acesso','Entre uma vez online na conta administrativa.');
   try {
     await guardarStatusPendente(uid,empresaAtual,id,item.status,status);
     setLista(prev=>prev.map(a=>a.id===id?{...a,status}:a));
     setPendencias(prev=>({...prev,[id]:'Aguardando sincronização'}));
     await sincronizarStatusPendentes(uid,empresaAtual);
     const rows=await lerStatusPendentes(uid,empresaAtual);setPendencias(Object.fromEntries(rows.map(x=>[x.id,x.erro??'Aguardando sincronização'])));
   } catch(e:any){Alert.alert('Erro',e?.message??'Não foi possível salvar o status.')}
 };
 return <SafeAreaView style={s.tela}><NeonBackdrop /><ScrollView contentContainerStyle={s.conteudo}><ThemeToggle compact /><View style={{backgroundColor:themeColor('rgba(5,14,28,0.94)'), borderRadius:24, borderWidth:1, borderColor:themeColor('#164463'), alignItems:'center', paddingBottom:18}}>
 <BrandLogo width={200} height={145}/>
 <Text style={s.titulo}>Painel da Estética</Text><Text style={{color:themeColor('#9EBDD3'),marginTop:6}}>Gerencie suas lavagens com praticidade</Text></View><Text style={s.aviso}>Firestore online e SQLite offline. Alterações sem internet ficam pendentes até confirmação no servidor.</Text><TouchableOpacity onPress={()=>Alert.alert("Encerrar sessão", "Isso desativará a biometria e exigirá a senha no próximo acesso.", [{text:"Cancelar",style:"cancel"},{text:"Sair definitivamente",style:"destructive",onPress:onSairCompleto}])} style={s.botao}><Text style={s.botaoTexto}>Sair definitivamente da conta</Text></TouchableOpacity><><Text style={s.texto}>{carregando?'Carregando agendamentos...':`${lista.filter(a=>!['pronto','cancelado'].includes(a.status)).length} atendimento(s) ativo(s)`}</Text>{!!erroAgenda&&<View style={s.cartao}><Text style={s.erro}>Informação da agenda: {erroAgenda}</Text><TouchableOpacity style={s.botao} onPress={()=>{setErroAgenda('');setTentativa(x=>x+1);}} accessibilityRole="button"><Text style={s.botaoTexto}>Tentar atualizar agenda</Text></TouchableOpacity></View>}{!carregando&&!erroAgenda&&lista.length===0&&<Text style={s.texto}>Nenhum agendamento salvo para esta estética.</Text>}<TouchableOpacity onPress={()=>setMostrarHistorico(v=>!v)} style={s.botao}><Text style={s.botaoTexto}>{mostrarHistorico?'Ver atendimentos ativos':'Ver histórico de prontos e cancelados'}</Text></TouchableOpacity>{lista.filter(a=>mostrarHistorico?['pronto','cancelado'].includes(a.status):!['pronto','cancelado'].includes(a.status)).map(a=><View key={a.id} style={s.cartao}><Text style={s.destaque}>{a.data} • {a.horario}</Text><Text style={s.texto}>{a.nome} • {a.celular}</Text><Text style={s.texto}>Placa: {a.placa} | {a.tipo_lavagem}</Text><Text style={s.texto}>Status: {a.status}</Text>{!!pendencias[a.id]&&<Text style={s.aviso}>⏳ {pendencias[a.id]}</Text>}<Text style={s.texto}>Pagamento: {a.formaPagamento === 'pix' ? '▦ Pix' : a.formaPagamento === 'dinheiro' ? '💵 Dinheiro' : a.formaPagamento === 'cartao_credito' ? '💳 Cartão de crédito' : 'Não escolhido'}</Text><View style={s.valores}>
 <Text style={s.destaque}>Valores do atendimento</Text>
 <Text style={s.texto}>{a.tipo_lavagem}: {precoServicoPrincipal(a.tipo_lavagem)>0?formatarPreco(precoServicoPrincipal(a.tipo_lavagem)):'Valor a confirmar'}</Text>
 {(() => { let ids:string[]=[];try{const parsed=JSON.parse(a.servicos_extras??'[]');if(Array.isArray(parsed))ids=parsed.filter((x):x is string=>typeof x==='string');}catch{}return <>
 {ids.length===0?<Text style={s.texto}>Adicionais: nenhum</Text>:ids.map((id,indice)=>{const extra=SERVICOS_EXTRAS.find(x=>x.id===id);return <Text key={`${id}-${indice}`} style={s.texto}>+ {extra?.titulo??id}: {extra?formatarPreco(extra.preco):'valor não cadastrado'}</Text>})}
 <Text style={s.total}>Total previsto: {precoServicoPrincipal(a.tipo_lavagem)>0 && ids.every(id=>SERVICOS_EXTRAS.some(e=>e.id===id))?formatarPreco(calcularTotal(a.tipo_lavagem,ids)):'A confirmar — serviço fora da tabela atual'}</Text>
 </>})()}
 <Text style={s.avisoValor}>Valores calculados pela tabela atual. Não representam confirmação de pagamento.</Text>
 </View><View style={s.linha}>{(['agendado','iniciado','finalizado','pronto'] as StatusLavagem[]).map(st=><TouchableOpacity key={st} onPress={()=>mudar(a.id,st)} style={[s.estado,a.status===st&&s.ativo]}><Text style={s.botaoTexto}>{st}</Text></TouchableOpacity>)}</View>{!mostrarHistorico&&<TouchableOpacity onPress={()=>arquivar(a)} style={[s.botao,{backgroundColor:themeColor('#9C3542')}]}><Text style={[s.botaoTexto,{color:themeColor('#fff')}]}>Cancelar / remover da agenda ativa</Text></TouchableOpacity>}<TouchableOpacity onPress={()=>abrirWhatsApp(a,a.status)} style={s.botao}><Text style={s.botaoTexto}>Enviar status pelo WhatsApp</Text></TouchableOpacity></View>)}</><TouchableOpacity onPress={onVoltar} accessibilityRole="button" style={[s.voltar,{borderWidth:1,borderColor:themeColor("#00B9FF"),borderRadius:12,marginTop:16,marginBottom:16}]}><Text style={{color:themeColor("#00B9FF"),fontWeight:"700"}}>← Bloquear painel / voltar ao acesso</Text></TouchableOpacity></ScrollView></SafeAreaView>
}
const s=createThemedStyles({tela:{flex:1,backgroundColor:themeColor('#03060D')},conteudo:{padding:20,gap:14},titulo:{fontSize:25,color:themeColor('white'),fontWeight:'800'},aviso:{color:themeColor('#4DDBFF'),lineHeight:21},erro:{color:themeColor('#FF9D9D'),lineHeight:21},cartao:{backgroundColor: themeColor('#0A111E'), padding: 16, borderRadius: 20, gap: 10, borderWidth: 1, borderColor: themeColor('#164463'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},texto:{color:themeColor('#e5edf7')},destaque:{color:themeColor('#00B9FF'),fontSize:18,fontWeight:'800'},input:{backgroundColor: themeColor('#081828'), borderRadius: 14, padding: 14, color: themeColor('white'), borderWidth: 1, borderColor: themeColor('#164463')},botao:{backgroundColor: themeColor('#067EEB'), padding: 15, borderRadius: 16, alignItems: 'center', borderWidth: 1, borderColor: themeColor('#43DEFF'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.35, shadowRadius: 12, shadowOffset: {width:0,height:3}, elevation: 6},botaoTexto:{color:themeColor('#FFFFFF'),fontWeight:'700',fontSize:12},linha:{flexDirection:'row',flexWrap:'wrap',gap:6},estado:{backgroundColor:themeColor('#34455d'),padding:9,borderRadius:8},ativo:{backgroundColor:themeColor('#00B9FF')},voltar:{padding:16,alignItems:'center'},valores:{backgroundColor: themeColor('#081828'), borderRadius: 20, padding: 12, gap: 6, borderWidth: 1, borderColor: themeColor('#164463'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},total:{color:themeColor('#4DDBFF'),fontSize:18,fontWeight:'900',marginTop:8},avisoValor:{color:themeColor('#9EBDD3'),fontSize:11,lineHeight:16}});
