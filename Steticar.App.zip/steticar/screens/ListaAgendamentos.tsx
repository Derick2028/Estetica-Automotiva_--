import { createThemedStyles, themeColor, themeStatusBar } from '../ui/theme';
import { NeonBackdrop, BrandLogo } from '../ui/neon';
import { SERVICOS_EXTRAS, calcularTotal, formatarPreco } from '../services/servicosExtras';
import { FormaPagamento } from '../services/firebase/agendamentos';
import { useEffect, useRef } from 'react';
import { Alert, Animated, Image, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Agendamento } from '../services/types';

interface Props { agendamentos: Agendamento[]; onVoltar: () => void; onNovoAgendamento: () => void; onLogout: () => void; onEditar: (agendamento: Agendamento) => void; onCancelar: (id: string) => void; onPagamento: (id:string, forma:FormaPagamento)=>Promise<void>; onReenviar:()=>void; }

export default function ListaAgendamentos({ agendamentos, onVoltar, onNovoAgendamento, onLogout, onEditar, onCancelar, onPagamento, onReenviar }: Props) {
  const pulso = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    const animacao = Animated.loop(Animated.sequence([
      Animated.timing(pulso, { toValue: 0.45, duration: 650, useNativeDriver: true }),
      Animated.timing(pulso, { toValue: 1, duration: 650, useNativeDriver: true }),
    ]));
    animacao.start();
    return () => animacao.stop();
  }, [pulso]);
  const selecionarPagamento = async (id: string, forma: FormaPagamento) => {
    try { if(agendamentos.some(a=>a.id===id && a.pendente)) { Alert.alert('Aguarde','O pagamento só pode ser escolhido após confirmar a reserva no Firebase.'); return; } await onPagamento(id, forma); }
    catch (erro) { Alert.alert('Pagamento', erro instanceof Error ? erro.message : 'Não foi possível salvar a escolha.'); }
  };
  const ordenados = [...agendamentos].sort((a, b) => {
    const dataHoraA = `${a.data.split('/').reverse().join('-')}T${a.horario}:00`;
    const dataHoraB = `${b.data.split('/').reverse().join('-')}T${b.horario}:00`;
    return dataHoraA.localeCompare(dataHoraB);
  });

  const handleLogout = () => Alert.alert('Sair do aplicativo', 'Deseja realmente sair?', [
    { text: 'Cancelar', style: 'cancel' },
    { text: 'Sair', style: 'destructive', onPress: onLogout },
  ]);

  return (
    <SafeAreaView style={styles.safeArea}><NeonBackdrop />
      <StatusBar barStyle={themeStatusBar()} />
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Agendamentos</Text>
        </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
        <View style={{ backgroundColor: themeColor('rgba(5,14,28,0.91)'), borderRadius: 24, borderWidth: 1, borderColor: themeColor('#164463'), alignItems: 'center', paddingBottom: 17, marginBottom: 17 }}>
          <BrandLogo width={195} height={140}/>
          <Text style={{ color: themeColor('#FFFFFF'), fontWeight: '900', fontSize: 20, marginTop: -6 }}>Meus agendamentos</Text>
          <Text style={{ color: themeColor('#9EBDD3'), marginTop: 5, fontSize: 12 }}>Acompanhe os cuidados com seu veículo</Text>
        </View>
        {ordenados.length === 0 ? (
          <View style={styles.emptyCard}>
            <Text style={styles.emptyTitle}>Nenhum agendamento</Text>
            <Text style={styles.emptyText}>Cadastre um novo agendamento para ele aparecer aqui.</Text>
          </View>
        ) : (
          ordenados.map((agendamento) => (
            <View key={agendamento.id} style={styles.card}>
              {agendamento.pendente && <View style={{marginBottom:12,padding:12,backgroundColor:themeColor('#3B2D1B'),borderRadius:10,borderWidth:1,borderColor:themeColor('#B48730')}}>
                <Text style={{color:themeColor('#FFE1A3'),fontWeight:'900'}}>Reserva provisória — NÃO CONFIRMADA</Text>
                <Text style={{color:themeColor('#FFE1A3'),lineHeight:20,marginTop:5}}>{agendamento.erroSincronizacao ? agendamento.erroSincronizacao : 'Aguardando conexão e confirmação do Firebase. A estética ainda pode não receber este atendimento.'}</Text>
                <TouchableOpacity onPress={onReenviar} accessibilityRole="button" style={{backgroundColor:themeColor('#00B9FF'),padding:11,borderRadius:8,marginTop:10,alignItems:'center'}}><Text style={{color:themeColor('#03060D'),fontWeight:'900'}}>Tentar sincronizar novamente</Text></TouchableOpacity>
              </View>}
              <View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'flex-start',gap:8}}>
                <Text style={[styles.cardTitle,{flex:1}]}>🚘 {agendamento.tipoLavagem}</Text>
                <Animated.View style={{opacity: agendamento.status === 'iniciado' ? pulso : 1, backgroundColor: agendamento.status === 'pronto' ? '#166534' : agendamento.status === 'finalizado' ? '#805600' : agendamento.status === 'iniciado' ? '#075B76' : '#244455', paddingHorizontal:9,paddingVertical:6,borderRadius:12}}>
                  <Text style={{color:themeColor('#fff'),fontSize:11,fontWeight:'900'}}>{agendamento.pendente ? '⌛ PENDENTE' : ({agendado:'● AGENDADO',iniciado:'● INICIADO',finalizado:'● FINALIZADO',pronto:'✓ PRONTO',cancelado:'✕ CANCELADO'} as const)[agendamento.status ?? 'agendado']}</Text>
                </Animated.View>
              </View><Text style={styles.text}>Veículo: {agendamento.placa}</Text>
              <Text style={styles.text}>Data: {agendamento.data}</Text>
              <Text style={styles.text}>Horário: {agendamento.horario}</Text>
              <Text style={styles.text}>Serviço: {agendamento.tipoLavagem}</Text>
              {!!agendamento.servicosExtras?.length && <Text style={styles.text}>Extras: {agendamento.servicosExtras.map(id => SERVICOS_EXTRAS.find(item => item.id === id)?.titulo ?? id).join(', ')}</Text>}
              <View style={{marginTop:14,padding:12,borderRadius:10,backgroundColor:themeColor('#103344')}}>
                <Text style={{color:themeColor('#00B9FF'),fontWeight:'800',marginBottom:8}}>Acompanhe seu serviço</Text>
                <Text style={{color:themeColor('#fff')}}>Agendado  →  Iniciado  →  Finalizado  →  Pronto</Text>
                <Text style={{color:themeColor('#C9E4EC'),marginTop:7}}>{agendamento.pendente ? 'Aguarde a confirmação do Firebase. A estética ainda não pode atualizar o atendimento.' : agendamento.status === 'pronto' ? 'Seu veículo está pronto para retirada!' : agendamento.status === 'finalizado' ? 'Serviço finalizado. Aguarde a liberação do veículo.' : agendamento.status === 'iniciado' ? 'Nossa equipe iniciou o atendimento do seu veículo.' : 'Aguardando o início do serviço.'}</Text>
              </View>
              <View style={{marginTop:14,padding:12,borderRadius:10,borderWidth:1,borderColor:themeColor('#176277')}}>
                <Text style={{color:themeColor('#00B9FF'),fontWeight:'800',marginBottom:8}}>Resumo dos valores</Text>
                <Text style={styles.text}>Serviço principal: {formatarPreco(calcularTotal(agendamento.tipoLavagem, []))}</Text>
                {(agendamento.servicosExtras ?? []).map((id, index) => {
                  const extra = SERVICOS_EXTRAS.find(item => item.id === id);
                  return <Text key={`${id}-${index}`} style={styles.text}>{extra?.titulo ?? id}: {extra ? formatarPreco(extra.preco) : 'Preço não disponível'}</Text>;
                })}
                <Text style={{color:themeColor('#4DDBFF'),fontWeight:'900',fontSize:19,marginTop:10}}>Total: {formatarPreco(calcularTotal(agendamento.tipoLavagem,agendamento.servicosExtras ?? []))}</Text>
                <Text style={{color:themeColor('#C9E4EC'),fontSize:11,marginTop:5}}>Valores do catálogo atual. Pagamento realizado diretamente à estética.</Text>
              </View>
              <Text style={{color:themeColor('#fff'),fontWeight:'800',marginTop:15,marginBottom:8}}>Escolha a forma de pagamento</Text>
              <View style={{flexDirection:'row',gap:6}}>
                {([{id:'pix',icone:'▦',titulo:'Pix'},{id:'dinheiro',icone:'💵',titulo:'Dinheiro'},{id:'cartao_credito',icone:'💳',titulo:'Crédito'}] as const).map(opcao => <TouchableOpacity key={opcao.id} onPress={()=>selecionarPagamento(agendamento.id,opcao.id)} accessibilityRole="button" style={{flex:1,borderWidth:2,borderColor:agendamento.formaPagamento===opcao.id?'#00B9FF':'#365666',borderRadius:10,paddingVertical:10,alignItems:'center'}}><Text style={{color:themeColor('#fff'),fontSize:20}}>{opcao.icone}</Text><Text style={{color:themeColor('#fff'),fontSize:12,fontWeight:'700'}}>{opcao.titulo}</Text></TouchableOpacity>)}
              </View>
              <Text style={{color:themeColor('#9EBDD3'),fontSize:11,marginTop:7}}>{agendamento.formaPagamento ? 'Forma de pagamento salva neste aparelho; sincroniza quando houver conexão.' : 'Selecione uma opção para informar à estética.'}</Text>
              {agendamento.tipoMidiaVeiculo === 'foto' && agendamento.midiaVeiculo && <Image source={{ uri: agendamento.midiaVeiculo }} style={styles.platePhoto} resizeMode="cover" />}
              {agendamento.tipoMidiaVeiculo === 'video' && <Text style={styles.text}>🎥 Vídeo anexado no dispositivo</Text>}
              {agendamento.fotoPlaca && <Image source={{ uri: agendamento.fotoPlaca }} style={styles.platePhoto} resizeMode="cover" />}
              <View style={styles.cardActions}>
                <TouchableOpacity style={styles.editButton} onPress={() => onEditar(agendamento)} accessibilityRole="button">
                  <Text style={styles.editText}>Editar</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.cancelButton} onPress={() => onCancelar(agendamento.id)} accessibilityRole="button">
                  <Text style={styles.cancelText}>Cancelar</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))
        )}
        <TouchableOpacity style={styles.primaryButton} onPress={onNovoAgendamento} accessibilityRole="button">
          <Text style={styles.primaryText}>Novo agendamento</Text>
        </TouchableOpacity>
      </ScrollView>

      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.backButton} onPress={onVoltar} accessibilityRole="button">
          <Text style={styles.backText}>Voltar</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout} accessibilityRole="button">
          <Text style={styles.logoutText}>Sair</Text>
        </TouchableOpacity>
      </View>
      </View>
    </SafeAreaView>
  );
}

const styles = createThemedStyles({
  safeArea: { flex: 1, backgroundColor: themeColor('#03060D') },
  container: { flex: 1, backgroundColor: 'transparent' },
  scroll: { flex: 1 },
  content: { width: '100%', maxWidth: 620, alignSelf: 'center', paddingHorizontal: 18, paddingTop: 18, paddingBottom: 30 },
  header: { minHeight: 64, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16, paddingVertical: 10, backgroundColor: themeColor('#03060D'), borderBottomWidth: 1, borderBottomColor: themeColor('#164463') },
  title: { color: themeColor('#ffffff'), fontSize: 23, fontWeight: '800', textAlign: 'center', width: '100%' },
  emptyCard: {backgroundColor: themeColor('#0A111E'), borderRadius: 20, padding: 20, borderWidth: 1, borderColor: themeColor('#164463'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},
  emptyTitle: { color: themeColor('#ffffff'), fontSize: 19, fontWeight: '700', marginBottom: 8 },
  emptyText: { color: themeColor('#9EBDD3'), lineHeight: 20 },
  card: {backgroundColor: themeColor('#0A111E'), borderWidth: 1, borderColor: themeColor('#164463'), borderRadius: 20, padding: 15, marginBottom: 10, shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},
  cardTitle: { color: themeColor('#00B9FF'), fontSize: 19, fontWeight: '700', marginBottom: 8 },
  text: { color: themeColor('#ffffff'), marginTop: 3 },
  platePhoto: { width: '100%', height: 130, borderRadius: 8, marginTop: 10, backgroundColor: themeColor('#03060D') },
  primaryButton: {backgroundColor: themeColor('#067EEB'), paddingVertical: 15, borderRadius: 16, alignItems: 'center', marginTop: 10, borderWidth: 1, borderColor: themeColor('#43DEFF'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.35, shadowRadius: 12, shadowOffset: {width:0,height:3}, elevation: 6},
  primaryText: { color: themeColor('#FFFFFF'), fontSize: 16, fontWeight: '700' },
  cardActions: { flexDirection: 'row', gap: 10, marginTop: 14 },
  editButton: { flex: 1, backgroundColor: themeColor('#00B9FF'), paddingVertical: 12, borderRadius: 8, alignItems: 'center' },
  editText: { color: themeColor('#FFFFFF'), fontWeight: '700' },
  cancelButton: { flex: 1, backgroundColor: themeColor('#6f0000'), paddingVertical: 12, borderRadius: 8, alignItems: 'center' },
  cancelText: { color: themeColor('#ffffff'), fontWeight: '700' },
  bottomBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 10, paddingBottom: 16, backgroundColor: themeColor('#03060D'), borderTopWidth: 1, borderTopColor: themeColor('#164463') },
  backButton: {flex: 1, marginRight: 8, backgroundColor: themeColor('#081828'), paddingVertical: 13, borderRadius: 15, alignItems: 'center', borderWidth: 1, borderColor: themeColor('#148DD2')},
  backText: { color: themeColor('#ffffff'), fontWeight: '700' },
  logoutButton: { flex: 1, marginLeft: 8, backgroundColor: themeColor('#a00000'), paddingVertical: 13, borderRadius: 9, alignItems: 'center' },
  logoutText: { color: themeColor('#ffffff'), fontWeight: '700' },
});
