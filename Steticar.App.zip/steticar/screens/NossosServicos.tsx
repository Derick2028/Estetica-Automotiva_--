import { createThemedStyles, themeColor, themeStatusBar, themedPalette } from '../ui/theme';
import { NeonBackdrop } from '../ui/neon';
import { formatarPreco, PRECO_LAVAGEM_SIMPLES, PRECO_LAVAGEM_COMPLETA } from '../services/servicosExtras';
import { useState } from 'react';
import {ImageBackground,ScrollView,Text,TouchableOpacity,View,StyleSheet,StatusBar} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
const C=themedPalette({bg:'#03060D',card:'#0A111E',line:'#164463',cyan:'#00B9FF',gold:'#4DDBFF',white:'#F5FAFC',muted:'#9EBDD3'});
const simples=[
'Pré-lavagem para remover a sujeira inicial',
'Lavagem com shampoo siliconado, que realça o brilho sem manchar',
'Limpeza das caixas de roda e pneus',
'Aplicação de pretinho convencional nos pneus',
'Aspiração do interior do veículo',
'Limpeza do painel com pano apropriado',
];
const completa=[
'Limpeza detalhada de todas as partes do veículo',
'Restauração e proteção dos plásticos, com duração estimada de até 6 meses',
'Duas etapas de pré-lavagem',
'Esfregação com shampoo de alta performance',
'Cera com proteção da pintura e hidrorrepelência',
'Limpeza das caixas de roda e aplicação de verniz de motor onde adequado',
'Selante de pneus com maior resistência à água',
'Limpeza e descontaminação dos painéis e portas para remover gorduras e sujeira acumulada',
'Higienização das superfícies para redução de contaminantes',
'Recondicionamento dos plásticos internos, painéis e portas',
];
export default function NossosServicos({onVoltar,onAgendar}:{onVoltar:()=>void;onAgendar:()=>void}){
 const [aba,setAba]=useState<'simples'|'completa'>('simples');
 const full=aba==='completa';const itens=full?completa:simples;
 return <SafeAreaView style={st.safe}><NeonBackdrop /><StatusBar barStyle={themeStatusBar()}/><ScrollView contentContainerStyle={st.content}>
 <View style={st.header}><TouchableOpacity onPress={onVoltar}><Text style={st.back}>‹</Text></TouchableOpacity><Text style={st.headerTitle}>Nossos Serviços</Text><Text style={{width:26}}/></View>
 <View style={st.tabs}><TouchableOpacity onPress={()=>setAba('simples')} style={[st.tab,!full&&st.active]}><Text style={[st.tabText,!full&&st.activeText]}>Lavagem Simples</Text></TouchableOpacity><TouchableOpacity onPress={()=>setAba('completa')} style={[st.tab,full&&st.active]}><Text style={[st.tabText,full&&st.activeText]}>Lavagem Completa</Text></TouchableOpacity></View>
 <View style={st.panel}><ImageBackground source={full?require('../assets/visual/lavagem_completa.jpg'):require('../assets/visual/lavagem_simples.jpg')} style={st.photo} imageStyle={{borderTopLeftRadius:17,borderTopRightRadius:17}}><View style={st.photoShade}><Text style={st.photoBadge}>{full?'👑':'💧'}</Text><Text style={st.photoTitle}>{full?'Lavagem Completa ou Detalhada':'Lavagem Simples'}</Text><Text style={st.photoDesc}>{full?'Máximo cuidado para o seu veículo':'Praticidade e brilho no seu dia a dia'}</Text><Text style={{color:C.gold,fontWeight:'900',fontSize:22,marginTop:6}}>💰 {formatarPreco(full?PRECO_LAVAGEM_COMPLETA:PRECO_LAVAGEM_SIMPLES)}</Text></View></ImageBackground>
 <View style={{padding:16}}>{itens.map(x=><View key={x} style={st.line}><Text style={st.check}>✓</Text><Text style={st.lineText}>{x}</Text></View>)}</View></View>
 <View style={st.duration}><Text style={{fontSize:23}}>◷</Text><Text style={{color:C.white,fontWeight:'700'}}>Tempo estimado: {full?'2 a 4 horas':'40 a 60 minutos'}</Text></View>
 <TouchableOpacity onPress={onAgendar} style={[st.mainButton,full&&{backgroundColor:C.gold}]}><Text style={st.mainText}>Agendar Lavagem {full?'Completa':'Simples'}  →</Text></TouchableOpacity>
 <Text style={st.note}>Estética automotiva é cuidado, proteção e atenção aos detalhes. Nosso compromisso é valorizar seu veículo em cada lavagem.</Text>
 </ScrollView></SafeAreaView>;
}
const st=createThemedStyles({safe:{flex:1,backgroundColor:C.bg},content:{paddingHorizontal:17,paddingBottom:50},header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingVertical:16},back:{color:C.white,fontSize:35,width:26},headerTitle:{color:C.white,fontSize:18,fontWeight:'900'},tabs:{flexDirection:'row',borderRadius:13,borderWidth:1,borderColor:C.line,overflow:'hidden',marginBottom:17},tab:{width:'50%',paddingVertical:13,alignItems:'center'},active:{backgroundColor:C.cyan},tabText:{color:C.white,fontWeight:'800',fontSize:12},activeText:{color:C.bg},panel:{borderWidth: 1, borderColor: themeColor('#164463'), borderRadius: 20, backgroundColor: themeColor('#03111A'), overflow: 'hidden', shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},photo:{height:210,justifyContent:'flex-end'},photoShade:{backgroundColor:themeColor('rgba(2,12,21,0.75)'),padding:15},photoBadge:{fontSize:27},photoTitle:{color:C.white,fontWeight:'900',fontSize:22},photoDesc:{color:C.muted,marginTop:4},line:{flexDirection:'row',paddingVertical:8,alignItems:'flex-start'},check:{color:C.bg,backgroundColor:C.cyan,borderRadius:12,overflow:'hidden',fontWeight:'900',marginRight:12,paddingHorizontal:5},lineText:{color:C.white,flex:1,lineHeight:20,fontSize:13},duration:{flexDirection: 'row', gap: 12, alignItems: 'center', borderWidth: 1, borderColor: themeColor('#164463'), padding: 15, borderRadius: 20, marginTop: 17, shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},mainButton:{backgroundColor: themeColor('#067EEB'), padding: 17, borderRadius: 16, marginTop: 18, borderWidth: 1, borderColor: themeColor('#43DEFF'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.35, shadowRadius: 12, shadowOffset: {width:0,height:3}, elevation: 6},mainText:{color:C.white,fontWeight:'900',textAlign:'center'},section:{color: C.white, fontSize: 24, fontWeight: '900', marginTop: 35, borderRadius: 20, borderWidth: 1, borderColor: themeColor('#164463'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},muted:{color:C.muted,marginTop:5,marginBottom:18},extra:{flexDirection:'row',alignItems:'center',borderRadius:15,borderWidth:1,borderColor:C.line,backgroundColor:C.card,padding:9,marginBottom:10},extraImage:{height:69,width:69,borderRadius:11},extraName:{color:C.white,fontWeight:'800',fontSize:13},extraDesc:{color:C.muted,fontSize:11,lineHeight:16,marginTop:5},plus:{height:33,width:33,borderRadius:9,backgroundColor:C.cyan,alignItems:'center',justifyContent:'center'},plusText:{color:C.bg,fontWeight:'900',fontSize:24},package:{flexDirection:'row',alignItems:'center',borderWidth:1,borderColor:C.cyan,borderRadius:16,padding:15,marginTop:8},note:{color:C.muted,fontSize:11,textAlign:'center',marginTop:18,lineHeight:17}});
