import { createThemedStyles, themeColor, themeStatusBar } from '../ui/theme';
import { NeonBackdrop } from '../ui/neon';
import {Image,ScrollView,StatusBar,StyleSheet,Text,TouchableOpacity,View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {SERVICOS_EXTRAS,formatarPreco} from '../services/servicosExtras';
const fotos=[require('../assets/visual/extra_vidro.jpg'),require('../assets/visual/extra_pintura.jpg'),require('../assets/visual/extra_protecao.jpg'),require('../assets/visual/extra_cera.jpg'),require('../assets/visual/extra_farol.jpg')];
export default function ServicosExtras({onVoltar,onAgendar}:{onVoltar:()=>void;onAgendar:()=>void}) {
 return <SafeAreaView style={st.safe}><NeonBackdrop /><StatusBar barStyle={themeStatusBar()}/><ScrollView contentContainerStyle={st.content}>
 <View style={st.header}><TouchableOpacity onPress={onVoltar}><Text style={st.back}>‹</Text></TouchableOpacity><Text style={st.title}>Serviços Extras</Text><View style={{width:26}}/></View>
 <Text style={st.sub}>Adicione cuidados especiais à lavagem simples ou completa escolhida no agendamento.</Text>
 {SERVICOS_EXTRAS.map((item,i)=><View key={item.id} style={st.card}><Image source={fotos[i]} style={st.image}/><View style={{flex:1}}><Text style={st.name}>{item.icone} {item.titulo}</Text><Text style={st.desc}>{item.descricao}</Text><Text style={st.price}>{formatarPreco(item.preco)}</Text></View></View>)}
 <TouchableOpacity onPress={onAgendar} style={st.button}><Text style={st.buttonText}>Escolher lavagem e adicionar extras →</Text></TouchableOpacity>
 <Text style={st.sub}>A seleção e o valor total são confirmados na tela de agendamento.</Text>
 </ScrollView></SafeAreaView>;
}
const st=createThemedStyles({safe:{flex:1,backgroundColor:themeColor('#03060D')},content:{padding:17,paddingBottom:50},header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginBottom:16},back:{color:themeColor('#fff'),fontSize:35,width:26},title:{color:themeColor('#fff'),fontSize:19,fontWeight:'900'},sub:{color:themeColor('#9EBDD3'),fontSize:13,lineHeight:20,marginBottom:18},card:{flexDirection: 'row', alignItems: 'center', borderRadius: 20, borderWidth: 1, borderColor: themeColor('#164463'), backgroundColor: themeColor('#0A111E'), padding: 10, marginBottom: 12, gap: 12, shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},image:{width:82,height:82,borderRadius:10},name:{color:themeColor('#fff'),fontWeight:'800',fontSize:14},desc:{color:themeColor('#9EBDD3'),fontSize:12,marginTop:4},price:{color:themeColor('#4DDBFF'),fontSize:16,fontWeight:'900',marginTop:6},button:{backgroundColor: themeColor('#067EEB'), padding: 17, borderRadius: 16, marginVertical: 16, borderWidth: 1, borderColor: themeColor('#43DEFF'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.35, shadowRadius: 12, shadowOffset: {width:0,height:3}, elevation: 6},buttonText:{color:themeColor('#FFFFFF'),fontWeight:'900',textAlign:'center'}});
