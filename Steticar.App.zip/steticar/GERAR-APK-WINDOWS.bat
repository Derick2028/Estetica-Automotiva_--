@echo off
setlocal
cd /d "%~dp0"
title StetiCar - Criar APK Android

echo =============================================
echo       STETICAR - GERAR APK INSTALAVEL
echo =============================================
echo.
echo O APK sera compilado online pela Expo (EAS).
echo Ao concluir, o EAS mostrara o link de download.
echo O primeiro uso exigira login em sua conta Expo.
echo.
where node >nul 2>nul || goto semnode
where npm >nul 2>nul || goto semnode

call node scripts\verificar-google.cjs --android
if errorlevel 1 goto google
:continuar
if not exist node_modules\expo\package.json (
  echo Instalando dependencias...
  call npm install
  if errorlevel 1 goto erro
)
echo Verificando TypeScript...
call npm run check
if errorlevel 1 goto erro

echo.
echo Fazendo login no Expo (nao compartilhe sua senha)...
call npx --yes eas-cli@latest login
if errorlevel 1 goto erro

echo Projeto EAS vinculado pela configuracao app.json.
echo Gerando APK com o perfil existente em eas.json...

echo.
echo Gerando arquivo APK Android. Essa etapa depende da internet.
echo Se solicitado, permita criar a chave de assinatura Android.
call npx --yes eas-cli@latest build --platform android --profile apk --clear-cache
if errorlevel 1 goto erro

echo.
echo O EAS mostrou o link do build acima.
echo Abra o link, aguarde a conclusao e baixe o arquivo .apk.
echo Para login Google: adicione o SHA-1 da assinatura no Firebase,
echo atualize google-services.json e gere nova versao do APK.
pause
exit /b 0
:google
echo.
echo Corrija as informacoes Google indicadas acima antes de compilar.
pause
exit /b 1
:semnode
echo Instale Node.js 22.13 ou superior: https://nodejs.org/
pause
exit /b 1
:erro
echo.
echo Falha: leia a mensagem acima. Nenhum APK valido foi gerado.
pause
exit /b 1
