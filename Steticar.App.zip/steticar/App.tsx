import { ThemeProvider, useAppTheme, themeColor } from './ui/theme';
import { useEffect, useState } from 'react';
import { Alert, AppState, BackHandler, Platform, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { onAuthStateChanged } from 'firebase/auth';

import TelaInicial from './components/TelaInicial';
import Home from './screens/Home';
import LoginProprietarioFirebase from './screens/LoginProprietarioFirebase';
import PainelProprietario from './screens/PainelProprietario';
import CadastroEmpresa from './screens/CadastroEmpresa';
import CadastroCliente from './screens/CadastroCliente';
import AgendamentoForm from './screens/AgendamentoForm';
import ListaAgendamentos from './screens/ListaAgendamentos';
import NossosServicos from './screens/NossosServicos';
import ServicosExtras from './screens/ServicosExtras';
import ServicosPolimentos from './screens/ServicosPolimentos';
import CartaoFidelidade from './screens/CartaoFidelidade';
import Login from './telas/autenticacao/Login';
import PerfilUsuario from './telas/perfil/PerfilUsuario';
import { buscarClientePorEmail, buscarClientePorId, criarCliente, inicializarBanco } from './services/database';
import { observarMeusAgendamentos, EMPRESA_ID } from './services/firebase/agendamentos';
import { firebaseServices } from './services/firebase/config';
import { sairFirebase } from './services/firebase/autenticacao';
import { sessaoOffline, lerSessaoLocal } from './services/firebase/sessaoOffline';
import { salvarCache, lerCacheCliente, lerPendentes, guardarPendente, sincronizarPendentes, removerReservaProvisoria, guardarCancelamento, lerCancelamentos, sincronizarOperacoesCliente, guardarPagamento, lerPagamentos, sincronizarPerfilPendente } from './services/offlineAgenda';
import { observarConexao } from './services/conexao';
import { obterAcessoBiometrico, bloquearComBiometria, estaBloqueadoComBiometria } from './servicos/segurancaUsuario';
import type { Agendamento } from './services/types';

type Screen = 'acesso' | 'cadastroEmpresa' | 'login' | 'cadastro' | 'home' | 'novo' | 'lista' | 'perfil' | 'proprietario' | 'loginProprietario' | 'servicos' | 'extras' | 'polimentos' | 'fidelidade';

export default function App() {
  return <ThemeProvider><StetiCarApp /></ThemeProvider>;
}

function StetiCarApp() {
  const { mode } = useAppTheme(); // Atualiza todas as telas quando a aparência muda.
  const [screen, setScreen] = useState<Screen>('acesso');
  const [servicoInicial, setServicoInicial] = useState('');
  const [bancoPronto, setBancoPronto] = useState(false);
  const [erroBanco, setErroBanco] = useState(false);
  const [donoAutorizado, setDonoAutorizado] = useState(false);
  const [clienteId, setClienteId] = useState<number | null>(null);
  const [uidAtivo, setUidAtivo] = useState<string | null>(null);
  const [remotos, setRemotos] = useState<Agendamento[]>([]);
  const [tentativaSincronizacao, setTentativaSincronizacao] = useState(0);

  useEffect(() => {
    let ativo = true;
    // Apresenta falha recuperável se a abertura nativa ficar bloqueada.
    const aviso = setTimeout(() => { if (ativo) setErroBanco(true); }, 12000);
    inicializarBanco().then(() => { if (ativo) {clearTimeout(aviso);setBancoPronto(true);} }).catch((error) => { if (ativo) {clearTimeout(aviso);console.warn('Falha no SQLite:',error);setErroBanco(true);} });
    return () => { ativo=false;clearTimeout(aviso); };
  }, []);

  useEffect(() => {
    if (!uidAtivo) return;
    let ativo = true;
    let cancelarRemoto: (() => void) | null = null;
    const atualizarLocal = async () => {
      const [cache,pendentes,cancelamentos,pagamentos] = await Promise.all([
        lerCacheCliente(uidAtivo,EMPRESA_ID),lerPendentes(uidAtivo),lerCancelamentos(uidAtivo),lerPagamentos(uidAtivo)
      ]);
      const ocultos = new Set(cancelamentos.filter(c=>!c.erro).map(c=>c.id));
      const forma = new Map(pagamentos.map(p=>[p.id,p.forma]));
      const itens = [...cache,...pendentes.filter(p=>!cache.some(c=>c.id===p.id))]
        .filter(a=>!ocultos.has(a.id))
        .map(a=>converterAgendamento({...a,formaPagamento:forma.get(a.id)??a.formaPagamento,
          pendente:pendentes.some(p=>p.id===a.id),
          erroSincronizacao:pendentes.find(p=>p.id===a.id)?.erroSincronizacao}));
      if (ativo) setRemotos(itens);
    };
    const tentar = () => {
      if(firebaseServices().auth.currentUser?.uid!==uidAtivo) return;
      // Não bloqueia a navegação esperando pelo Firebase.
      (async () => { await sincronizarPendentes(uidAtivo);await sincronizarOperacoesCliente(uidAtivo);await sincronizarPerfilPendente(uidAtivo);await atualizarLocal(); })().catch(console.warn);
    };
    const observar = () => {
      if (cancelarRemoto || firebaseServices().auth.currentUser?.uid!==uidAtivo) return;
      cancelarRemoto=observarMeusAgendamentos(uidAtivo,items=>{
        salvarCache(uidAtivo,EMPRESA_ID,items,'cliente').then(atualizarLocal).catch(console.warn);
      },erro=>{
        // Um listener que falhou encerra a escuta. Permitir nova assinatura ao reconectar.
        cancelarRemoto=null;
        console.warn('Agenda online indisponível, usando SQLite:', 'code' in erro ? erro.code : 'sem-codigo', erro.message);
      });
    };
    atualizarLocal().catch(console.warn);
    observar();tentar();
    const pararConexao=observarConexao(()=>{observar();tentar();});
    const pararAuth=onAuthStateChanged(firebaseServices().auth,usuario=>{
      if(!ativo)return;
      if(usuario?.uid===uidAtivo){observar();tentar();}
      else {cancelarRemoto?.();cancelarRemoto=null;}
    });
    const appListener=AppState.addEventListener('change',estado=>{if(estado==='active'){observar();tentar();}});
    const intervalo=setInterval(()=>{observar();tentar();},30000);
    return ()=>{ativo=false;cancelarRemoto?.();pararConexao();pararAuth();appListener.remove();clearInterval(intervalo);};
  },[uidAtivo,tentativaSincronizacao]);

  function converterAgendamento(a:any):Agendamento {
    return {id:a.id,placa:a.placa,data:a.data?.includes('-')?a.data.split('-').reverse().join('/'):a.data,
      horario:a.horario,tipoLavagem:a.tipoLavagem,servicosExtras:a.servicosExtras??[],status:a.status??'agendado',
      formaPagamento:a.formaPagamento,pendente:a.pendente,erroSincronizacao:a.erroSincronizacao};
  }

  // A sessão salva no aparelho permite abrir o app sem consultar a rede.
  useEffect(() => {
    if (!bancoPronto) return;
    let ativo = true;
    (async () => {
      try {
        const sessao=await lerSessaoLocal();
        if(!ativo || !sessao || sessao.perfil.ativo===false) return;
        const bio=await obterAcessoBiometrico(sessao.perfil.tipo);
        if(!ativo)return;
        if(bio){setScreen(sessao.perfil.tipo==='estetica'?'loginProprietario':'login');return;}
        if(await estaBloqueadoComBiometria())return;
        if(sessao.perfil.tipo==='estetica') {
          if(sessao.perfil.ativo===true) {setDonoAutorizado(true);setScreen('proprietario');}
          return;
        }
        const {user,perfil}=await sessaoOffline('cliente');
        let cliente=await buscarClientePorEmail(user.email);
        if(!cliente){
          const id=await criarCliente({nome:perfil.nome,celular:perfil.telefone??'',endereco:perfil.endereco??'',email:user.email,placa:`CLIENTE-${user.uid}`});
          cliente=await buscarClientePorId(id);
        }
        if(ativo&&cliente) await entrar(cliente.id);
      }catch(e){console.warn('Não foi possível restaurar a sessão local:',e);}
    })();
    return ()=>{ativo=false;};
  },[bancoPronto]);

  // Evita que o botão físico/virtual Voltar encerre a abertura sem confirmação.
  useEffect(() => {
    if (Platform.OS !== 'android') return;
    const listener = BackHandler.addEventListener('hardwareBackPress', () => {
      if (screen === 'acesso') {
        Alert.alert('Sair do StetiCar?', 'Deseja realmente fechar o aplicativo?', [
          { text: 'Continuar no aplicativo', style: 'cancel' },
          { text: 'Sair', onPress: () => BackHandler.exitApp() },
        ]);
        return true;
      }
      if (screen === 'login' || screen === 'loginProprietario' || screen === 'cadastro' || screen === 'cadastroEmpresa') {
        setScreen('acesso');
        return true;
      }
      return false;
    });
    return () => listener.remove();
  }, [screen]);

  const limparTelaAposSaida=()=>{
    setClienteId(null);setUidAtivo(null);setDonoAutorizado(false);
    setRemotos([]);setScreen('acesso');
  };
  // Bloquear mantém a sessão Firebase válida para que a biometria funcione
  // novamente, inclusive sem internet. "Sair definitivamente" encerra tudo.
  const logout = () => {
    const id=clienteId;
    limparTelaAposSaida();
    (async()=>{
      try{
        const registro=await obterAcessoBiometrico('cliente');
        if(registro?.clienteId===id){await bloquearComBiometria();setScreen('login');}
        else await sairFirebase();
      }catch(e){console.warn('Falha ao sair:',e);}
    })();
  };
  const logoutEmpresa = () => {
    limparTelaAposSaida();
    (async()=>{
      try{
        if(await obterAcessoBiometrico('estetica')){
          await bloquearComBiometria();setScreen('loginProprietario');
        }else await sairFirebase();
      }catch(e){console.warn('Falha ao sair:',e);}
    })();
  };
  const logoutCompleto=()=>{
    limparTelaAposSaida();
    sairFirebase().catch(e=>console.warn('Falha ao encerrar sessão:',e));
  };
  const entrar = async (id:number) => { try { const {user}=await sessaoOffline('cliente');setClienteId(id);setUidAtivo(user.uid);setScreen('home'); } catch(e:any) { Alert.alert('Acesso indisponível',e?.message??'Entre com internet uma vez para preparar os dados locais.'); } };
  const abrirNovo = async () => { try { setServicoInicial('');setScreen('novo'); } catch { Alert.alert('Erro','Não foi possível consultar os horários ocupados.'); } };
  const agendarPolimento = (servico: string) => { setServicoInicial(servico);setScreen('novo'); };
  const abrirLista = async () => { if (!clienteId) return; try { setScreen('lista'); } catch { Alert.alert('Erro','Não foi possível carregar seus agendamentos.'); } };
  const reenviarReservas = () => {
    if(!uidAtivo) {Alert.alert('Acesso necessário','Entre novamente para sincronizar a agenda.');return;}
    setTentativaSincronizacao(valor=>valor+1);
    Alert.alert('Sincronização solicitada','Vamos tentar enviar novamente as reservas pendentes. Se houver recusa, confira as regras publicadas no Firebase e se o horário já está reservado.');
  };
  const abrirEdicaoSegura = async (a: Agendamento) => { Alert.alert('Alteração online', 'Para alterar data ou horário, cancele a reserva e crie uma nova.'); };

  const cancelarAgendamento = (id:string) => {
    if(!uidAtivo)return;
    const a=remotos.find(item=>item.id===id);
    if(!a)return;
    Alert.alert('Cancelar agendamento',`Deseja cancelar a reserva da placa ${a.placa}?`,[
      {text:'Voltar',style:'cancel'},
      {text:'Cancelar reserva',style:'destructive',onPress:async()=>{
        try{
          if(a.pendente) await removerReservaProvisoria(uidAtivo,id);
          // Também cobre uma confirmação remota simultânea ao cancelamento local.
          await guardarCancelamento(uidAtivo,id);
          setRemotos(antes=>antes.filter(item=>item.id!==id));
          sincronizarOperacoesCliente(uidAtivo).catch(console.warn);
          Alert.alert('Cancelamento registrado','O pedido ficou salvo no aparelho e será verificado pelo servidor ao conectar.');
        }catch(e:any){Alert.alert('Erro',e?.message??'Não foi possível registrar o cancelamento.');}
      }}
    ]);
  };

  const salvarPagamento=async(id:string,forma:'pix'|'dinheiro'|'cartao_credito')=>{
    if(!uidAtivo)throw new Error('Entre novamente com sua conta.');
    if(remotos.some(a=>a.id===id && a.pendente))throw new Error('Aguarde a confirmação da reserva para selecionar o pagamento.');
    await guardarPagamento(uidAtivo,id,forma);
    setRemotos(lista=>lista.map(item=>item.id===id?{...item,formaPagamento:forma}:item));
    sincronizarOperacoesCliente(uidAtivo).catch(console.warn);
  };

  const salvarAgendamento = async (novo:Agendamento) => {
    if(!clienteId || !uidAtivo)return;
    try{
      const cliente=await buscarClientePorId(clienteId);
      const {user}=await sessaoOffline('cliente');
      if(!cliente || user.uid!==uidAtivo) throw new Error('Conta local não corresponde ao cliente.');
      const reserva={clienteId:uidAtivo,empresaId:EMPRESA_ID,nome:cliente.nome,celular:cliente.celular,
        placa:novo.placa,data:novo.data,horario:novo.horario,tipoLavagem:novo.tipoLavagem,
        servicosExtras:novo.servicosExtras??[]};
      const item=await guardarPendente(reserva);
      setRemotos(atuais=>[...atuais.filter(a=>a.id!==item.id),converterAgendamento({...item,pendente:true})]);
      setScreen('lista');
      sincronizarPendentes(uidAtivo).catch(console.warn);
      Alert.alert('Reserva registrada','O agendamento foi salvo no aparelho e será confirmado pelo servidor quando houver conexão.');
    }catch(e:any){Alert.alert('Não foi possível agendar',e?.message??'Confira os dados informados.');}
  };

  if (erroBanco) return <SafeAreaProvider><View style={{flex:1,justifyContent:'center',padding:24,backgroundColor:themeColor('#03060D')}}><Text style={{color:themeColor('white'),fontSize:18,marginBottom:20}}>Não foi possível preparar o banco local. Verifique o armazenamento e reinicie o aplicativo.</Text><TouchableOpacity onPress={()=>{setErroBanco(false);inicializarBanco().then(()=>setBancoPronto(true)).catch(()=>setErroBanco(true));}} style={{padding:15,backgroundColor:'#067EEB',borderRadius:10}}><Text style={{fontWeight:'800',color:'#FFFFFF'}}>Tentar novamente</Text></TouchableOpacity></View></SafeAreaProvider>;
  if (!bancoPronto) return <SafeAreaProvider><View style={{flex:1,justifyContent:'center',alignItems:'center',backgroundColor:themeColor('#03060D')}}><Text style={{color:themeColor('white')}}>Preparando dados locais...</Text></View></SafeAreaProvider>;
  return (
    <SafeAreaProvider>
      {screen === 'acesso' && (
        <TelaInicial
          onCliente={() => setScreen('login')}
          onCadastroCliente={() => setScreen('cadastro')}
          onEstetica={() => setScreen('loginProprietario')}
          onCadastroEstetica={() => setScreen('cadastroEmpresa')}
        />
      )}
       {screen === 'cadastroEmpresa' && <CadastroEmpresa onVoltar={()=>setScreen('acesso')} onConcluido={()=>setScreen('loginProprietario')} />}
      {screen === 'loginProprietario' && <LoginProprietarioFirebase onAutorizado={() => {setDonoAutorizado(true);setScreen('proprietario');}} onVoltar={() => setScreen('acesso')} />}
      {screen === 'proprietario' && donoAutorizado && <PainelProprietario onVoltar={logoutEmpresa} onSairCompleto={logoutCompleto} />}
      {screen === 'login' && (<View style={{flex:1}}>
        <Login
          onEnter={entrar}
          onCadastro={() => setScreen('cadastro')}
          onVoltar={() => setScreen('acesso')}
        />
        </View>
      )}
      {screen === 'cadastro' && (
        <CadastroCliente
          onCadastroConcluido={entrar}
          onVoltar={() => setScreen('acesso')}
        />
      )}
      {screen === 'novo' && (
        <AgendamentoForm
          key={servicoInicial || 'novo'}
          tipoInicial={servicoInicial}
          agendamentos={remotos}
          onAgendamento={salvarAgendamento}
          onVoltar={() => setScreen('home')}
          onLogout={logout}
        />
      )}
      {screen === 'lista' && (
        <ListaAgendamentos
          agendamentos={remotos}
          onVoltar={() => setScreen('home')}
          onNovoAgendamento={abrirNovo}
          onLogout={logout}
          onEditar={abrirEdicaoSegura}
          onCancelar={cancelarAgendamento}
          onPagamento={salvarPagamento}
          onReenviar={reenviarReservas}
        />
      )}
      {screen === 'perfil' && clienteId && <PerfilUsuario clienteId={clienteId} onVoltar={() => setScreen('home')} onSairCompleto={logoutCompleto} />}
      {screen === 'extras' && <ServicosExtras onVoltar={() => setScreen('home')} onAgendar={abrirNovo} />}
      {screen === 'polimentos' && <ServicosPolimentos onVoltar={() => setScreen('home')} onAgendar={agendarPolimento} />}
      {screen === 'fidelidade' && <CartaoFidelidade onVoltar={() => setScreen('home')} agendamentos={remotos} />}
      {screen === 'servicos' && <NossosServicos onVoltar={() => setScreen('home')} onAgendar={abrirNovo} />}
      {screen === 'home' && (
        <Home
          clienteId={clienteId!}
          onAgendar={abrirNovo}
          onServicos={() => setScreen('servicos')}
          onExtras={() => setScreen('extras')}
          onPolimentos={() => setScreen('polimentos')}
          onFidelidade={() => setScreen('fidelidade')}
          onVerAgendamentos={abrirLista}
          onLogout={logout}
          onPerfil={() => setScreen('perfil')}
          onSincronizar={reenviarReservas}
        />
      )}
    </SafeAreaProvider>
  );
}
