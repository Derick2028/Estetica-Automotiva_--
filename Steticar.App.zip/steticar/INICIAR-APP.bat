@echo off
setlocal
cd /d "%~dp0"
title StetiCar - Expo

echo ========================================
echo         STETICAR - INICIAR APP
echo ========================================
echo.

where node >nul 2>nul || goto semnode
where npm >nul 2>nul || goto semnode

if not exist node_modules\expo\package.json (
  echo Dependencias nao encontradas. Instalando...
  call npm install
  if errorlevel 1 goto erro
)

echo.
echo Iniciando Expo em modo TUNNEL.
echo Este modo evita o erro de conexao pelo IP local 192.168.x.x.
echo Aguarde o QR Code e abra-o no Expo Go.
echo.
call npx expo start --tunnel --clear
if errorlevel 1 goto erro
exit /b 0

:semnode
echo ERRO: Node.js/NPM nao encontrado.
echo Instale o Node.js 22 e execute este arquivo novamente.
pause
exit /b 1

:erro
echo.
echo Nao foi possivel iniciar o Expo.
echo Confira sua conexao com a internet e tente novamente.
pause
exit /b 1
