export interface Agendamento {
  id: string;
  pendente?: boolean;
  erroSincronizacao?: string | null;
  status?: 'agendado' | 'iniciado' | 'finalizado' | 'pronto' | 'cancelado';
  formaPagamento?: 'pix' | 'dinheiro' | 'cartao_credito';
  placa: string;
  data: string;
  horario: string;
  tipoLavagem: string;
  fotoPlaca?: string;
  servicosExtras?: string[];
  midiaVeiculo?: string;
  tipoMidiaVeiculo?: 'foto' | 'video';
}
