export const SERVICOS_EXTRAS = [
  { id: 'cristalizacao_vidro', titulo: 'Cristalização de vidro', icone: '🪟', preco: 120, descricao: 'Tratamento para os vidros' },
  { id: 'cristalizacao_pintura', titulo: 'Cristalização de pintura', icone: '✨', preco: 250, descricao: 'Realce e cuidado da pintura' },
  { id: 'protecao_pintura', titulo: 'Proteção de pintura', icone: '🛡️', preco: 80, descricao: 'Camada de proteção adicional' },
  { id: 'cera_hidrorrepelente', titulo: 'Cera hidrorrepelente', icone: '💧', preco: 75, descricao: 'Ajuda a repelir a água' },
  { id: 'restauracao_farois', titulo: 'Restauração de faróis', icone: '💡', preco: 220, descricao: 'Revitalização dos faróis' },
] as const;

export const SERVICOS_POLIMENTO = [
  {
    id: 'polimento_tecnico', titulo: 'Polimento Técnico', icone: '✨', preco: 480,
    descricao: 'Tratamento detalhado para corrigir imperfeições superficiais do verniz e recuperar a profundidade do brilho da pintura.',
    detalhes: [
      'Avaliação visual da pintura e preparação da superfície antes do polimento.',
      'Polimento técnico em etapas, conforme a necessidade e as condições do verniz.',
      'Redução de microrriscos, marcas circulares e hologramas superficiais.',
      'Acabamento para realçar a cor, o reflexo e a profundidade do brilho.',
    ],
    observacao: 'Riscos profundos e danos que ultrapassam o verniz podem não ser removidos. A proteção cerâmica não está incluída.',
  },
  {
    id: 'polimento_comercial', titulo: 'Polimento Comercial', icone: '🚘', preco: 220,
    descricao: 'Revitalização estética para recuperar o brilho e suavizar sinais leves de uso na pintura, com execução mais objetiva.',
    detalhes: [
      'Preparação e limpeza da superfície para o tratamento.',
      'Etapa de polimento leve voltada à renovação do brilho.',
      'Atenuação de marcas muito superficiais e aparência opaca.',
      'Acabamento que valoriza o visual do veículo.',
    ],
    observacao: 'É um tratamento de revitalização, não uma correção profunda de riscos ou defeitos da pintura.',
  },
  {
    id: 'enceramento_comercial', titulo: 'Enceramento Comercial', icone: '🛡️', preco: 180,
    descricao: 'Aplicação de cera automotiva para intensificar o brilho e oferecer uma camada temporária de proteção à pintura.',
    detalhes: [
      'Preparação e limpeza superficial da área a ser encerada.',
      'Aplicação e acabamento com cera automotiva.',
      'Realce do brilho e toque mais liso na superfície.',
      'Ajuda a reduzir a aderência de água e sujeira durante o período de proteção.',
    ],
    observacao: 'A durabilidade varia conforme o produto, a exposição ao tempo e a frequência das lavagens. Não elimina riscos.',
  },
] as const;

export const PRECO_LAVAGEM_SIMPLES = 60;
export const PRECO_LAVAGEM_COMPLETA = 160;
export const SERVICOS_PRINCIPAIS = [
  { id: 'lavagem_simples', titulo: 'Simples', preco: PRECO_LAVAGEM_SIMPLES },
  { id: 'lavagem_completa', titulo: 'Completa', preco: PRECO_LAVAGEM_COMPLETA },
  ...SERVICOS_POLIMENTO,
] as const;
export const precoServicoPrincipal = (nome: string): number => {
  // Compatibilidade de exibição com agendamentos de versões anteriores.
  const equivalentes: Record<string,string> = {
    'Lavagem Simples': 'Simples',
    'Lavagem Completa': 'Completa',
    'Lavagem Completa ou Detalhada': 'Completa',
  };
  const titulo = equivalentes[nome] ?? nome;
  return SERVICOS_PRINCIPAIS.find(item => item.titulo === titulo)?.preco ?? 0;
};
export const servicoPrincipalValido = (nome: string): boolean =>
  SERVICOS_PRINCIPAIS.some(item => item.titulo === nome);

export function formatarPreco(valor: number): string { return `R$ ${valor.toFixed(2).replace('.', ',')}`; }
export function calcularTotal(tipo: string, extras: readonly string[]): number {
 const principal = precoServicoPrincipal(tipo);
 return principal + extras.reduce((soma,id)=>soma+(SERVICOS_EXTRAS.find(s=>s.id===id)?.preco ?? 0),0);
}
