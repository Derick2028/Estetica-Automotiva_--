/**
 * Consulta a API pública e gratuita ViaCEP (https://viacep.com.br/).
 * A consulta é opcional: o usuário pode digitar o endereço sem conexão.
 */
export interface EnderecoViaCep {
  cep: string;
  logradouro: string;
  bairro: string;
  localidade: string;
  uf: string;
  complemento?: string;
}

export function formatarCep(valor: string): string {
  const digitos = valor.replace(/\D/g, '').slice(0, 8);
  return digitos.length > 5 ? `${digitos.slice(0, 5)}-${digitos.slice(5)}` : digitos;
}

/** Monta um endereço editável; o número do imóvel é informado manualmente. */
export function enderecoDoCep(dados: EnderecoViaCep): string {
  const partes = [dados.logradouro, dados.bairro, `${dados.localidade} - ${dados.uf}`]
    .map(parte => parte.trim()).filter(Boolean);
  return `${partes.join(', ')}. CEP: ${formatarCep(dados.cep)}`;
}

export async function consultarCep(valor: string): Promise<EnderecoViaCep> {
  const digitos = valor.replace(/\D/g, '');
  if (!/^\d{8}$/.test(digitos)) {
    throw new Error('Informe um CEP com exatamente 8 números.');
  }

  const controlador = new AbortController();
  const temporizador = setTimeout(() => controlador.abort(), 10000);
  try {
    const resposta = await fetch(`https://viacep.com.br/ws/${digitos}/json/`, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal: controlador.signal,
    });
    if (!resposta.ok) throw new Error('A consulta de CEP está indisponível. Digite seu endereço manualmente.');
    const dados: unknown = await resposta.json();
    if (!dados || typeof dados !== 'object') {
      throw new Error('O serviço retornou uma resposta inválida. Digite seu endereço manualmente.');
    }
    const resultado = dados as Record<string, unknown>;
    if (resultado.erro === true || resultado.erro === 'true') {
      throw new Error('CEP não encontrado. Confira os números ou digite o endereço manualmente.');
    }
    if (typeof resultado.localidade !== 'string' || !resultado.localidade ||
        typeof resultado.uf !== 'string' || !/^[A-Z]{2}$/.test(resultado.uf)) {
      throw new Error('O serviço retornou um endereço incompleto. Digite o endereço manualmente.');
    }
    return {
      cep: digitos,
      logradouro: typeof resultado.logradouro === 'string' ? resultado.logradouro : '',
      bairro: typeof resultado.bairro === 'string' ? resultado.bairro : '',
      localidade: resultado.localidade,
      uf: resultado.uf,
      complemento: typeof resultado.complemento === 'string' ? resultado.complemento : '',
    };
  } catch (erro: unknown) {
    if (erro instanceof Error && erro.name === 'AbortError') {
      throw new Error('A consulta demorou muito. Confira a conexão ou digite o endereço manualmente.');
    }
    if (erro instanceof TypeError) {
      throw new Error('Sem acesso ao ViaCEP. Verifique a internet ou digite o endereço manualmente.');
    }
    throw erro;
  } finally {
    clearTimeout(temporizador);
  }
}
