import * as SQLite from 'expo-sqlite';
import { doc, getDocFromServer, setDoc, updateDoc, deleteDoc, serverTimestamp } from 'firebase/firestore';
import { firebaseServices } from './firebase/config';
import { sessaoOffline } from './firebase/sessaoOffline';
import { EMPRESA_ID, idHorario, ReservaRemota } from './firebase/agendamentos';
import { temInternet } from './conexao';

type Escopo = 'cliente' | 'empresa';
type Reserva = ReservaRemota & { id: string; erroSincronizacao?: string; pendente?: boolean };
let dbPromise: Promise<SQLite.SQLiteDatabase> | null = null;
async function banco(): Promise<SQLite.SQLiteDatabase> {
  if (!dbPromise) dbPromise = abrir().catch(error => { dbPromise = null; throw error; });
  return dbPromise;
}
async function abrir() {
  const db = await SQLite.openDatabaseAsync('esteticar_agenda_offline.db');
  await db.execAsync(`PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS agenda_cache (id TEXT PRIMARY KEY, uid TEXT NOT NULL, empresa TEXT NOT NULL, dados TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS agenda_pendente (id TEXT PRIMARY KEY, uid TEXT NOT NULL, dados TEXT NOT NULL, erro TEXT);
    CREATE TABLE IF NOT EXISTS status_pendente (id TEXT PRIMARY KEY, uid TEXT NOT NULL, empresa TEXT NOT NULL, status_anterior TEXT NOT NULL, status_novo TEXT NOT NULL, erro TEXT);
    CREATE TABLE IF NOT EXISTS empresa_autorizada (uid TEXT PRIMARY KEY, empresa TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS agenda_cache_v2 (escopo TEXT NOT NULL, usuario TEXT NOT NULL, empresa TEXT NOT NULL, id TEXT NOT NULL, dados TEXT NOT NULL, PRIMARY KEY(escopo, usuario, empresa, id));
    CREATE TABLE IF NOT EXISTS cache_atualizacoes (escopo TEXT NOT NULL, usuario TEXT NOT NULL, empresa TEXT NOT NULL, PRIMARY KEY(escopo,usuario,empresa));
    CREATE TABLE IF NOT EXISTS agenda_pendente_v2 (uid TEXT NOT NULL, id TEXT NOT NULL, dados TEXT NOT NULL, erro TEXT, PRIMARY KEY(uid,id));
    CREATE TABLE IF NOT EXISTS status_pendente_v2 (uid TEXT NOT NULL, id TEXT NOT NULL, empresa TEXT NOT NULL, status_anterior TEXT NOT NULL, status_novo TEXT NOT NULL, erro TEXT, PRIMARY KEY(uid,id));
    CREATE TABLE IF NOT EXISTS cancelamento_pendente (uid TEXT NOT NULL, id TEXT NOT NULL, erro TEXT, PRIMARY KEY(uid,id));
    CREATE TABLE IF NOT EXISTS perfil_pendente (uid TEXT PRIMARY KEY, nome TEXT NOT NULL, telefone TEXT NOT NULL, endereco TEXT NOT NULL, erro TEXT);
    CREATE TABLE IF NOT EXISTS pagamento_pendente (uid TEXT NOT NULL, id TEXT NOT NULL, forma TEXT NOT NULL, erro TEXT, PRIMARY KEY(uid,id));
    INSERT OR IGNORE INTO agenda_pendente_v2 SELECT uid,id,dados,erro FROM agenda_pendente;
    INSERT OR IGNORE INTO status_pendente_v2 SELECT uid,id,empresa,status_anterior,status_novo,erro FROM status_pendente;
    DELETE FROM agenda_pendente;
    DELETE FROM status_pendente;
  `);
  return db;
}

// O cache do administrador e o cache individual não compartilham linhas:
// jamais apagar a agenda administrativa ao atualizar a visão do cliente.
export async function salvarCache(uid: string, empresa: string, items: any[], modo: Escopo) {
  const db = await banco();
  await db.withExclusiveTransactionAsync(async tx => {
    await tx.runAsync('DELETE FROM agenda_cache_v2 WHERE escopo=? AND usuario=? AND empresa=?',modo,uid,empresa);
    await tx.runAsync('INSERT OR IGNORE INTO cache_atualizacoes(escopo,usuario,empresa) VALUES (?,?,?)',modo,uid,empresa);
    for (const item of items) {
      await tx.runAsync('INSERT OR REPLACE INTO agenda_cache_v2(escopo,usuario,empresa,id,dados) VALUES (?,?,?,?,?)',modo,uid,empresa,String(item.id),JSON.stringify(item));
    }
  });
}
async function lerCache(uid:string, empresa:string, modo:Escopo): Promise<any[]> {
  const db=await banco();
  const rows=await db.getAllAsync<{dados:string}>('SELECT dados FROM agenda_cache_v2 WHERE escopo=? AND usuario=? AND empresa=?',modo,uid,empresa);
  if (rows.length) return rows.map(r=>JSON.parse(r.dados));
  const atualizado=await db.getFirstAsync('SELECT 1 FROM cache_atualizacoes WHERE escopo=? AND usuario=? AND empresa=?',modo,uid,empresa);
  if(atualizado)return [];
  // Conserva dados de instalações anteriores à mudança de esquema.
  if(modo==='cliente') {
    const legacy=await db.getAllAsync<{dados:string}>('SELECT dados FROM agenda_cache WHERE uid=?',uid);
    return legacy.map(r=>JSON.parse(r.dados));
  }
  const legacy=await db.getAllAsync<{dados:string}>('SELECT dados FROM agenda_cache WHERE empresa=?',empresa);
  return legacy.map(r=>JSON.parse(r.dados));
}
export async function lerCacheCliente(uid:string,empresa:string){return lerCache(uid,empresa,'cliente');}
export async function lerCacheEmpresa(empresa:string,uid:string){return lerCache(uid,empresa,'empresa');}
export async function guardarConfirmadoLocal(uid:string,empresa:string,item:Reserva){
  const db=await banco();
  await db.runAsync('INSERT OR IGNORE INTO cache_atualizacoes(escopo,usuario,empresa) VALUES (?,?,?)','cliente',uid,empresa);
  await db.runAsync('INSERT OR REPLACE INTO agenda_cache_v2(escopo,usuario,empresa,id,dados) VALUES (?,?,?,?,?)','cliente',uid,empresa,item.id,JSON.stringify(item));
}
export async function lerPendentes(uid:string):Promise<Reserva[]> {
  const db=await banco();
  const rows=await db.getAllAsync<{dados:string;erro:string|null}>('SELECT dados,erro FROM agenda_pendente_v2 WHERE uid=?',uid);
  return rows.map(r=>({...JSON.parse(r.dados),pendente:true,erroSincronizacao:r.erro??undefined}));
}
export async function guardarPendente(r: Omit<ReservaRemota,'status'>):Promise<Reserva> {
  const db=await banco();
  if(!/^\d{2}\/\d{2}\/\d{4}$/.test(r.data) || !/^\d{2}:\d{2}$/.test(r.horario)) throw new Error('Data ou horário inválido.');
  const [dia,mes,ano]=r.data.split('/');
  const dataISO=`${ano}-${mes}-${dia}`;
  const id=idHorario(r.empresaId,dataISO,r.horario);
  const item:Reserva={...r,id,data:dataISO,status:'agendado'};
  await db.runAsync('INSERT OR REPLACE INTO agenda_pendente_v2(uid,id,dados,erro) VALUES (?,?,?,NULL)',r.clienteId,id,JSON.stringify(item));
  return item;
}
export async function removerReservaProvisoria(uid:string,id:string){
  const db=await banco();
  await db.runAsync('DELETE FROM agenda_pendente_v2 WHERE uid=? AND id=?',uid,id);
}

// As operações remotas não devem prender a fila caso a rede desapareça no meio da requisição.
function comPrazo<T>(promessa:Promise<T>,ms=8000):Promise<T>{
  return new Promise((resolve,reject)=>{
    const limite=setTimeout(()=>reject(new Error('Conexão temporariamente indisponível')),ms);
    promessa.then(valor=>{clearTimeout(limite);resolve(valor);},erro=>{clearTimeout(limite);reject(erro);});
  });
}
const enviandoReservas = new Set<string>();
export async function sincronizarPendentes(uid:string){
  if(enviandoReservas.has(uid) || firebaseServices().auth.currentUser?.uid !== uid || !await temInternet()) return;
  enviandoReservas.add(uid);
  try {
    const db=await banco();
    const rows=await db.getAllAsync<{id:string;dados:string}>('SELECT id,dados FROM agenda_pendente_v2 WHERE uid=?',uid);
    for(const row of rows){
      if(firebaseServices().auth.currentUser?.uid!==uid || !await temInternet()) break;
      const item=JSON.parse(row.dados) as Reserva;
      const referencia=doc(firebaseServices().db,'agendamentos',row.id);
      try {
        // O ID reservado por horário impede dupla confirmação pelas regras do Firestore.
        const {id,...campos}=item;
        await comPrazo(setDoc(referencia,{...campos,criadoEm:serverTimestamp()}));
        await guardarConfirmadoLocal(uid,item.empresaId,item);
        await db.runAsync('DELETE FROM agenda_pendente_v2 WHERE uid=? AND id=?',uid,row.id);
      }catch(e:any){
        if(e?.code==='permission-denied'){
          // Uma escrita confirmada anteriormente pode ter perdido a resposta por queda de rede.
          try {
            const remoto=await comPrazo(getDocFromServer(referencia));
            if(remoto.exists() && remoto.data().clienteId===uid){
              await guardarConfirmadoLocal(uid,item.empresaId,{...item,...remoto.data(),id:row.id});
              await db.runAsync('DELETE FROM agenda_pendente_v2 WHERE uid=? AND id=?',uid,row.id);
              continue;
            }
          }catch{ /* Reserva de outro cliente não pode ser consultada pelas regras. */ }
          await db.runAsync('UPDATE agenda_pendente_v2 SET erro=? WHERE uid=? AND id=?','Reserva não confirmada pelo Firebase: horário ocupado ou acesso negado. Confira as regras da agenda e tente sincronizar novamente.',uid,row.id);
        }
      }
    }
  } finally {enviandoReservas.delete(uid);}
}

export async function registrarEmpresaAutorizada(uid:string,empresa:string){
  const db=await banco();
  await db.runAsync('INSERT OR REPLACE INTO empresa_autorizada(uid,empresa) VALUES (?,?)',uid,empresa);
}
export async function empresaAutorizadaLocal(uid:string):Promise<string|null>{
  const db=await banco();
  const row=await db.getFirstAsync<{empresa:string}>('SELECT empresa FROM empresa_autorizada WHERE uid=?',uid);
  return row?.empresa??null;
}
export async function guardarStatusPendente(uid:string,empresa:string,id:string,anterior:string,novo:string){
  const sessao=await sessaoOffline('estetica');
  if(sessao.user.uid!==uid || await empresaAutorizadaLocal(uid)!==empresa) throw new Error('Conta administrativa não autorizada neste aparelho.');
  const db=await banco();
  const anteriorPendente=await db.getFirstAsync<{status_anterior:string}>('SELECT status_anterior FROM status_pendente_v2 WHERE id=? AND uid=?',id,uid);
  await db.runAsync('INSERT OR REPLACE INTO status_pendente_v2(uid,id,empresa,status_anterior,status_novo,erro) VALUES (?,?,?,?,?,NULL)',uid,id,empresa,anteriorPendente?.status_anterior??anterior,novo);
}
export async function lerStatusPendentes(uid:string,empresa:string){
  const db=await banco();
  return db.getAllAsync<{id:string;status_novo:string;erro:string|null}>('SELECT id,status_novo,erro FROM status_pendente_v2 WHERE uid=? AND empresa=?',uid,empresa);
}
const enviandoStatus=new Set<string>();
export async function sincronizarStatusPendentes(uid:string,empresa:string){
  const chave=`${uid}:${empresa}`;
  if(enviandoStatus.has(chave)||firebaseServices().auth.currentUser?.uid!==uid || await empresaAutorizadaLocal(uid)!==empresa || !await temInternet()) return;
  enviandoStatus.add(chave);
  try{
    const db=await banco();
    const rows=await db.getAllAsync<{id:string;status_anterior:string;status_novo:string;erro:string|null}>('SELECT id,status_anterior,status_novo,erro FROM status_pendente_v2 WHERE uid=? AND empresa=?',uid,empresa);
    for(const row of rows){
      if(firebaseServices().auth.currentUser?.uid!==uid || !await temInternet()) break;
      if(row.erro) continue; // conflito exige revisão humana antes de sobrescrever
      try{
        const referencia=doc(firebaseServices().db,'agendamentos',row.id);
        const remoto=await comPrazo(getDocFromServer(referencia));
        if(remoto.exists() && remoto.data().empresaId===empresa && remoto.data().status===row.status_novo){
          await db.runAsync('DELETE FROM status_pendente_v2 WHERE uid=? AND id=?',uid,row.id);continue;
        }
        if(!remoto.exists()||remoto.data().empresaId!==empresa||remoto.data().status!==row.status_anterior){
          await db.runAsync('UPDATE status_pendente_v2 SET erro=? WHERE uid=? AND id=?','O status mudou no servidor. Revise a alteração.',uid,row.id);continue;
        }
        await comPrazo(updateDoc(referencia,{status:row.status_novo,atualizadoEm:serverTimestamp()}));
        await db.runAsync('DELETE FROM status_pendente_v2 WHERE uid=? AND id=?',uid,row.id);
      }catch(e:any){
        if(e?.code==='permission-denied') await db.runAsync('UPDATE status_pendente_v2 SET erro=? WHERE uid=? AND id=?','Sem permissão para alterar esse atendimento.',uid,row.id);
      }
    }
  }finally{enviandoStatus.delete(chave);}
}

export async function guardarPerfilPendente(uid:string,nome:string,telefone:string,endereco:string){
  const db=await banco();
  await db.runAsync('INSERT OR REPLACE INTO perfil_pendente(uid,nome,telefone,endereco,erro) VALUES (?,?,?,?,NULL)',uid,nome,telefone,endereco);
}
export async function sincronizarPerfilPendente(uid:string){
  if(firebaseServices().auth.currentUser?.uid!==uid || !await temInternet())return;
  const db=await banco();
  const row=await db.getFirstAsync<{nome:string;telefone:string;endereco:string}>('SELECT nome,telefone,endereco FROM perfil_pendente WHERE uid=?',uid);
  if(!row)return;
  try{
    await comPrazo(updateDoc(doc(firebaseServices().db,'usuarios',uid),row));
    await db.runAsync('DELETE FROM perfil_pendente WHERE uid=? AND nome=? AND telefone=? AND endereco=?',uid,row.nome,row.telefone,row.endereco);
  }catch(e:any){
    if(e?.code==='permission-denied')await db.runAsync('UPDATE perfil_pendente SET erro=? WHERE uid=?','Atualização do perfil não autorizada.',uid);
  }
}
export async function guardarCancelamento(uid:string,id:string){
  const db=await banco();
  await db.runAsync('INSERT OR REPLACE INTO cancelamento_pendente(uid,id,erro) VALUES (?,?,NULL)',uid,id);
}
export async function lerCancelamentos(uid:string){
  const db=await banco();
  const rows=await db.getAllAsync<{id:string;erro:string|null}>('SELECT id,erro FROM cancelamento_pendente WHERE uid=?',uid);
  return rows;
}
export async function guardarPagamento(uid:string,id:string,forma:string){
  const db=await banco();
  await db.runAsync('INSERT OR REPLACE INTO pagamento_pendente(uid,id,forma,erro) VALUES (?,?,?,NULL)',uid,id,forma);
}
export async function removerConfirmadoLocal(uid:string,id:string){
  const db=await banco();
  await db.runAsync('INSERT OR IGNORE INTO cache_atualizacoes(escopo,usuario,empresa) VALUES (?,?,?)','cliente',uid,EMPRESA_ID);
  await db.runAsync('DELETE FROM agenda_cache_v2 WHERE escopo=? AND usuario=? AND id=?','cliente',uid,id);
}
export async function lerPagamentos(uid:string){
  const db=await banco();
  return db.getAllAsync<{id:string;forma:string;erro:string|null}>('SELECT id,forma,erro FROM pagamento_pendente WHERE uid=?',uid);
}
const enviandoOperacoes=new Set<string>();
export async function sincronizarOperacoesCliente(uid:string){
  if(enviandoOperacoes.has(uid)||firebaseServices().auth.currentUser?.uid!==uid||!await temInternet()) return;
  enviandoOperacoes.add(uid);
  try{
    const db=await banco();
    for(const row of await lerPagamentos(uid)){
      if(firebaseServices().auth.currentUser?.uid!==uid||!await temInternet()) break;
      try{await comPrazo(updateDoc(doc(firebaseServices().db,'agendamentos',row.id),{formaPagamento:row.forma}));await db.runAsync('DELETE FROM pagamento_pendente WHERE uid=? AND id=? AND forma=?',uid,row.id,row.forma)}
      catch(e:any){if(e?.code==='permission-denied')await db.runAsync('UPDATE pagamento_pendente SET erro=? WHERE uid=? AND id=?','Não autorizado. Verifique a reserva.',uid,row.id);}
    }
    for(const row of await lerCancelamentos(uid)){
      if(firebaseServices().auth.currentUser?.uid!==uid||!await temInternet()) break;
      try {
        const referencia=doc(firebaseServices().db,'agendamentos',row.id);
        const remoto=await comPrazo(getDocFromServer(referencia));
        if(!remoto.exists()){await removerConfirmadoLocal(uid,row.id);await db.runAsync('DELETE FROM cancelamento_pendente WHERE uid=? AND id=?',uid,row.id);continue;}
        if(remoto.data().clienteId!==uid || remoto.data().status!=='agendado'){
          await db.runAsync('UPDATE cancelamento_pendente SET erro=? WHERE uid=? AND id=?','Este atendimento não pode mais ser cancelado.',uid,row.id);continue;
        }
        await comPrazo(deleteDoc(referencia));
        await removerConfirmadoLocal(uid,row.id);
        await db.runAsync('DELETE FROM cancelamento_pendente WHERE uid=? AND id=?',uid,row.id);
      }catch(e:any){if(e?.code==='permission-denied')await db.runAsync('UPDATE cancelamento_pendente SET erro=? WHERE uid=? AND id=?','Cancelamento não autorizado. Confira o status.',uid,row.id);}
    }
  }finally{enviandoOperacoes.delete(uid);}
}
