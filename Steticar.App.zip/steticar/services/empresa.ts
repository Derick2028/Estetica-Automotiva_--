import * as SQLite from 'expo-sqlite';
export type Empresa={nome:string;telefone:string;email:string;endereco:string;foto:string|null};
export async function salvarEmpresa(e:Empresa){const db=await SQLite.openDatabaseAsync('steticcar.db');await db.execAsync('CREATE TABLE IF NOT EXISTS empresa (id INTEGER PRIMARY KEY CHECK(id=1),nome TEXT NOT NULL,telefone TEXT NOT NULL,email TEXT NOT NULL,endereco TEXT NOT NULL,foto TEXT);');await db.runAsync('INSERT OR REPLACE INTO empresa (id,nome,telefone,email,endereco,foto) VALUES (1,?,?,?,?,?)',e.nome,e.telefone,e.email,e.endereco,e.foto);}

