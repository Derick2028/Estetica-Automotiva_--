import { initializeApp, getApps, getApp } from 'firebase/app';
import { initializeAuth, getAuth } from 'firebase/auth';
import type { Persistence } from 'firebase/auth';

// Resolução nativa da persistência de autenticação Firebase.
const authNative = require('firebase/auth') as {
  getReactNativePersistence?: (storage: typeof AsyncStorage) => Persistence;
};
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const config = {
  apiKey: process.env.EXPO_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.EXPO_PUBLIC_FIREBASE_APP_ID,
};
export const firebaseConfigured = Boolean(config.apiKey && config.projectId && config.appId);
// Inicialização sob demanda para preservar o funcionamento sem credenciais.
let cached: ReturnType<typeof criarServicos> | null = null;
function criarServicos() {
  if (!firebaseConfigured) throw new Error('Configure as variáveis EXPO_PUBLIC_FIREBASE_* no .env');
  const app = getApps().length ? getApp() : initializeApp(config);
  let auth;
  try {
    auth = authNative.getReactNativePersistence
      ? initializeAuth(app, { persistence: authNative.getReactNativePersistence(AsyncStorage) })
      : (() => { throw new Error('Persistência de autenticação React Native indisponível. Verifique a versão do Firebase.'); })();
  } catch (error: any) {
    // initializeAuth pode ter sido chamado anteriormente durante o hot reload.
    if (error?.code === 'auth/already-initialized') auth = getAuth(app);
    else throw error;
  }
  return { auth, db: getFirestore(app), storage: getStorage(app) };
}
export function firebaseServices() { return cached ?? (cached = criarServicos()); }
