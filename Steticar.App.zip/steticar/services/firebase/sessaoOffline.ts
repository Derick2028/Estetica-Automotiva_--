import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { firebaseServices } from './config';
import type { PerfilRemoto } from './autenticacao';

const SESSAO = 'esteticar_sessao_validada_v2';
const chaveAnterior = (uid: string) => `esteticar:sessao-offline:${uid}`;
type SessaoLocal = { uid: string; email: string; perfil: PerfilRemoto };

// A sessão local é gravada somente após autenticação E validação online do perfil.
// Não guarda senhas ou tokens; sair do app revoga o acesso local automático.
export async function guardarPerfilOffline(uid: string, perfil: PerfilRemoto, email?: string | null) {
  const endereco = email ?? firebaseServices().auth.currentUser?.email;
  if (!endereco) throw new Error('Conta sem e-mail válido.');
  const registro: SessaoLocal = { uid, email: endereco.toLowerCase(), perfil };
  await SecureStore.setItemAsync(SESSAO, JSON.stringify(registro));
  await AsyncStorage.removeItem(chaveAnterior(uid));
}

export async function lerSessaoLocal(): Promise<SessaoLocal | null> {
  const texto = await SecureStore.getItemAsync(SESSAO);
  if (texto) {
    try {
      const sessao = JSON.parse(texto) as SessaoLocal;
      if (sessao.uid && sessao.email && ['cliente','estetica'].includes(sessao.perfil?.tipo)) return sessao;
    } catch { /* Registro inválido. */ }
  }
  // Atualiza instalações antigas apenas com Firebase Auth já autenticado.
  const auth=firebaseServices().auth;
  if(!auth.currentUser){
    await Promise.race([auth.authStateReady().catch(()=>{}),new Promise(resolve=>setTimeout(resolve,2500))]);
  }
  const atual = auth.currentUser;
  if (!atual?.uid || !atual.email) return null;
  const antigo = await AsyncStorage.getItem(chaveAnterior(atual.uid));
  if (!antigo) return null;
  try {
    const perfil = (JSON.parse(antigo) as { perfil: PerfilRemoto }).perfil;
    if (!perfil) return null;
    await guardarPerfilOffline(atual.uid, perfil, atual.email);
    return { uid: atual.uid, email: atual.email.toLowerCase(), perfil };
  } catch { return null; }
}

export async function sessaoOffline(tipo: 'cliente'|'estetica') {
  // Primeiro usa o registro do dispositivo: não depende de uma resposta do Firebase.
  const sessao = await lerSessaoLocal();
  if (!sessao || sessao.perfil.tipo !== tipo || sessao.perfil.ativo === false ||
      (tipo === 'estetica' && sessao.perfil.ativo !== true)) {
    throw new Error('Entre com internet uma vez neste aparelho para habilitar este acesso.');
  }
  const atual = firebaseServices().auth.currentUser;
  // Se há uma conta Firebase diferente ativa, não reutilizar dados de outro usuário.
  if (atual && atual.uid !== sessao.uid) throw new Error('A sessão pertence a outra conta.');
  return { user: {uid:sessao.uid, email:sessao.email}, perfil:sessao.perfil };
}
export async function limparPerfilOffline(uid: string) {
  const texto = await SecureStore.getItemAsync(SESSAO);
  if (texto) {
    try { if ((JSON.parse(texto) as SessaoLocal).uid === uid) await SecureStore.deleteItemAsync(SESSAO); } catch { await SecureStore.deleteItemAsync(SESSAO); }
  }
  await AsyncStorage.removeItem(chaveAnterior(uid));
}
