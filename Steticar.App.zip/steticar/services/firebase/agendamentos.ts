import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { firebaseServices } from './config';

export type StatusRemoto = 'agendado' | 'iniciado' | 'finalizado' | 'pronto' | 'cancelado';
export type FormaPagamento = 'pix' | 'dinheiro' | 'cartao_credito';
export type ReservaRemota = { clienteId: string; empresaId: string; nome: string; celular: string; placa: string; data: string; horario: string; tipoLavagem: string; servicosExtras: string[]; status: StatusRemoto; };
export const EMPRESA_ID = 'bjMKnYuOOlhyRxm2kPZ6GfKEGIp1';
export function idHorario(empresaId:string,data:string,horario:string) { return `${empresaId}_${data}_${horario}`; }

export function observarMeusAgendamentos(clienteId:string, atualizar:(items:any[])=>void, erro:(e:Error)=>void) {
  const q=query(collection(firebaseServices().db,'agendamentos'),where('clienteId','==',clienteId));
  return onSnapshot(q,{includeMetadataChanges:true},s=>{if(!s.metadata.fromCache) atualizar(s.docs.map(d=>({id:d.id,...d.data()})));},erro);
}
export function observarAgendaDaEmpresa(empresaId:string, atualizar:(items:any[])=>void, erro:(e:Error)=>void) {
  const q=query(collection(firebaseServices().db,'agendamentos'),where('empresaId','==',empresaId));
  return onSnapshot(q,{includeMetadataChanges:true},s=>{if(!s.metadata.fromCache) atualizar(s.docs.map(d=>({id:d.id,...d.data()})));},erro);
}


