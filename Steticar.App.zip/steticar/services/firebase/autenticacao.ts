import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signInWithCredential, GoogleAuthProvider, signOut, sendPasswordResetEmail, updatePassword, reauthenticateWithCredential, EmailAuthProvider } from 'firebase/auth';
import Constants from 'expo-constants';
import { Platform } from 'react-native';
import { doc, getDocFromServer, serverTimestamp, setDoc } from 'firebase/firestore';
import { firebaseServices } from './config';
import { guardarPerfilOffline, limparPerfilOffline, lerSessaoLocal } from './sessaoOffline';
import { limparBloqueioBiometrico, removerClienteBiometria, removerEmpresaBiometria } from '../../servicos/segurancaUsuario';
import { apagarCredenciaisCliente } from '../../servicos/credenciaisSalvas';

export type PerfilRemoto = { nome: string; telefone: string; endereco: string; tipo: 'cliente' | 'estetica'; ativo?: boolean; empresaId?: string };

// Contas novas criadas pelo aplicativo recebem sempre o papel cliente.
// O acesso de proprietário exige autorização separada no Firestore.
export async function cadastrarClienteFirebase(email: string, senha: string, perfil: Omit<PerfilRemoto, 'tipo'>) {
  const { auth, db } = firebaseServices();
  const cred = await createUserWithEmailAndPassword(auth, email.trim().toLowerCase(), senha);
  try {
    await setDoc(doc(db, 'usuarios', cred.user.uid), {
      ...perfil, tipo: 'cliente', ativo: true, email: cred.user.email, criadoEm: serverTimestamp(),
    });
  } catch (error) {
    // Não apagar a conta automaticamente: informe falha parcial para tratamento.
    throw new Error('Conta criada no Authentication, mas não foi possível salvar o perfil. Verifique as regras do Firestore.');
  }
  await guardarPerfilOffline(cred.user.uid, {...perfil,tipo:'cliente',ativo:true},cred.user.email);
  await limparBloqueioBiometrico();
  return cred.user.uid;
}
export async function entrarFirebase(email: string, senha: string) {
  const { auth, db } = firebaseServices();
  const endereco = email.trim().toLowerCase();
  // A senha sempre precisa ser validada pelo Firebase. Quando estiver offline,
  // a entrada pode usar uma sessão biométrica previamente autorizada.
  const cred = await signInWithEmailAndPassword(auth, endereco, senha);
  const snap = await getDocFromServer(doc(db, 'usuarios', cred.user.uid));
  const perfil = snap.exists() ? snap.data() as PerfilRemoto : null;
  if (perfil && perfil.ativo !== false) {
    await guardarPerfilOffline(cred.user.uid, perfil, cred.user.email);
  }
  await limparBloqueioBiometrico();
  return { usuario: cred.user, perfil };
}
/**
 * Login Google requer internet na primeira utilização, Google OAuth habilitado
 * no Firebase e cliente OAuth Web + SHA-1 do APK configurados no Google Cloud.
 * Nunca cria conta administrativa por conta própria.
 */
export async function entrarGoogleFirebase(tipoSolicitado: 'cliente' | 'estetica') {
  const webClientId = process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID;
  if (!webClientId) throw new Error('Login Google ainda não configurado: informe EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID.');
  // O Expo Go não inclui o módulo nativo Google Sign-In.
  // O require é adiado para permitir testar as demais telas no Expo Go SDK 58.
  if (Constants.expoGoConfig != null || Constants.appOwnership === 'expo') {
    throw new Error('O login Google necessita do aplicativo instalado (build nativa). No Expo Go, entre com e-mail e senha.');
  }
  if (Platform.OS === 'web') throw new Error('O Google Sign-In nativo está disponível apenas nos aplicativos Android e iOS.');
  const { GoogleSignin } = require('@react-native-google-signin/google-signin') as typeof import('@react-native-google-signin/google-signin');
  GoogleSignin.configure({
    webClientId,
    ...(process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID ? { iosClientId: process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID } : {}),
  });
  if (Platform.OS === 'android') await GoogleSignin.hasPlayServices({ showPlayServicesUpdateDialog: true });
  const resultadoGoogle = await GoogleSignin.signIn();
  if (resultadoGoogle.type !== 'success') return null; // Usuário cancelou.
  const idToken = resultadoGoogle.data?.idToken;
  if (!idToken) throw new Error('O Google não retornou um token de identidade. Confira o cliente OAuth configurado.');

  const { auth, db } = firebaseServices();
  const cred = await signInWithCredential(auth, GoogleAuthProvider.credential(idToken));
  if (!cred.user.email) throw new Error('A Conta Google não disponibilizou um e-mail.');
  const email = cred.user.email.toLowerCase();
  const referencia = doc(db, 'usuarios', cred.user.uid);
  let perfil: PerfilRemoto;
  try {
    const snap = await getDocFromServer(referencia);
    if (snap.exists()) {
      perfil = snap.data() as PerfilRemoto;
    } else if (tipoSolicitado === 'cliente') {
      perfil = { nome: cred.user.displayName?.trim() || 'Cliente', telefone: '', endereco: '', tipo: 'cliente', ativo: true };
      // Regras: contas novas podem criar somente seu próprio perfil de cliente.
      await setDoc(referencia, { ...perfil, email, criadoEm: serverTimestamp() });
    } else {
      throw new Error('Esta Conta Google ainda não possui autorização de estética no Firestore.');
    }
    if (perfil.tipo !== tipoSolicitado || perfil.ativo !== true) {
      throw new Error(tipoSolicitado === 'estetica'
        ? 'Esta Conta Google não tem autorização administrativa da estética.'
        : 'Esta Conta Google não está ativa como cliente.');
    }
    await guardarPerfilOffline(cred.user.uid, perfil, cred.user.email);
    await limparBloqueioBiometrico();
    return { usuario: cred.user, perfil };
  } catch (erro) {
    // Uma conta inválida não pode permanecer aberta no Firebase por engano.
    await signOut(auth).catch(() => {});
    throw erro;
  }
}

export async function sairFirebase() {
  const auth = firebaseServices().auth;
  const uid = auth.currentUser?.uid ?? (await lerSessaoLocal())?.uid;
  if (uid) await limparPerfilOffline(uid);
  await Promise.all([removerClienteBiometria(), removerEmpresaBiometria(), limparBloqueioBiometrico(), apagarCredenciaisCliente()]);
  await signOut(auth);
  // O Expo Go não oferece Google Sign-In nativo; não tente carregá-lo ali.
  if (Platform.OS !== 'web' && Constants.expoGoConfig == null && Constants.appOwnership !== 'expo') {
    const { GoogleSignin } = require('@react-native-google-signin/google-signin') as typeof import('@react-native-google-signin/google-signin');
    await GoogleSignin.signOut().catch(() => {});
  }
}

export async function recuperarSenhaFirebase(email: string) {
  const endereco = email.trim().toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(endereco)) throw new Error('Informe um e-mail válido.');
  await sendPasswordResetEmail(firebaseServices().auth, endereco);
}
export async function alterarSenhaFirebase(senhaAtual: string, novaSenha: string) {
  const usuario = firebaseServices().auth.currentUser;
  if (!usuario?.email) throw new Error('Entre novamente com e-mail e senha.');
  if (novaSenha.length < 6) throw new Error('A nova senha precisa ter pelo menos 6 caracteres.');
  await reauthenticateWithCredential(usuario, EmailAuthProvider.credential(usuario.email, senhaAtual));
  await updatePassword(usuario, novaSenha);
}
