import NetInfo from '@react-native-community/netinfo';

export async function temInternet(): Promise<boolean> {
  try {
    const estado = await NetInfo.fetch();
    return estado.isConnected === true && estado.isInternetReachable !== false;
  } catch { return false; }
}
export function observarConexao(quandoOnline: () => void) {
  let conectadoAntes = false;
  return NetInfo.addEventListener(estado => {
    const conectado = estado.isConnected === true && estado.isInternetReachable !== false;
    if (conectado && !conectadoAntes) quandoOnline();
    conectadoAntes = conectado;
  });
}
