import * as SQLite from 'expo-sqlite';

let databasePromise: Promise<SQLite.SQLiteDatabase> | null = null;

async function getDatabase(): Promise<SQLite.SQLiteDatabase> {
  if (!databasePromise) databasePromise = criarBanco().catch(erro => { databasePromise = null; throw erro; });
  return databasePromise;
}

async function criarBanco(): Promise<SQLite.SQLiteDatabase> {
  const db = await SQLite.openDatabaseAsync('steticcar.db');
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS clientes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      celular TEXT NOT NULL UNIQUE,
      endereco TEXT NOT NULL,
      placa TEXT NOT NULL UNIQUE,
      foto_perfil TEXT,
      email TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
  `);
  try { await db.execAsync('ALTER TABLE clientes ADD COLUMN foto_perfil TEXT;'); } catch { /* coluna já existe */ }
  try { await db.execAsync('ALTER TABLE clientes ADD COLUMN email TEXT;'); } catch { /* coluna já existe */ }
  await db.execAsync(`CREATE TABLE IF NOT EXISTS agendamentos (
    id TEXT PRIMARY KEY, cliente_id INTEGER NOT NULL, placa TEXT NOT NULL,
    data TEXT NOT NULL, horario TEXT NOT NULL, tipo_lavagem TEXT NOT NULL,
    foto_placa TEXT, status TEXT NOT NULL DEFAULT 'agendado',
    UNIQUE(data, horario), FOREIGN KEY(cliente_id) REFERENCES clientes(id)
  );`);
  try { await db.execAsync("ALTER TABLE agendamentos ADD COLUMN atualizado_em TEXT;"); } catch { /* coluna existente */ }
  try { await db.execAsync('ALTER TABLE agendamentos ADD COLUMN servicos_extras TEXT;'); } catch { /* coluna existente */ }
  try { await db.execAsync('ALTER TABLE agendamentos ADD COLUMN midia_veiculo TEXT;'); } catch { /* coluna existente */ }
  try { await db.execAsync('ALTER TABLE agendamentos ADD COLUMN tipo_midia_veiculo TEXT;'); } catch { /* coluna existente */ }
  await db.execAsync('CREATE INDEX IF NOT EXISTS idx_agendamentos_cliente ON agendamentos(cliente_id);');
  return db;
}

export interface Cliente {
  id: number;
  nome: string;
  celular: string;
  endereco: string;
  placa: string;
  foto_perfil?: string | null;
  email?: string | null;
  created_at?: string;
  updated_at?: string;
}

export async function inicializarBanco() {
  await getDatabase();
}

export async function criarCliente(dados: Omit<Cliente, 'id' | 'created_at' | 'updated_at'>) {
  const db = await getDatabase();
  const result = await db.runAsync(
    'INSERT INTO clientes (nome, celular, endereco, placa, foto_perfil, email) VALUES (?, ?, ?, ?, ?, ?)',
    dados.nome,
    dados.celular,
    dados.endereco,
    dados.placa,
    dados.foto_perfil ?? null,
    dados.email ?? null,
  );
  return Number(result.lastInsertRowId);
}

export async function buscarClientePorId(id: number) {
  const db = await getDatabase();
  return db.getFirstAsync<Cliente>('SELECT * FROM clientes WHERE id = ?', id);
}

export async function buscarClientePorEmail(email: string) {
  const db = await getDatabase();
  return db.getFirstAsync<Cliente>('SELECT * FROM clientes WHERE LOWER(TRIM(email)) = ? LIMIT 1', email.trim().toLowerCase());
}

export async function buscarClientePorCelular(celular: string) {
  const db = await getDatabase();
  return db.getFirstAsync<Cliente>('SELECT * FROM clientes WHERE celular = ?', celular);
}

export async function atualizarCliente(id: number, dados: Pick<Cliente, 'nome' | 'celular' | 'endereco' | 'placa' | 'foto_perfil' | 'email'>) {
  const db = await getDatabase();
  await db.runAsync(
    'UPDATE clientes SET nome = ?, celular = ?, endereco = ?, placa = ?, foto_perfil = ?, email = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
    dados.nome, dados.celular, dados.endereco, dados.placa, dados.foto_perfil ?? null, dados.email ?? null, id,
  );
}



export type StatusLavagem = 'agendado' | 'iniciado' | 'finalizado' | 'pronto' | 'cancelado';


