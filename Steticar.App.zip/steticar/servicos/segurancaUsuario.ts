import * as SecureStore from 'expo-secure-store';
import * as LocalAuthentication from 'expo-local-authentication';
import { Platform } from 'react-native';
import Constants from 'expo-constants';
import { buscarClientePorId } from '../services/database';
import { lerSessaoLocal } from '../services/firebase/sessaoOffline';

type Tipo = 'cliente' | 'estetica';
export type AcessoBiometrico = { uid: string; email: string; tipo: Tipo; clienteId?: number };
const chave = (tipo: Tipo) => `esteticar_biometria_${tipo}_v2`;
const CHAVE_ANTIGA = 'steticcar_cliente_biometria_id';
const BLOQUEIO = 'esteticar_bloqueio_biometrico_v1';

// Uma digital/face desbloqueia APENAS a conta já validada neste dispositivo.
// Não são salvos senha, token Firebase ou dados biométricos do usuário.
async function salvarAcesso(tipo: Tipo, clienteId?: number) {
  const sessao = await lerSessaoLocal();
  if (!sessao || sessao.perfil.tipo !== tipo || sessao.perfil.ativo === false ||
      (tipo === 'estetica' && sessao.perfil.ativo !== true)) {
    throw new Error('Entre com sua senha e internet antes de ativar a biometria.');
  }
  if (tipo === 'cliente') {
    const cliente = clienteId && await buscarClientePorId(clienteId);
    if (!cliente || cliente.email?.trim().toLowerCase() !== sessao.email.toLowerCase()) {
      throw new Error('O perfil local não corresponde à conta autenticada.');
    }
  }
  const registro: AcessoBiometrico = { uid: sessao.uid, email: sessao.email.toLowerCase(), tipo,
    ...(clienteId ? { clienteId } : {}) };
  await SecureStore.setItemAsync(chave(tipo), JSON.stringify(registro), {
    keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK,
  });
  if (tipo === 'cliente') await SecureStore.deleteItemAsync(CHAVE_ANTIGA);
}

export async function obterAcessoBiometrico(tipo: Tipo): Promise<AcessoBiometrico | null> {
  const sessao = await lerSessaoLocal();
  if (!sessao || sessao.perfil.tipo !== tipo || sessao.perfil.ativo === false ||
      (tipo === 'estetica' && sessao.perfil.ativo !== true)) return null;

  let texto = await SecureStore.getItemAsync(chave(tipo));
  // Compatibilidade com a configuração feita em versões anteriores do EstetiCar.
  if (!texto && tipo === 'cliente') {
    const legado = await SecureStore.getItemAsync(CHAVE_ANTIGA);
    const id = Number(legado);
    if (legado && Number.isSafeInteger(id) && id > 0) {
      const cliente = await buscarClientePorId(id);
      if (cliente?.email?.trim().toLowerCase() === sessao.email.toLowerCase()) {
        await salvarAcesso('cliente', id);
        texto = await SecureStore.getItemAsync(chave(tipo));
      }
    }
  }
  if (!texto) return null;
  try {
    const dados = JSON.parse(texto) as AcessoBiometrico;
    if (dados.tipo !== tipo || dados.uid !== sessao.uid ||
        dados.email?.toLowerCase() !== sessao.email.toLowerCase()) return null;
    if (tipo === 'cliente' && (!Number.isSafeInteger(dados.clienteId) || !dados.clienteId)) return null;
    return dados;
  } catch { return null; }
}

export async function salvarClienteBiometria(id: number) { await salvarAcesso('cliente', id); }

export async function removerClienteBiometria() {
  await Promise.all([SecureStore.deleteItemAsync(chave('cliente')), SecureStore.deleteItemAsync(CHAVE_ANTIGA)]);
}
export async function salvarEmpresaBiometria() { await salvarAcesso('estetica'); }
export async function removerEmpresaBiometria() { await SecureStore.deleteItemAsync(chave('estetica')); }
export async function bloquearComBiometria() { await SecureStore.setItemAsync(BLOQUEIO, '1'); }
export async function estaBloqueadoComBiometria() { return (await SecureStore.getItemAsync(BLOQUEIO)) === '1'; }
export async function limparBloqueioBiometrico() { await SecureStore.deleteItemAsync(BLOQUEIO); }

export async function nomeBiometria(): Promise<string> {
  const tipos = await LocalAuthentication.supportedAuthenticationTypesAsync();
  if (Platform.OS === 'ios' && tipos.includes(LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION)) return 'Face ID';
  if (tipos.includes(LocalAuthentication.AuthenticationType.FINGERPRINT)) return 'impressão digital';
  if (tipos.includes(LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION)) return 'reconhecimento facial';
  return 'biometria';
}

export async function autenticarNoAparelho(mensagem: string): Promise<boolean> {
  // O Face ID não é incluído no aplicativo Expo Go para iOS.
  if (Platform.OS === 'ios' && (Constants.expoGoConfig != null || Constants.appOwnership === 'expo')) {
    throw new Error('O Face ID não funciona no Expo Go no iPhone. Instale uma versão iOS própria do StetiCar para ativar e testar.');
  }
  const temSensor = await LocalAuthentication.hasHardwareAsync();
  const tipos = temSensor ? await LocalAuthentication.supportedAuthenticationTypesAsync() : [];
  if (!temSensor || tipos.length === 0) {
    throw new Error('O aplicativo não identificou um sensor biométrico compatível. Verifique o aparelho e teste em uma compilação instalada.');
  }
  const cadastrada = await LocalAuthentication.isEnrolledAsync();
  const nivel = await LocalAuthentication.getEnrolledLevelAsync();
  if (!cadastrada || nivel < LocalAuthentication.SecurityLevel.BIOMETRIC_WEAK) {
    throw new Error('A biometria foi detectada, mas não consta como cadastrada para uso por aplicativos. Confirme as permissões de biometria/Face ID do StetiCar nas configurações e tente novamente.');
  }
  const resultado = await LocalAuthentication.authenticateAsync({
    promptMessage: mensagem,
    cancelLabel: 'Cancelar',
    // Exigimos uma biometria efetiva; o PIN/senha continua sendo feito no login normal.
    disableDeviceFallback: true,
    // Alguns Android só têm biometria Classe 2, embora ela esteja cadastrada.
    // A classe 3 também é aceita quando o mínimo permitido é weak.
    ...(Platform.OS === 'android' ? { biometricsSecurityLevel: 'weak' as const } : {}),
  });
  if (resultado.success) return true;
  if (['user_cancel','system_cancel','app_cancel'].includes(resultado.error)) return false;
  if (resultado.error === 'lockout') throw new Error('Biometria temporariamente bloqueada por tentativas. Desbloqueie o aparelho e tente mais tarde.');
  if (resultado.error === 'not_enrolled') throw new Error('O Android/iPhone não disponibilizou biometria cadastrada para este aplicativo.');
  if (resultado.error === 'not_available') throw new Error('Serviço biométrico não disponível nesta execução. Use o APK ou uma compilação iOS própria.');
  throw new Error(`Falha biométrica (${resultado.error}). ${resultado.warning ?? 'Tente novamente ou entre com senha.'}`);
}
