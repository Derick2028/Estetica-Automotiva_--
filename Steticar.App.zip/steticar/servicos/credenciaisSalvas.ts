import * as SecureStore from 'expo-secure-store';

const CHAVE = 'steticcar_credenciais_cliente_v1';
export type CredenciaisSalvas = { email: string; senha: string };

// As credenciais ficam no armazenamento seguro do sistema (Keychain/Keystore), nunca em SQLite ou AsyncStorage.
export async function salvarCredenciaisCliente(email: string, senha: string): Promise<void> {
  await SecureStore.setItemAsync(CHAVE, JSON.stringify({ email: email.trim().toLowerCase(), senha }), {
    keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK,
  });
}

export async function lerCredenciaisCliente(): Promise<CredenciaisSalvas | null> {
  const valor = await SecureStore.getItemAsync(CHAVE);
  if (!valor) return null;
  try {
    const dados = JSON.parse(valor) as CredenciaisSalvas;
    if (typeof dados.email === 'string' && typeof dados.senha === 'string' && dados.email && dados.senha) return dados;
  } catch { /* ignora registro inválido */ }
  await apagarCredenciaisCliente();
  return null;
}

export async function apagarCredenciaisCliente(): Promise<void> {
  await SecureStore.deleteItemAsync(CHAVE);
}
