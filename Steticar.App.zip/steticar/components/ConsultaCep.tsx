import { createThemedStyles, themeColor } from '../ui/theme';
import { useRef, useState } from 'react';
import { Alert, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { consultarCep, enderecoDoCep, formatarCep } from '../services/viacep';

interface Props {
  enderecoAtual: string;
  aoPreencherEndereco: (endereco: string) => void;
}

/** Campo reutilizável no cadastro do cliente e da estética. Não impede preenchimento offline. */
export default function ConsultaCep({ enderecoAtual, aoPreencherEndereco }: Props) {
  const [cep, setCep] = useState('');
  const [consultando, setConsultando] = useState(false);
  const [mensagem, setMensagem] = useState('');
  const cepAtual = useRef('');

  const alterarCep = (valor: string) => {
    const formatado = formatarCep(valor);
    cepAtual.current = formatado;
    setCep(formatado);
    setMensagem('');
  };

  const buscar = async () => {
    if (consultando) return;
    if (cep.replace(/\D/g, '').length !== 8) {
      Alert.alert('CEP inválido', 'Digite os 8 números do CEP antes de consultar.');
      return;
    }
    const pesquisado = cep;
    setConsultando(true);
    setMensagem('Consultando a API pública ViaCEP...');
    try {
      const resultado = await consultarCep(pesquisado);
      // Se o CEP foi alterado enquanto a consulta ocorria, não preenche com dados antigos.
      if (cepAtual.current !== pesquisado) return;
      const enderecoEncontrado = enderecoDoCep(resultado);
      const preencher = () => {
        aoPreencherEndereco(enderecoEncontrado);
        setMensagem('Endereço preenchido pela API ViaCEP. Acrescente o número do imóvel e, se necessário, o complemento.');
      };
      if (enderecoAtual.trim()) {
        Alert.alert('Endereço já preenchido', 'Deseja substituir o endereço digitado pelo resultado da consulta?', [
          { text: 'Manter endereço', style: 'cancel', onPress: () => setMensagem('Endereço atual mantido.') },
          { text: 'Substituir', onPress: preencher },
        ]);
      } else {
        preencher();
      }
    } catch (erro: unknown) {
      if (cepAtual.current !== pesquisado) return;
      const texto = erro instanceof Error ? erro.message : 'Não foi possível consultar o CEP.';
      setMensagem(texto);
      Alert.alert('Consulta de CEP', texto);
    } finally {
      setConsultando(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>📮  CEP (API pública ViaCEP)</Text>
      <View style={styles.linha}>
        <TextInput
          accessibilityLabel="CEP para consulta na API pública ViaCEP"
          style={styles.input}
          value={cep}
          onChangeText={alterarCep}
          placeholder="00000-000"
          placeholderTextColor={themeColor("#688CA7")}
          keyboardType="number-pad"
          maxLength={9}
          returnKeyType="search"
          onSubmitEditing={() => { void buscar(); }}
        />
        <TouchableOpacity
          accessibilityRole="button"
          accessibilityLabel="Buscar endereço pelo CEP"
          style={[styles.botao, consultando && styles.desabilitado]}
          onPress={() => { void buscar(); }}
          disabled={consultando}
        >
          <Text style={styles.botaoTexto}>{consultando ? 'Buscando...' : 'Buscar CEP'}</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.ajuda}>A consulta exige internet. Sem conexão, preencha o endereço manualmente no campo abaixo.</Text>
      {!!mensagem && <Text accessibilityRole="text" style={styles.retorno}>{mensagem}</Text>}
    </View>
  );
}

const styles = createThemedStyles({
  container: { marginBottom: 14 },
  label: { color: themeColor('#fff'), fontSize: 15, fontWeight: '700', marginBottom: 7 },
  linha: { flexDirection: 'row', alignItems: 'stretch', gap: 10 },
  input: {flex: 1, minWidth: 0, minHeight: 50, borderWidth: 1, borderColor: themeColor('#164463'), borderRadius: 14, paddingHorizontal: 14, backgroundColor: themeColor('#081828'), color: themeColor('#fff'), fontSize: 16},
  botao: {minWidth: 113, minHeight: 50, alignItems: 'center', justifyContent: 'center', borderRadius: 16, paddingHorizontal: 11, backgroundColor: themeColor('#067EEB'), borderWidth: 1, borderColor: themeColor('#43DEFF'), shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.35, shadowRadius: 12, shadowOffset: {width:0,height:3}, elevation: 6},
  desabilitado: { opacity: 0.65 },
  botaoTexto: { color: themeColor('#fff'), fontWeight: '800', fontSize: 13 },
  ajuda: { color: themeColor('#9EBDD3'), fontSize: 12, lineHeight: 18, marginTop: 7 },
  retorno: { color: themeColor('#00B9FF'), fontSize: 12, lineHeight: 18, marginTop: 6 },
});
