import ThemeToggle from '../ui/ThemeToggle';
import { createThemedStyles, themeColor, themeStatusBar } from '../ui/theme';
import { ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, useWindowDimensions, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { BrandLogo, NEON, NeonBackdrop, neo } from '../ui/neon';

type Props = { onCliente: () => void; onCadastroCliente: () => void; onEstetica: () => void; onCadastroEstetica: () => void };
export default function TelaInicial({ onCliente, onCadastroCliente, onEstetica, onCadastroEstetica }: Props) {
 const { height, width } = useWindowDimensions();
 const small=height<710 || width<370;
 const cards=[
  {title:'Área do Cliente',subtitle:'Agende serviços e acompanhe seus atendimentos.',icon:'◉',enter:onCliente,register:onCadastroCliente,registerTitle:'Criar conta'},
  {title:'Área da Estética',subtitle:'Gerencie a agenda e seus clientes.',icon:'▣',enter:onEstetica,register:onCadastroEstetica,registerTitle:'Cadastrar estética'},
 ];
 return <SafeAreaView edges={['top','bottom']} style={s.safe}>
  <StatusBar barStyle={themeStatusBar()}/><NeonBackdrop/>
  <ScrollView contentContainerStyle={[s.content,{paddingVertical:small?16:27}]} showsVerticalScrollIndicator={false}>
   <ThemeToggle compact />
   <View style={s.hero}>
    <View pointerEvents="none" style={s.glow}/>
    <BrandLogo width={small?260:300} height={small?185:220}/>
    <Text style={s.eyebrow}>ESTÉTICA AUTOMOTIVA PREMIUM</Text>
    <Text style={s.title}>Seu carro merece o melhor.</Text>
    <Text style={s.subtitle}>Bem-vindo ao StetiCar. Escolha seu acesso.</Text>
   </View>
   <View style={{gap:14}}>{cards.map(c=><View key={c.title} style={[neo.card,s.card]}>
    <View style={s.row}><View style={s.iconBox}><Text style={s.icon}>{c.icon}</Text></View><View style={{flex:1}}><Text style={s.cardTitle}>{c.title}</Text><Text style={s.cardSub}>{c.subtitle}</Text></View></View>
    <View style={s.actions}><TouchableOpacity onPress={c.enter} style={[neo.action,{flex:1}]} accessibilityRole="button"><Text style={neo.actionText}>Entrar  ›</Text></TouchableOpacity>
     <TouchableOpacity onPress={c.register} style={[neo.secondary,{flex:1}]} accessibilityRole="button"><Text style={s.secondaryText}>{c.registerTitle}</Text></TouchableOpacity></View>
   </View>)}</View>
   <Text style={s.footer}>STETICAR  •  CUIDADO EM CADA DETALHE</Text>
  </ScrollView>
 </SafeAreaView>;
}
const s=createThemedStyles({
 safe:{flex:1,backgroundColor:NEON.bg},content:{flexGrow:1,justifyContent:'center',maxWidth:550,width:'100%',alignSelf:'center',paddingHorizontal:18},
 hero:{alignItems:'center',marginBottom:24},glow:{position:'absolute',top:20,width:220,height:170,borderRadius:100,backgroundColor:themeColor('rgba(0,150,255,0.13)')},
 eyebrow:{color:NEON.bright,fontSize:10,fontWeight:'900',letterSpacing:2,marginTop:-8},
 title:{color:NEON.text,fontSize:24,fontWeight:'900',textAlign:'center',marginTop:12},
 subtitle:{color:NEON.muted,fontSize:13,textAlign:'center',marginTop:8},
 card:{padding:17,backgroundColor:themeColor('rgba(9,19,33,0.98)')},row:{flexDirection:'row',alignItems:'center',gap:12,marginBottom:17},
 iconBox:{backgroundColor:NEON.input,borderWidth:1,borderColor:NEON.lineBright,borderRadius:15,width:55,height:55,justifyContent:'center',alignItems:'center'},
 icon:{color:NEON.bright,fontSize:30},cardTitle:{color:NEON.text,fontWeight:'900',fontSize:18},cardSub:{color:NEON.muted,fontSize:12,lineHeight:18,marginTop:4},
 actions:{flexDirection:'row',gap:10},secondaryText:{color:NEON.text,fontSize:12,fontWeight:'800',textAlign:'center'},
 footer:{fontSize:9,fontWeight:'900',letterSpacing:1,color:NEON.subtle,textAlign:'center',marginTop:23},
});
