import { createThemedStyles, themeColor } from '../ui/theme';
import { useMemo, useState } from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
const meses = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
const semana = ['D','S','T','Q','Q','S','S'];
const formatar = (d:Date) => `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
export default function CalendarioAgendamento({valor,onChange}:{valor:string;onChange:(v:string)=>void}) {
 const [mes,setMes] = useState(()=>new Date(new Date().getFullYear(),new Date().getMonth(),1));
 const dias = useMemo(()=>{const offset=new Date(mes.getFullYear(),mes.getMonth(),1).getDay();const qtd=new Date(mes.getFullYear(),mes.getMonth()+1,0).getDate();return [...Array(offset).fill(0),...Array.from({length:qtd},(_,i)=>i+1)];},[mes]);
 const hoje=new Date();hoje.setHours(0,0,0,0);
 const anterior=()=>setMes(new Date(mes.getFullYear(),mes.getMonth()-1,1));
 const proximo=()=>setMes(new Date(mes.getFullYear(),mes.getMonth()+1,1));
 const mesAtual=new Date(hoje.getFullYear(),hoje.getMonth(),1);
 return <View style={s.card}>
  <View style={s.header}><TouchableOpacity disabled={mes<=mesAtual} onPress={anterior} style={s.nav}><Text style={s.navText}>‹</Text></TouchableOpacity><Text style={s.mes}>{meses[mes.getMonth()]} {mes.getFullYear()}</Text><TouchableOpacity onPress={proximo} style={s.nav}><Text style={s.navText}>›</Text></TouchableOpacity></View>
  <View style={s.grid}>{semana.map((d,i)=><View key={'w'+i} style={s.cell}><Text style={s.week}>{d}</Text></View>)}{dias.map((d,i)=>{const date=d?new Date(mes.getFullYear(),mes.getMonth(),d):null;const disabled=!date||date<hoje;const selected=date&&formatar(date)===valor;return <TouchableOpacity key={'d'+i} disabled={disabled} onPress={()=>date&&onChange(formatar(date))} style={[s.cell,selected&&s.selected]}><Text style={[s.day,disabled&&s.disabled,selected&&s.selectedText]}>{d||''}</Text></TouchableOpacity>})}</View>
  <Text style={s.hint}>{valor?'Dia escolhido: '+valor:'Selecione um dia disponível no calendário'}</Text>
 </View>
}
const s=createThemedStyles({card:{backgroundColor: themeColor('#0E1929'), padding: 14, borderRadius: 20, borderWidth: 1, borderColor: themeColor('#164463'), marginBottom: 16, shadowColor: themeColor('#00B9FF'), shadowOpacity: 0.17, shadowRadius: 16, shadowOffset: {width:0,height:4}, elevation: 5},header:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:14},nav:{width:38,height:38,alignItems:'center',justifyContent:'center',backgroundColor:themeColor('#102439'),borderRadius:10},navText:{color:themeColor('#fff'),fontSize:26},mes:{color:themeColor('#fff'),fontWeight:'800',fontSize:16},grid:{flexDirection:'row',flexWrap:'wrap'},cell:{width:'14.2857%',height:42,alignItems:'center',justifyContent:'center',borderRadius:10},week:{color:themeColor('#78A6C3'),fontWeight:'800'},day:{color:themeColor('#F2F8FC'),fontWeight:'700'},disabled:{color:themeColor('#506B7D')},selected:{backgroundColor:themeColor('#067EEB')},selectedText:{color:themeColor('#fff')},hint:{color:themeColor('#9EBDD3'),fontSize:12,marginTop:10,textAlign:'center'}});
