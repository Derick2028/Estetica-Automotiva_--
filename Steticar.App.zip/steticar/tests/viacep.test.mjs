// Executar com: npm run test:cep (Node.js >= 22)
// As respostas são simuladas: não depende da disponibilidade do ViaCEP nos testes.
import test from 'node:test';
import assert from 'node:assert/strict';
import { consultarCep, enderecoDoCep, formatarCep } from '../services/viacep.ts';

const originalFetch = globalThis.fetch;
const resposta = (dados, status = 200) => ({ ok: status >= 200 && status < 300, json: async () => dados });

test.after(() => { globalThis.fetch = originalFetch; });

test('formata CEP com e sem pontuação', () => {
  assert.equal(formatarCep('01001000'), '01001-000');
  assert.equal(formatarCep('01001-000'), '01001-000');
  assert.equal(formatarCep('abc 123'), '123');
});

test('consulta API pública e monta endereço preenchível', async () => {
  let urlCapturada = '';
  globalThis.fetch = async url => {
    urlCapturada = url;
    return resposta({ cep: '01001-000', logradouro: 'Praça da Sé', bairro: 'Sé', localidade: 'São Paulo', uf: 'SP' });
  };
  const dados = await consultarCep('01001-000');
  assert.equal(urlCapturada, 'https://viacep.com.br/ws/01001000/json/');
  assert.equal(dados.localidade, 'São Paulo');
  assert.equal(enderecoDoCep(dados), 'Praça da Sé, Sé, São Paulo - SP. CEP: 01001-000');
});

test('rejeita CEP incompleto antes de acessar a API', async () => {
  let chamada = false;
  globalThis.fetch = async () => { chamada = true; return resposta({}); };
  await assert.rejects(() => consultarCep('1234'), /8 números/);
  assert.equal(chamada, false);
});

test('mostra mensagem amigável para CEP inexistente', async () => {
  globalThis.fetch = async () => resposta({ erro: true });
  await assert.rejects(() => consultarCep('99999999'), /CEP não encontrado/);
});

test('trata indisponibilidade do serviço', async () => {
  globalThis.fetch = async () => resposta({}, 500);
  await assert.rejects(() => consultarCep('01001000'), /consulta de CEP está indisponível/);
});

test('permite informar endereço manualmente quando não há internet', async () => {
  globalThis.fetch = async () => { throw new TypeError('Network request failed'); };
  await assert.rejects(() => consultarCep('01001000'), /Sem acesso ao ViaCEP/);
});

test('identifica retorno incompleto como resposta inválida', async () => {
  globalThis.fetch = async () => resposta({ localidade: '', uf: 'SP' });
  await assert.rejects(() => consultarCep('01001000'), /endereço incompleto/);
});
